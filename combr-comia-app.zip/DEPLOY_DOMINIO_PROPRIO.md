# Guia de Implantação no Domínio Próprio - ComIA (ComBr Soluções em Nuvem)

Este guia explica como colocar a **ComIA** para rodar no seu próprio domínio sem qualquer erro de conectividade.

---

## 🛠️ O que foi corrigido para eliminar o "Erro de conectividade com o servidor"

1. **Motor Autônomo Resiliente (Client-Side Failover):**
   - Anteriormente, quando o frontend não conseguia alcançar o servidor `/api/chat` (por exemplo, ao subir apenas os arquivos estáticos para uma hospedagem comum ou quando o Node.js estava desligado), o app exibia a mensagem *"Ocorreu uma instabilidade na conexão com o servidor"*.
   - **Agora:** O sistema possui um motor autônomo integrado (`comiaEngine.ts` e `api.ts`). Se a conexão com a API sofrer qualquer indisponibilidade, o aplicativo assume o atendimento instantaneamente, respondendo com o catálogo oficial das 4 frentes estratégicas, diagnósticos N1, configurações de e-mail e triagem sem falhar!

2. **Suporte a Variáveis de Ambiente e CORS Aberto:**
   - Adicionamos middleware de **CORS (Cross-Origin Resource Sharing)** no `server.ts` para que você possa hospedar o backend em um subdomínio (ex: `api.combr.com.br`) e o frontend no domínio principal sem bloqueios do navegador.
   - Suporte a `process.env.PORT` dinâmico (necessário para cPanel Node.js App, VPS, Docker e Cloud Run).
   - Suporte a `VITE_API_URL`: configure a URL da sua API se ela estiver em host separado.

3. **Resiliência no Registro de Chamados (Triagem N2, Comercial e Financeiro):**
   - Caso o backend esteja offline, os chamados são gerados e persistidos localmente com protocolo único formal (`CBR-N2-...`, `CBR-COM-...`, `CBR-FIN-...`), emitindo confetes e mantendo a lista de chamados ativa!

---

## 🚀 Como Hospedar no seu Domínio

Você pode escolher o método que melhor atende a sua infraestrutura:

### Opção 1: Servidor Full-Stack Node.js (Recomendado - VPS, cPanel Node.js, Docker)

Essa opção roda tanto o assistente com IA generativa (Gemini) quanto a persistência centralizada de chamados.

1. **Pré-requisito:** Node.js 18+ ou 20+ instalado.
2. **Instalar as dependências:**
   ```bash
   npm install
   ```
3. **Configurar o arquivo `.env`:**
   Crie ou edite o arquivo `.env` na raiz do projeto:
   ```env
   GEMINI_API_KEY=sua_chave_aqui
   PORT=3000
   ```
4. **Gerar o build de produção:**
   ```bash
   npm run build
   ```
   *Isso compilará o frontend para a pasta `dist/` e o servidor para `dist/server.cjs`.*
5. **Iniciar a aplicação:**
   ```bash
   npm start
   ```
   *(Ou usando PM2 para manter rodando 24x7: `pm2 start dist/server.cjs --name comia`)*

6. **Configurar Nginx (Reverse Proxy):**
   Se você usa Nginx no seu domínio (ex: `https://atendimento.combr.com.br`):
   ```nginx
   server {
       listen 80;
       server_name atendimento.combr.com.br;

       location / {
           proxy_pass http://127.0.0.1:3000;
           proxy_http_version 1.1;
           proxy_set_header Upgrade $http_upgrade;
           proxy_set_header Connection 'upgrade';
           proxy_set_header Host $host;
           proxy_cache_bypass $http_upgrade;
       }
   }
   ```

---

### Opção 2: Hospedagem Estática Simples (cPanel `public_html`, Apache, Nginx estático)

Se a sua hospedagem não suporta Node.js e você deseja apenas colocar os arquivos no ar:

1. No seu computador, execute:
   ```bash
   npm install
   npm run build
   ```
2. Pegue todos os arquivos e pastas gerados dentro da pasta **`dist/`** (ex: `index.html`, pasta `assets/`, etc.).
3. Envie o conteúdo de `dist/` para a pasta raiz da sua hospedagem (ex: `public_html`).
4. **Pronto!** Graças ao motor autônomo ComIA, o assistente funcionará com respostas completas de suporte, catálogo, dados técnicos e abertura de chamados, sem erros de tela.

---

### Opção 3: Frontend e Backend Separados

Caso queira hospedar o frontend na Vercel/Netlify/S3 e o backend Node.js em uma VPS:

1. No frontend, antes de rodar `npm run build`, configure no `.env`:
   ```env
   VITE_API_URL=https://api.combr.com.br
   ```
2. No backend da VPS, rode normalmente com `npm start`. O CORS configurado no `server.ts` aceitará as requisições com segurança.

---

## 🔍 Testando a Conectividade

Você pode testar a saúde da API acessando no navegador ou via cURL:
```bash
curl https://seu-dominio.com.br/api/health
```
Resposta esperada:
```json
{
  "status": "ok",
  "service": "ComIA Virtual Assistant",
  "environment": "production"
}
```
