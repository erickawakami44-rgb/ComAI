import express from "express";
import http from "http";
import path from "path";
import fs from "fs";
import { WebSocketServer, WebSocket } from "ws";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";
import { generateClientComIaResponse } from "./src/lib/comiaEngine";

dotenv.config();

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

// CORS configuration for custom domain hosting & API consumers
app.use((req, res, next) => {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, PATCH, OPTIONS");
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept, Authorization");
  if (req.method === "OPTIONS") {
    return res.sendStatus(200);
  }
  next();
});

app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ extended: true, limit: "50mb" }));

// Server health check
app.get("/api/health", (_req, res) => {
  res.json({
    status: "ok",
    service: "ComIA Virtual Assistant",
    environment: process.env.NODE_ENV || "development",
    timestamp: new Date().toISOString(),
  });
});

// Download ZIP of project
app.get(["/combr-comia-app.zip", "/api/download-zip"], (_req, res) => {
  const rootZip = path.join(process.cwd(), "combr-comia-app.zip");
  const publicZip = path.join(process.cwd(), "public", "combr-comia-app.zip");
  const targetZip = fs.existsSync(rootZip) ? rootZip : publicZip;

  if (fs.existsSync(targetZip)) {
    const fileStat = fs.statSync(targetZip);
    res.writeHead(200, {
      "Content-Type": "application/zip",
      "Content-Disposition": 'attachment; filename="combr-comia-app.zip"',
      "Content-Length": fileStat.size,
      "Cache-Control": "no-cache, no-store, must-revalidate",
      "Pragma": "no-cache",
      "Expires": "0",
      "Access-Control-Allow-Origin": "*",
    });
    const readStream = fs.createReadStream(targetZip);
    readStream.pipe(res);
  } else {
    res.status(404).json({ error: "Arquivo zip não encontrado" });
  }
});

// Download ZIP as Base64 JSON
app.get("/api/download-zip-base64", (_req, res) => {
  const rootZip = path.join(process.cwd(), "combr-comia-app.zip");
  const publicZip = path.join(process.cwd(), "public", "combr-comia-app.zip");
  const targetZip = fs.existsSync(rootZip) ? rootZip : publicZip;

  if (fs.existsSync(targetZip)) {
    const fileBuffer = fs.readFileSync(targetZip);
    res.json({
      filename: "combr-comia-app.zip",
      size: fileBuffer.length,
      base64: fileBuffer.toString("base64"),
    });
  } else {
    res.status(404).json({ error: "Arquivo zip não encontrado" });
  }
});

// Persistent Storage for Triage Tickets
interface StoredTicket {
  id: string;
  type: "support_n2" | "commercial" | "financial";
  domain?: string;
  cnpjOrCorporateName?: string;
  companyName?: string;
  contactName?: string;
  phone?: string;
  email?: string;
  subject: string;
  affectedEmail?: string;
  errorMessage?: string;
  approxAccountsOrResources?: string;
  attachmentImage?: {
    url: string;
    fileName?: string;
    caption?: string;
    size?: string;
  };
  attachmentDocument?: {
    name: string;
    size: string;
    type: string;
    url?: string;
  };
  status: "not_started" | "in_progress" | "completed" | "cancelled";
  createdAt: string;
  updatedAt?: string;
}

const DATA_DIR = path.join(process.cwd(), "data");
const TICKETS_FILE = path.join(DATA_DIR, "tickets.json");
const DELETED_TICKETS_FILE = path.join(DATA_DIR, "deleted_tickets.json");
const LIVE_SESSION_FILE = path.join(DATA_DIR, "live_session.json");

function ensureDataDir() {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
  } catch (err) {
    console.warn("[DataDir] Error ensuring data directory:", err);
  }
}

// Live Session Type & Store
interface StoredLiveSession {
  id: string;
  mode: "bot" | "human";
  status?: "active" | "in_progress" | "finished";
  assignedAgent: {
    name: string;
    role: string;
    email?: string;
  } | null;
  clientInfo: {
    name: string;
    phone: string;
    company?: string;
    online: boolean;
  };
  messages: any[];
  unreadCountForAgent: number;
  internalNotes?: Array<{
    id: string;
    author: string;
    text: string;
    timestamp: string;
  }>;
  createdAt: string;
  updatedAt: string;
  finishedAt?: string;
  awaitingRating?: boolean;
  rating?: {
    stars: number;
    tags?: string[];
    comment?: string;
    clientName?: string;
    ratedAt: string;
  };
}

function loadLiveSessionFromDisk(): StoredLiveSession {
  try {
    ensureDataDir();
    if (fs.existsSync(LIVE_SESSION_FILE)) {
      const raw = fs.readFileSync(LIVE_SESSION_FILE, "utf-8");
      const data = JSON.parse(raw);
      if (data && data.id) {
        return data;
      }
    }
  } catch (err) {
    console.warn("[LiveSession] Failed to load live session:", err);
  }

  return {
    id: "session-main",
    mode: "bot",
    assignedAgent: null,
    clientInfo: {
      name: "Cliente ComBR (Empresa Conectada)",
      phone: "+55 (14) 99895-1113",
      company: "Sua Empresa",
      online: true,
    },
    messages: [],
    unreadCountForAgent: 0,
    internalNotes: [],
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
}

let liveSession: StoredLiveSession = loadLiveSessionFromDisk();

function saveLiveSessionToDisk() {
  try {
    ensureDataDir();
    fs.writeFileSync(LIVE_SESSION_FILE, JSON.stringify(liveSession, null, 2), "utf-8");
  } catch (err) {
    console.error("[LiveSession] Failed to save live session:", err);
  }
}

// Reference to WebSocket broadcast function initialized in startServer
let broadcastWs: (data: any, excludeWs?: WebSocket) => void = () => {};

function loadDeletedTicketIds(): Set<string> {
  try {
    ensureDataDir();
    if (fs.existsSync(DELETED_TICKETS_FILE)) {
      const raw = fs.readFileSync(DELETED_TICKETS_FILE, "utf-8");
      const list = JSON.parse(raw);
      if (Array.isArray(list)) {
        return new Set(list.filter((id) => typeof id === "string" && id.trim().length > 0));
      }
    }
  } catch (err) {
    console.warn("[Tickets] Failed to read deleted tickets file:", err);
  }
  return new Set<string>();
}

const deletedTicketIds: Set<string> = loadDeletedTicketIds();

function persistDeletedTicketId(id: string) {
  try {
    ensureDataDir();
    deletedTicketIds.add(id);
    fs.writeFileSync(
      DELETED_TICKETS_FILE,
      JSON.stringify(Array.from(deletedTicketIds), null, 2),
      "utf-8"
    );
  } catch (err) {
    console.error("[Tickets] Failed to save deleted tickets file:", err);
  }
}

const DEFAULT_INITIAL_TICKETS: StoredTicket[] = [
  {
    id: "CBR-N2-LK4M9A-312",
    type: "support_n2",
    domain: "empresaexemplo.com.br",
    affectedEmail: "contato@empresaexemplo.com.br",
    subject: "Falha de autenticação IMAP e análise de bloqueio",
    errorMessage: "535 Authentication credentials invalid / IP temporary blacklist",
    status: "not_started",
    createdAt: new Date(Date.now() - 1000 * 60 * 35).toISOString(),
  },
  {
    id: "CBR-COM-LK4J82-749",
    type: "commercial",
    cnpjOrCorporateName: "Inovação Tech Ltda",
    companyName: "Inovação Tech",
    contactName: "Mariana Souza",
    phone: "(11) 98765-4321",
    email: "mariana@inovacaotech.com.br",
    subject: "Cotação sob medida: E-mail Híbrido + SaveData em Nuvem",
    approxAccountsOrResources: "35 caixas corporativas + 500GB SaveData",
    status: "in_progress",
    createdAt: new Date(Date.now() - 1000 * 60 * 120).toISOString(),
  },
];

function loadTicketsFromDisk(): StoredTicket[] {
  try {
    ensureDataDir();
    if (fs.existsSync(TICKETS_FILE)) {
      const raw = fs.readFileSync(TICKETS_FILE, "utf-8");
      const list = JSON.parse(raw);
      if (Array.isArray(list)) {
        return list.filter((t) => t && t.id && !deletedTicketIds.has(t.id));
      }
    }
  } catch (err) {
    console.warn("[Tickets] Failed to read tickets from file:", err);
  }

  const initial = DEFAULT_INITIAL_TICKETS.filter((t) => !deletedTicketIds.has(t.id));
  saveTicketsToDisk(initial);
  return initial;
}

function saveTicketsToDisk(tickets: StoredTicket[]) {
  try {
    ensureDataDir();
    const cleanTickets = tickets.filter((t) => t && t.id && !deletedTicketIds.has(t.id));
    fs.writeFileSync(TICKETS_FILE, JSON.stringify(cleanTickets, null, 2), "utf-8");
  } catch (err) {
    console.error("[Tickets] Failed to save tickets to file:", err);
  }
}

let triageTickets: StoredTicket[] = loadTicketsFromDisk();

function getGeminiClient(): GoogleGenAI | null {
  const apiKey =
    process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY !== "MY_GEMINI_API_KEY"
      ? process.env.GEMINI_API_KEY.trim()
      : "AQ.Ab8RN6L-SiYRX9DvGQjvQ0cpIN-U0Ac1ucFcPRciGiiyfPZ1dg";

  if (!apiKey) return null;
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
}

function buildSystemInstruction(): string {
  const now = new Date();
  const dataExtenso = now.toLocaleDateString("pt-BR", {
    timeZone: "America/Sao_Paulo",
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
  });
  const horaAtual = now.toLocaleTimeString("pt-BR", {
    timeZone: "America/Sao_Paulo",
    hour: "2-digit",
    minute: "2-digit",
  });

  return `# CONTEXTO TEMPORAL
- Data atual: ${dataExtenso}
- Horário atual oficial: ${horaAtual} (Horário de Brasília/SP)
- Somente informe o horário ou a data caso o usuário pergunte explicitamente sobre que horas são ou que dia é hoje. Em outras mensagens, não adicione a data ou a hora no final.

# RESTRICÃO FUNDAMENTAL DE ESCOPO (EXCLUSIVIDADE COMBR SOLUÇÕES EM NUVEM)
- VOCÊ DEVE RESPONDER EXCLUSIVAMENTE SOBRE A EMPRESA COMBR SOLUÇÕES EM NUVEM, SEUS SERVIÇOS, PRODUTOS, INFRAESTRUTURA, E-MAILS, SUPORTE TÉCNICO, CONTATO OU ATENDIMENTO.
- Caso o usuário pergunte sobre QUALQUER assunto que NÃO seja da empresa, dos seus serviços, de infraestrutura em nuvem/e-mails da ComBr ou de suporte (por exemplo: receitas culinárias, piadas, futebol, esportes, política, fofocas, matemática escolar, curiosidades gerais, poemas, outras empresas de fora, etc.):
  • Responda de forma educada, gentil, polida e profissional informando que seu atendimento é exclusivo para assuntos e soluções da ComBr Soluções em Nuvem.
  • Exemplo de resposta para temas fora do escopo:
    "Como assistente virtual da **ComBr Soluções em Nuvem**, meu atendimento é exclusivo para informações sobre nossos serviços, infraestrutura de servidores (Cloud AWS & Oracle, VPS Linux), e-mail corporativo, backup SaveData e suporte técnico. Caso necessite de auxílio com alguma de nossas soluções ou queira falar com nossa equipe, estou à disposição!"
  • Nunca responda ao assunto alheio (não dê a receita, não conte a piada, não responda ao tema fora de escopo). Apenas recuse com gentileza e oriente sobre a ComBr.

# IDENTIDADE E PAPEL
Você é a ComIA, assistente virtual corporativa da ComBr Soluções em Nuvem.
Sua comunicação deve ser estritamente profissional, segura, polida, clara e objetiva.

# DIRETRIZES DE ESTILO E LINGUAGEM (PROFISSIONALISMO)
1. **Tom Corporativo e Polido:**
   - Adote linguagem formal, cordial e assertiva em português do Brasil (norma culta moderna).
   - Evite gírias, expressões excessivamente coloquiais e excesso de emojis. Use no máximo um emoji discreto e contextual quando estritamente adequado, ou nenhum.
   - Seja direto e resolutivo: entregue a resposta ou solução logo no início da mensagem, sem rodeios ou introduções vazias.
   - NUNCA repita ou parafraseie a pergunta do usuário na primeira linha (não use "Em relação ao que você perguntou", "Você perguntou sobre", "Quanto à sua dúvida", etc.).

2. **Formatação e Legibilidade Executiva:**
   - Organize explicações complexas com tópicos limpos (bullet points) e destaque termos técnicos ou pontos centrais em **negrito**.
   - Para códigos ou configurações de servidores/e-mails, utilize blocos devidamente formatados.
   - Priorize síntese com alta densidade de informação útil.

# BASE DE CONHECIMENTO INSTITUCIONAL (COMBR SOLUÇÕES EM NUVEM)
Quando o usuário solicitar informações sobre a empresa, cotações, serviços ou suporte técnico:
- **Institucional:** A ComBr atua há mais de 25 anos em infraestrutura de tecnologia de missão crítica, telecomunicações e computação em nuvem corporativa (B2B). Sede em Marília – SP (Av. Ipiranga, 85 – Sala 91). Portais oficiais: combr.com.br e combremail.com.br.
- **Portfólio de Soluções:**
  • **Cloud AWS & Oracle Cloud (OCI):** Ambientes corporativos dedicados com SLA de 99,9% para ERPs (Totvs Protheus, RM, Datasul, SAP, Senior) e bancos de alta concorrência. Faturamento nacional em Real (BRL) com valor fixo e previsível em nota fiscal (sem variação cambial do dólar e sem IOF).
  • **VPS Linux Gerenciada:** Servidores virtuais dedicados com armazenamento NVMe, sustentação completa, monitoramento contínuo NOC 24x7 e rotinas automatizadas de backup.
  • **E-mail Corporativo e Híbrido:** Integração estratégica no mesmo domínio (@suaempresa.com.br) combinando contas corporativas ComBr com licenças de Microsoft 365 ou Google Workspace, permitindo redução de até 70% nos custos de licenciamento.
  • **SMTP Envios Empresarial:** Infraestrutura de relay dedicada para emissão de notas fiscais (NF-e, NFS-e, CT-e) e envios transacionais de ERPs com entregabilidade garantida, IPs aquecidos e conformidade com SPF, DKIM e DMARC.
  • **SaveData:** Solução corporativa de backup em nuvem em datacenters Tier III com criptografia AES-256 e proteção imutável contra ataques de ransomware.
  • **SaveMail:** Arquivamento e auditoria contínua de tráfego de e-mails para compliance com a LGPD e respaldo jurídico.
  • **Consultoria DBA:** Administração e tuning de performance em bancos de dados relacionais Oracle Database e MySQL.
- **Parâmetros Oficiais de E-mail:**
  • IMAP: \`imap.combr.com.br\` (Porta 993, SSL/TLS)
  • POP3: \`pop.combr.com.br\` (Porta 995, SSL/TLS)
  • SMTP: \`smtp.combr.com.br\` (Porta 465 com SSL/TLS ou Porta 587 com STARTTLS)
  • Webmail: https://webmail.combr.com.br
- **Canais de Contato:**
  • Central: (14) 3333-1150
  • Suporte Técnico Especializado: WhatsApp (14) 99895-1113 | suporte@combr.com.br
  • Comercial (Propostas e Novos Projetos): WhatsApp (14) 98170-0888 | comercial@combr.com.br
  • Financeiro (Faturamento e Boletos): WhatsApp (14) 99851-1113 | financeiro@combr.com.br
- **Interação com os Botões de Ação na Tela (MANDATÓRIO):**
  • O chat do WhatsApp já exibe automaticamente botões clicáveis logo abaixo da mensagem: **[Enviar para o Comercial]**, **[Enviar para o Financeiro]** e **[Falar com Suporte Técnico]**.
  • Portanto, NUNCA fique colando parágrafos longos com números de telefone, e-mails de contato ou textos repetitivos como "nossa equipe Comercial está à disposição pelo WhatsApp...".
  • Quando o assunto envolver contratação, propostas, dúvidas financeiras ou chamados técnicos, instrua o usuário de forma super curta, natural e direta apontando para os botões abaixo. Exemplo:
    *"Para dar andamento à contratação ou suporte, basta clicar no botão desejado logo abaixo."*
  • Jamais inclua esse direcionamento quando a pergunta for simples (como que horas são, perguntas gerais, cálculos matemáticos ou dúvidas conceituais).`;
}

function detectGreetingAndReply(prompt: string): string | null {
  const lower = prompt.toLowerCase().trim();
  const clean = lower
    .replace(/[^\w\s\u00C0-\u00FF]/g, " ")
    .replace(/\s+/g, " ")
    .trim();

  const isGreeting =
    /^(oi|ol[aá]|opa|ei|salve|hello|hi|e a[ií])(\s+(comia|combr|amigo|amiga|equipe|time|pessoal))?(\s+(bom dia|boa tarde|boa noite))?(\s+(tudo bem|tudo bom|como vai|como voc[eê] est[aá]|beleza|tranquilo))?$/i.test(clean) ||
    /^(bom dia|boa tarde|boa noite)(\s+(comia|combr|amigo|amiga|equipe|time|pessoal))?(\s+(tudo bem|tudo bom|como vai|como voc[eê] est[aá]|beleza|tranquilo))?$/i.test(clean) ||
    /^(tudo bem|tudo bom|como vai|como voc[eê] est[aá]|beleza)(\s+com\s+voc[eê])?$/i.test(clean);

  if (!isGreeting) return null;

  const hasBoaNoite = /boa noite/i.test(clean);
  const hasBoaTarde = /boa tarde/i.test(clean);
  const hasBomDia = /bom dia/i.test(clean);
  const askedTudoBem = /tudo bem|tudo bom|como vai|como voc[eê] est[aá]|beleza|tranquilo/i.test(clean);

  let greetingWord = "Olá";
  if (hasBoaNoite) {
    greetingWord = "Boa noite";
  } else if (hasBoaTarde) {
    greetingWord = "Boa tarde";
  } else if (hasBomDia) {
    greetingWord = "Bom dia";
  } else {
    // Caso o usuário diga apenas "oi", "olá", "tudo bem?", responde com a saudação de acordo com o horário exato de Brasília
    const now = new Date();
    const currentHourStr = now.toLocaleTimeString("pt-BR", {
      timeZone: "America/Sao_Paulo",
      hour: "2-digit",
      hour12: false,
    });
    const currentHour = parseInt(currentHourStr, 10);
    if (currentHour >= 5 && currentHour < 12) {
      greetingWord = "Bom dia";
    } else if (currentHour >= 12 && currentHour < 18) {
      greetingWord = "Boa tarde";
    } else {
      greetingWord = "Boa noite";
    }
  }

  if (askedTudoBem) {
    return `${greetingWord}. Tudo bem por aqui, obrigado por perguntar. Sou a ComIA, assistente virtual da ComBr Soluções em Nuvem. Em que posso auxiliá-lo hoje?`;
  }
  return `${greetingWord}. Sou a ComIA, assistente virtual da ComBr Soluções em Nuvem. Como posso auxiliá-lo hoje?`;
}

// Lista ordenada de modelos para contingência e alta disponibilidade
const CANDIDATE_MODELS = [
  "gemini-3.1-flash-lite", // Modelo oficial primário: alta velocidade, excelente raciocínio e alta cota disponível
  "gemini-3.8-flash",      // Modelo secundário oficial
  "gemini-flash-latest",   // Fallback universal
];

async function generateAiReply(
  ai: GoogleGenAI,
  contents: any[],
  systemInstruction: string
): Promise<{ text: string | null; modelUsed: string }> {
  for (const model of CANDIDATE_MODELS) {
    try {
      const response = await ai.models.generateContent({
        model,
        contents,
        config: {
          systemInstruction,
          temperature: 0.7,
        },
      });
      if (response && response.text && response.text.trim().length > 0) {
        return { text: response.text.trim(), modelUsed: model };
      }
    } catch (err: any) {
      const errMsg = String(err?.message || "");
      console.warn(`[Gemini SDK] Modelo ${model} falhou:`, err?.status || err?.code, errMsg.slice(0, 120));
      // Se for quota esgotada (resource_exhausted), não trava esperando retry e usa o motor inteligente ComBR
      if (errMsg.includes("resource_exhausted") || errMsg.includes("quota")) {
        console.info("[Gemini SDK] Cota de API excedida temporariamente. Ativando base de conhecimento inteligente autônoma ComBR.");
        break;
      }
      // Se for rate limit transitório (429), aguarda 800ms e tenta novamente
      if (err?.status === 429 || errMsg.includes("429")) {
        await new Promise((resolve) => setTimeout(resolve, 850));
        try {
          const retryRes = await ai.models.generateContent({
            model,
            contents,
            config: {
              systemInstruction,
              temperature: 0.7,
            },
          });
          if (retryRes && retryRes.text && retryRes.text.trim().length > 0) {
            return { text: retryRes.text.trim(), modelUsed: `${model}-retry` };
          }
        } catch (_) {}
      }
    }
  }

  // Se o histórico multiturn continha algum formato incompatível, tenta chamada direta somente com o último turno
  const lastTurn = contents[contents.length - 1];
  if (lastTurn && contents.length > 1) {
    for (const model of CANDIDATE_MODELS) {
      try {
        const response = await ai.models.generateContent({
          model,
          contents: [lastTurn],
          config: {
            systemInstruction,
            temperature: 0.7,
          },
        });
        if (response && response.text && response.text.trim().length > 0) {
          return { text: response.text.trim(), modelUsed: `${model}-direct` };
        }
      } catch (directErr: any) {
        console.warn(`[Gemini SDK Direct] Modelo ${model} falhou:`, directErr?.status || directErr?.code);
      }
    }
  }

  return { text: null, modelUsed: "fallback" };
}

// Endpoint de Chat
app.post("/api/chat", async (req, res) => {
  try {
    const { message, history, image, audio, document } = req.body;
    if ((!message || typeof message !== "string") && !image && !audio && !document) {
      res.status(400).json({ error: "Mensagem obrigatória" });
      return;
    }

    const safeMessage = message || "";

    // 1. Saudação inicial rápida
    const greeting = detectGreetingAndReply(safeMessage);
    if (greeting && !image && !audio && !document) {
      res.json({ reply: greeting, source: "greeting-engine" });
      return;
    }

    // 2. Horário e data em tempo real imediatos
    if (/hor[aá]rio|que\s+horas?|qual\s+a\s+hora|data\s+de\s+hoje|que\s+dia\s+[eé]\s+hoje/i.test(safeMessage)) {
      const now = new Date();
      const horaFormatada = now.toLocaleTimeString("pt-BR", {
        timeZone: "America/Sao_Paulo",
        hour: "2-digit",
        minute: "2-digit",
      });
      const dataFormatada = now.toLocaleDateString("pt-BR", {
        timeZone: "America/Sao_Paulo",
        weekday: "long",
        day: "numeric",
        month: "long",
        year: "numeric",
      });

      res.json({
        reply: `Agora são **${horaFormatada}** (${dataFormatada}). Como posso auxiliá-lo?`,
        source: "system-clock",
      });
      return;
    }

    const ai = getGeminiClient();
    if (!ai) {
      res.json({
        reply: "Não foi possível estabelecer conexão com o serviço de inteligência artificial no momento. Por favor, verifique a chave de API nos Secrets do sistema.",
        source: "error-no-client",
      });
      return;
    }

    const currentInstruction = buildSystemInstruction();

    // Monta as partes da mensagem do usuário (texto + imagem/áudio/documento se houver)
    const userParts: any[] = [];

    if (image?.dataUrl) {
      let mimeType = "image/jpeg";
      let base64Data = image.dataUrl;
      if (base64Data.startsWith("data:")) {
        const match = base64Data.match(/^data:([^;]+);base64,(.+)$/);
        if (match) {
          mimeType = match[1];
          base64Data = match[2];
        }
      }
      userParts.push({
        inlineData: {
          mimeType,
          data: base64Data,
        },
      });
    }

    if (document?.dataBase64 || (document?.dataUrl && document.dataUrl.startsWith("data:"))) {
      let mimeType = document.mimeType || "application/pdf";
      let base64Data = document.dataBase64 || document.dataUrl || "";
      if (base64Data.startsWith("data:")) {
        const match = base64Data.match(/^data:([^;]+);base64,(.+)$/);
        if (match) {
          mimeType = match[1];
          base64Data = match[2];
        }
      }
      userParts.push({
        inlineData: {
          mimeType,
          data: base64Data,
        },
      });
    } else if (document?.textContent) {
      userParts.push({
        text: `[Documento anexado: ${document.name || "arquivo"}]:\n${document.textContent.slice(0, 6000)}`,
      });
    }

    if (audio?.dataBase64 || (audio?.dataUrl && audio.dataUrl.startsWith("data:"))) {
      let mimeType = audio.mimeType || "audio/webm";
      let base64Data = audio.dataBase64 || audio.dataUrl || "";
      if (base64Data.startsWith("data:")) {
        const match = base64Data.match(/^data:([^;]+);base64,(.+)$/);
        if (match) {
          mimeType = match[1];
          base64Data = match[2];
        }
      }
      userParts.push({
        inlineData: {
          mimeType,
          data: base64Data,
        },
      });
    }

    if (safeMessage) {
      userParts.push({ text: safeMessage });
    } else if (userParts.length === 0) {
      userParts.push({ text: "Olá" });
    }

    // Histórico de conversação limpo
    const contents: any[] = [];
    if (Array.isArray(history)) {
      for (const h of history) {
        if (!h || !h.content || typeof h.content !== "string") continue;
        const trimmed = h.content.trim();
        if (!trimmed) continue;
        if (h.role !== "assistant" && trimmed === safeMessage.trim()) continue;

        const role = h.role === "assistant" ? "model" : "user";
        contents.push({
          role,
          parts: [{ text: trimmed }],
        });
      }
    }

    while (contents.length > 0 && contents[0].role === "model") {
      contents.shift();
    }
    if (contents.length > 0 && contents[contents.length - 1].role === "user") {
      contents.pop();
    }

    contents.push({
      role: "user",
      parts: userParts,
    });

    const { text: aiReply, modelUsed } = await generateAiReply(ai, contents, currentInstruction);

    if (aiReply && aiReply.trim().length > 0) {
      res.json({
        reply: aiReply,
        source: modelUsed,
      });
      return;
    }

    // Caso o modelo retorne vazio ou haja oscilação transitória, utiliza a base de conhecimento inteligente
    const smartFallback = generateClientComIaResponse(safeMessage);
    res.json({
      reply: smartFallback,
      source: "smart-knowledge-base",
    });
  } catch (error: any) {
    console.error("[ComIA Chat Error]:", error?.message || error);
    const safeMessage = typeof req.body?.message === "string" ? req.body.message : "";
    const smartFallback = safeMessage ? generateClientComIaResponse(safeMessage) : "Estou à disposição para auxiliá-lo. Como posso ajudar com a sua solicitação?";
    res.json({
      reply: smartFallback,
      source: "smart-knowledge-base",
    });
  }
});

// Ticket endpoints
app.post("/api/ticket", (req, res) => {
  try {
    const { type, domain, cnpjOrCorporateName, companyName, contactName, phone, email, subject, affectedEmail, errorMessage, approxAccountsOrResources, status, attachmentImage, attachmentDocument } = req.body;
    const validatedType = type === "support_n2" || type === "financial" ? type : "commercial";
    const typePrefix = validatedType === "support_n2" ? "N2" : validatedType === "financial" ? "FIN" : "COM";
    const validStatus = status === "in_progress" || status === "completed" || status === "cancelled" ? status : "not_started";

    const newTicket: StoredTicket = {
      id: `CBR-${typePrefix}-${Date.now().toString(36).toUpperCase()}-${Math.floor(100 + Math.random() * 900)}`,
      type: validatedType,
      domain: domain?.trim()?.toLowerCase(),
      cnpjOrCorporateName: cnpjOrCorporateName?.trim(),
      companyName: companyName?.trim(),
      contactName: contactName?.trim(),
      phone: phone?.trim(),
      email: email?.trim(),
      subject: subject?.trim() || "Atendimento ComBR Soluções em Nuvem",
      affectedEmail: affectedEmail?.trim(),
      errorMessage: errorMessage?.trim(),
      approxAccountsOrResources: approxAccountsOrResources?.trim(),
      attachmentImage: attachmentImage ? {
        url: attachmentImage.url,
        fileName: attachmentImage.fileName,
        caption: attachmentImage.caption,
        size: attachmentImage.size,
      } : undefined,
      attachmentDocument: attachmentDocument ? {
        name: attachmentDocument.name,
        size: attachmentDocument.size,
        type: attachmentDocument.type,
        url: attachmentDocument.url,
      } : undefined,
      status: validStatus,
      createdAt: new Date().toISOString(),
    };

    triageTickets.unshift(newTicket);
    saveTicketsToDisk(triageTickets);

    res.json({
      success: true,
      ticket: newTicket,
      message: `Protocolo ${newTicket.id} registrado com sucesso.`,
    });
  } catch (error: any) {
    res.status(500).json({ error: "Falha ao registrar chamado." });
  }
});

app.patch("/api/tickets/:id/status", (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;
    const ticketIndex = triageTickets.findIndex((t) => t.id === id);
    if (ticketIndex === -1) {
      res.status(404).json({ error: "Chamado não encontrado." });
      return;
    }
    triageTickets[ticketIndex].status = status;
    triageTickets[ticketIndex].updatedAt = new Date().toISOString();
    saveTicketsToDisk(triageTickets);

    if (liveSession && Array.isArray(liveSession.messages)) {
      liveSession.messages = liveSession.messages.map((m) =>
        m.ticketData && m.ticketData.id === id
          ? { ...m, ticketData: { ...m.ticketData, status } }
          : m
      );
      saveLiveSessionToDisk();
    }

    const cleanTickets = triageTickets.filter((t) => t && t.id && !deletedTicketIds.has(t.id));
    broadcastWs({
      type: "ticket_updated",
      ticketId: id,
      status,
      tickets: cleanTickets,
      session: liveSession,
    });
    res.json({ success: true, ticket: triageTickets[ticketIndex], tickets: cleanTickets });
  } catch (error: any) {
    res.status(500).json({ error: "Falha ao atualizar status." });
  }
});

app.delete("/api/tickets/:id", (req, res) => {
  try {
    const { id } = req.params;
    persistDeletedTicketId(id);
    const ticketIndex = triageTickets.findIndex((t) => t.id === id);
    if (ticketIndex !== -1) {
      triageTickets.splice(ticketIndex, 1);
    }
    saveTicketsToDisk(triageTickets);

    if (liveSession && Array.isArray(liveSession.messages)) {
      liveSession.messages = liveSession.messages.filter((m) =>
        !(m.ticketData && m.ticketData.id === id) &&
        !(typeof m.content === "string" && m.content.includes(id))
      );
      saveLiveSessionToDisk();
    }

    const cleanTickets = triageTickets.filter((t) => t && t.id && !deletedTicketIds.has(t.id));
    broadcastWs({
      type: "ticket_deleted",
      ticketId: id,
      tickets: cleanTickets,
      session: liveSession,
    });
    res.json({ success: true, ticketId: id, tickets: cleanTickets });
  } catch (error: any) {
    res.status(500).json({ error: "Falha ao excluir chamado." });
  }
});

app.post("/api/tickets/sync-deleted", (req, res) => {
  try {
    const { deletedIds } = req.body;
    if (Array.isArray(deletedIds)) {
      for (const id of deletedIds) {
        persistDeletedTicketId(id);
        const idx = triageTickets.findIndex((t) => t.id === id);
        if (idx !== -1) triageTickets.splice(idx, 1);
      }
      saveTicketsToDisk(triageTickets);
    }
    const cleanTickets = triageTickets.filter((t) => t && t.id && !deletedTicketIds.has(t.id));
    res.json({ success: true, tickets: cleanTickets });
  } catch (error: any) {
    res.status(500).json({ error: "Falha ao sincronizar chamados excluídos." });
  }
});

app.get("/api/tickets", (_req, res) => {
  const cleanTickets = triageTickets.filter((t) => t && t.id && !deletedTicketIds.has(t.id));
  res.json({ tickets: cleanTickets.slice(-50) });
});

// Live Session & Dual-Screen Support Endpoints
async function processClientMessage(userMsg: any) {
  if (!userMsg || !userMsg.id) return;

  // Prevent duplicate insertion
  if (!liveSession.messages.some((m) => m.id === userMsg.id)) {
    liveSession.messages.push(userMsg);
    liveSession.updatedAt = new Date().toISOString();
    if (liveSession.mode === "human") {
      liveSession.unreadCountForAgent = (liveSession.unreadCountForAgent || 0) + 1;
    }
    saveLiveSessionToDisk();
  }

  // Broadcast user message to all connected clients & agents
  broadcastWs({
    type: "new_message",
    message: userMsg,
    session: liveSession,
  });

  // If in bot mode, trigger ComIA response
  if (liveSession.mode === "bot") {
    broadcastWs({ type: "typing", who: "comia", isTyping: true });

    try {
      let replyText = "";
      const safeText = userMsg.content || "";

      // 1. Greeting
      const greeting = detectGreetingAndReply(safeText);
      if (greeting && !userMsg.imageAttachment && !userMsg.documentAttachment && !userMsg.isAudio) {
        replyText = greeting;
      } else if (/hor[aá]rio|que\s+horas?|qual\s+a\s+hora|data\s+de\s+hoje|que\s+dia\s+[eé]\s+hoje/i.test(safeText)) {
        const now = new Date();
        const hora = now.toLocaleTimeString("pt-BR", { timeZone: "America/Sao_Paulo", hour: "2-digit", minute: "2-digit" });
        const dataStr = now.toLocaleDateString("pt-BR", { timeZone: "America/Sao_Paulo", weekday: "long", day: "numeric", month: "long", year: "numeric" });
        replyText = `Agora são **${hora}** (${dataStr}). Como posso auxiliá-lo?`;
      } else {
        const ai = getGeminiClient();
        if (ai) {
          const currentInstruction = buildSystemInstruction();
          const contents: any[] = [];
          const recent = liveSession.messages.slice(-8);
          for (const m of recent) {
            if (!m.content) continue;
            contents.push({
              role: m.sender === "assistant" ? "model" : "user",
              parts: [{ text: m.content }],
            });
          }
          while (contents.length > 0 && contents[0].role === "model") contents.shift();
          if (contents.length > 0 && contents[contents.length - 1].role === "user") contents.pop();
          contents.push({
            role: "user",
            parts: [{ text: safeText || "Olá" }],
          });

          const { text: genText } = await generateAiReply(ai, contents, currentInstruction);
          if (genText && genText.trim().length > 0) {
            replyText = genText.trim();
          }
        }

        if (!replyText) {
          replyText = generateClientComIaResponse(safeText);
        }
      }

      const isGreeting = Boolean(detectGreetingAndReply(safeText));
      const isExplicitMenu = /^(menu|opções|opcoes|canais|departamentos|iniciar|ajuda|falar com alguém|falar com atendente|chamado|chamados|abrir chamado)/i.test(safeText.trim());
      const showDepartmentOptions =
        liveSession.mode === "bot" && (
          isGreeting ||
          isExplicitMenu ||
          liveSession.messages.length <= 4 ||
          /botão|botões|clic.*botão|selecion.*botão|abaixo|proposta detalhada|selecione uma das opções abaixo|escolha um dos departamentos|canais de atendimento|opções rápidas de atendimento/i.test(replyText)
        );

      const assistantMsg = {
        id: `assistant-${Date.now()}`,
        sender: "assistant",
        content: replyText,
        timestamp: new Date().toISOString(),
        status: "read",
        showDepartmentOptions,
      };

      liveSession.messages.push(assistantMsg);
      liveSession.updatedAt = new Date().toISOString();
      saveLiveSessionToDisk();

      broadcastWs({
        type: "new_message",
        message: assistantMsg,
        session: liveSession,
      });
    } catch (err) {
      console.error("[Process Client Message Error]:", err);
    } finally {
      broadcastWs({ type: "typing", who: "comia", isTyping: false });
    }
  }
}

app.get("/api/live-session", (_req, res) => {
  res.json({ session: liveSession });
});

app.post("/api/live-session/client-message", async (req, res) => {
  const { message } = req.body;
  if (!message) {
    res.status(400).json({ error: "Mensagem obrigatória" });
    return;
  }
  await processClientMessage(message);
  res.json({ success: true, session: liveSession });
});

app.post("/api/live-session/takeover", (req, res) => {
  const { agentName } = req.body;
  const name = agentName || "Atendente de Suporte N2";
  liveSession.mode = "human";
  liveSession.assignedAgent = {
    name,
    role: "Suporte N2 Especializado",
  };
  liveSession.unreadCountForAgent = 0;
  liveSession.updatedAt = new Date().toISOString();

  const sysMsg = {
    id: `sys-${Date.now()}`,
    sender: "system",
    content: `🧑‍💼 O atendente humano **${name}** assumiu esta conversa. A ComIA foi pausada e agora você está em atendimento direto com nosso time especializado.`,
    timestamp: new Date().toISOString(),
  };

  liveSession.messages.push(sysMsg);
  saveLiveSessionToDisk();

  broadcastWs({
    type: "session_updated",
    session: liveSession,
    systemMessage: sysMsg,
  });

  res.json({ success: true, session: liveSession });
});

app.post("/api/live-session/release", (_req, res) => {
  liveSession.mode = "bot";
  liveSession.assignedAgent = null;
  liveSession.updatedAt = new Date().toISOString();

  const sysMsg = {
    id: `sys-${Date.now()}`,
    sender: "system",
    content: `🤖 O atendimento foi retornado para a assistente virtual **ComIA**. Você pode continuar tirando dúvidas sobre e-mail, servidores ou serviços ComBR a qualquer momento.`,
    timestamp: new Date().toISOString(),
  };

  liveSession.messages.push(sysMsg);
  saveLiveSessionToDisk();

  broadcastWs({
    type: "session_updated",
    session: liveSession,
    systemMessage: sysMsg,
  });

  res.json({ success: true, session: liveSession });
});

// Finalizar Atendimento e solicitar avaliação do cliente
app.post("/api/live-session/finish", (req, res) => {
  const { agentName, ticketId } = req.body;
  const name = agentName || liveSession.assignedAgent?.name || "Erick (Suporte N2)";

  liveSession.status = "finished";
  liveSession.finishedAt = new Date().toISOString();
  liveSession.awaitingRating = true;
  liveSession.mode = "bot";
  liveSession.assignedAgent = null;

  // Se houver ticketId, atualiza o status do chamado para concluído
  if (ticketId) {
    const t = triageTickets.find((item) => item.id === ticketId);
    if (t) {
      t.status = "completed";
      t.updatedAt = new Date().toISOString();
      saveTicketsToDisk(triageTickets);
      broadcastWs({
        type: "ticket_updated",
        ticket: t,
        tickets: triageTickets.filter((item) => item && item.id && !deletedTicketIds.has(item.id)),
      });
    }
  }

  // Mensagem do sistema informando finalização
  const closeMsg = {
    id: `sys-${Date.now()}`,
    sender: "system",
    content: `✅ O atendimento foi finalizado por **${name}**. Agradecemos pela sua preferência e confiança na ComBR Soluções em Nuvem!`,
    timestamp: new Date().toISOString(),
  };
  liveSession.messages.push(closeMsg);

  // Solicitação interativa de avaliação para o cliente
  const ratingPromptMsg = {
    id: `rating-${Date.now()}`,
    sender: "assistant",
    content: `⭐ **Avaliação de Atendimento**\nSua opinião é fundamental para mantermos a excelência do nosso suporte! Como você avalia o atendimento que acabou de receber de **${name}**?`,
    timestamp: new Date().toISOString(),
    status: "read",
    showRatingCard: true,
  };
  liveSession.messages.push(ratingPromptMsg);

  liveSession.updatedAt = new Date().toISOString();
  saveLiveSessionToDisk();

  broadcastWs({
    type: "attendance_finished",
    session: liveSession,
    agentName: name,
    ticketId,
  });

  res.json({ success: true, session: liveSession });
});

// Receber avaliação enviada pelo cliente
app.post("/api/live-session/rate", (req, res) => {
  const { stars, tags, comment, clientName } = req.body;
  const numStars = Math.min(5, Math.max(1, Number(stars) || 5));

  const ratingData = {
    stars: numStars,
    tags: Array.isArray(tags) ? tags : [],
    comment: typeof comment === "string" ? comment.trim() : "",
    clientName: clientName || liveSession.clientInfo?.name || "Cliente",
    ratedAt: new Date().toISOString(),
  };

  liveSession.rating = ratingData;
  liveSession.awaitingRating = false;

  const starIcons = "⭐".repeat(numStars);
  const thankMsg = {
    id: `rating-thank-${Date.now()}`,
    sender: "assistant",
    content: `🙏 **Muito obrigado pela sua avaliação!**\nNota registrada: ${starIcons} (${numStars}/5 estrelas)${
      ratingData.comment ? `\n\n*"${ratingData.comment}"*` : ""
    }\n\nSua opinião nos ajuda a aprimorar continuamente nossos serviços de suporte e infraestrutura. Conte sempre com a ComBR Soluções em Nuvem!`,
    timestamp: new Date().toISOString(),
    status: "read",
    ratingData,
  };

  liveSession.messages.push(thankMsg);
  liveSession.updatedAt = new Date().toISOString();
  saveLiveSessionToDisk();

  broadcastWs({
    type: "session_rated",
    session: liveSession,
    rating: ratingData,
  });

  res.json({ success: true, rating: ratingData, session: liveSession });
});

app.post("/api/live-session/agent-message", (req, res) => {
  const { content, agentName } = req.body;
  if (!content || typeof content !== "string") {
    res.status(400).json({ error: "Mensagem obrigatória" });
    return;
  }

  const name = agentName || liveSession.assignedAgent?.name || "Suporte ComBR";
  const agentMsg = {
    id: `agent-${Date.now()}`,
    sender: "assistant",
    isHumanAgent: true,
    agentName: name,
    agentRole: "Suporte Técnico N2",
    content,
    timestamp: new Date().toISOString(),
    status: "read",
  };

  liveSession.messages.push(agentMsg);
  liveSession.unreadCountForAgent = 0;
  liveSession.updatedAt = new Date().toISOString();
  saveLiveSessionToDisk();

  broadcastWs({
    type: "new_message",
    message: agentMsg,
    session: liveSession,
  });

  res.json({ success: true, message: agentMsg, session: liveSession });
});

app.post("/api/live-session/reset", (_req, res) => {
  liveSession.messages = [];
  liveSession.mode = "bot";
  liveSession.assignedAgent = null;
  liveSession.unreadCountForAgent = 0;
  liveSession.internalNotes = [];
  liveSession.updatedAt = new Date().toISOString();
  saveLiveSessionToDisk();

  broadcastWs({
    type: "chat_reset",
    session: liveSession,
  });

  res.json({ success: true, session: liveSession });
});

app.post("/api/live-session/note", (req, res) => {
  const { text, author } = req.body;
  if (!text) {
    res.status(400).json({ error: "Texto da nota é obrigatório" });
    return;
  }
  if (!liveSession.internalNotes) liveSession.internalNotes = [];
  const note = {
    id: `note-${Date.now()}`,
    author: author || "Suporte N2",
    text,
    timestamp: new Date().toISOString(),
  };
  liveSession.internalNotes.push(note);
  saveLiveSessionToDisk();

  broadcastWs({
    type: "session_updated",
    session: liveSession,
  });

  res.json({ success: true, note, session: liveSession });
});

async function startServer() {
  const server = http.createServer(app);
  const wss = new WebSocketServer({ server });

  broadcastWs = (data: any, excludeWs?: WebSocket) => {
    const payload = JSON.stringify(data);
    wss.clients.forEach((client) => {
      if (client.readyState === WebSocket.OPEN && client !== excludeWs) {
        try {
          client.send(payload);
        } catch (_) {}
      }
    });
  };

  wss.on("connection", (ws: WebSocket) => {
    // Send initial sync on connection
    try {
      ws.send(
        JSON.stringify({
          type: "sync",
          session: liveSession,
          tickets: triageTickets.filter((t) => t && t.id && !deletedTicketIds.has(t.id)),
        })
      );
    } catch (_) {}

    ws.on("message", async (dataRaw: any) => {
      try {
        const data = JSON.parse(dataRaw.toString());
        if (!data || !data.type) return;

        switch (data.type) {
          case "sync_request":
          case "init": {
            ws.send(
              JSON.stringify({
                type: "sync",
                session: liveSession,
                tickets: triageTickets.filter((t) => t && t.id && !deletedTicketIds.has(t.id)),
              })
            );
            break;
          }

          case "client_message": {
            await processClientMessage(data.message);
            break;
          }

          case "agent_takeover": {
            const agentName = data.agentName || "Atendente de Suporte N2";
            liveSession.mode = "human";
            liveSession.assignedAgent = {
              name: agentName,
              role: "Suporte N2 Especializado",
            };
            liveSession.unreadCountForAgent = 0;
            liveSession.updatedAt = new Date().toISOString();

            const sysMsg = {
              id: `sys-${Date.now()}`,
              sender: "system",
              content: `🧑‍💼 O atendente humano **${agentName}** assumiu esta conversa. A ComIA foi pausada e agora você está em atendimento direto com nosso time especializado.`,
              timestamp: new Date().toISOString(),
            };

            liveSession.messages.push(sysMsg);
            saveLiveSessionToDisk();

            broadcastWs({
              type: "session_updated",
              session: liveSession,
              systemMessage: sysMsg,
            });
            break;
          }

          case "agent_message": {
            const agentName = data.agentName || liveSession.assignedAgent?.name || "Suporte ComBR";
            const agentMsg = {
              id: `agent-${Date.now()}`,
              sender: "assistant",
              isHumanAgent: true,
              agentName,
              agentRole: "Suporte Técnico N2",
              content: data.content,
              timestamp: new Date().toISOString(),
              status: "read",
            };

            liveSession.messages.push(agentMsg);
            liveSession.unreadCountForAgent = 0;
            liveSession.updatedAt = new Date().toISOString();
            saveLiveSessionToDisk();

            broadcastWs({
              type: "new_message",
              message: agentMsg,
              session: liveSession,
            });
            break;
          }

          case "release_to_bot": {
            liveSession.mode = "bot";
            liveSession.assignedAgent = null;
            liveSession.updatedAt = new Date().toISOString();

            const sysMsg = {
              id: `sys-${Date.now()}`,
              sender: "system",
              content: `🤖 O atendimento foi retornado para a assistente virtual **ComIA**. Você pode continuar tirando dúvidas ou solicitar apoio a qualquer momento.`,
              timestamp: new Date().toISOString(),
            };

            liveSession.messages.push(sysMsg);
            saveLiveSessionToDisk();

            broadcastWs({
              type: "session_updated",
              session: liveSession,
              systemMessage: sysMsg,
            });
            break;
          }

          case "typing": {
            broadcastWs(
              {
                type: "typing",
                who: data.who, // 'client' | 'agent' | 'comia'
                isTyping: !!data.isTyping,
              },
              ws
            );
            break;
          }

          case "finish_attendance": {
            const name = data.agentName || liveSession.assignedAgent?.name || "Erick (Suporte N2)";
            liveSession.status = "finished";
            liveSession.finishedAt = new Date().toISOString();
            liveSession.awaitingRating = true;
            liveSession.mode = "bot";
            liveSession.assignedAgent = null;

            if (data.ticketId) {
              const t = triageTickets.find((item) => item.id === data.ticketId);
              if (t) {
                t.status = "completed";
                t.updatedAt = new Date().toISOString();
                saveTicketsToDisk(triageTickets);
                broadcastWs({
                  type: "ticket_updated",
                  ticket: t,
                  tickets: triageTickets.filter((item) => item && item.id && !deletedTicketIds.has(item.id)),
                });
              }
            }

            const closeMsg = {
              id: `sys-${Date.now()}`,
              sender: "system",
              content: `✅ O atendimento foi finalizado por **${name}**. Agradecemos pela sua preferência e confiança na ComBR Soluções em Nuvem!`,
              timestamp: new Date().toISOString(),
            };
            liveSession.messages.push(closeMsg);

            const ratingPromptMsg = {
              id: `rating-${Date.now()}`,
              sender: "assistant",
              content: `⭐ **Avaliação de Atendimento**\nSua opinião é fundamental para mantermos a excelência do nosso suporte! Como você avalia o atendimento que acabou de receber de **${name}**?`,
              timestamp: new Date().toISOString(),
              status: "read",
              showRatingCard: true,
            };
            liveSession.messages.push(ratingPromptMsg);

            liveSession.updatedAt = new Date().toISOString();
            saveLiveSessionToDisk();

            broadcastWs({
              type: "attendance_finished",
              session: liveSession,
              agentName: name,
              ticketId: data.ticketId,
            });
            break;
          }

          case "submit_rating": {
            const numStars = Math.min(5, Math.max(1, Number(data.rating?.stars) || 5));
            const ratingData = {
              stars: numStars,
              tags: Array.isArray(data.rating?.tags) ? data.rating.tags : [],
              comment: typeof data.rating?.comment === "string" ? data.rating.comment.trim() : "",
              clientName: data.rating?.clientName || liveSession.clientInfo?.name || "Cliente",
              ratedAt: new Date().toISOString(),
            };

            liveSession.rating = ratingData;
            liveSession.awaitingRating = false;

            const starIcons = "⭐".repeat(numStars);
            const thankMsg = {
              id: `rating-thank-${Date.now()}`,
              sender: "assistant",
              content: `🙏 **Muito obrigado pela sua avaliação!**\nNota registrada: ${starIcons} (${numStars}/5 estrelas)${
                ratingData.comment ? `\n\n*"${ratingData.comment}"*` : ""
              }\n\nSua opinião nos ajuda a aprimorar continuamente nossos serviços de suporte e infraestrutura. Conte sempre com a ComBR Soluções em Nuvem!`,
              timestamp: new Date().toISOString(),
              status: "read",
              ratingData,
            };

            liveSession.messages.push(thankMsg);
            liveSession.updatedAt = new Date().toISOString();
            saveLiveSessionToDisk();

            broadcastWs({
              type: "session_rated",
              session: liveSession,
              rating: ratingData,
            });
            break;
          }

          case "reset_chat": {
            liveSession.messages = [];
            liveSession.mode = "bot";
            liveSession.assignedAgent = null;
            liveSession.unreadCountForAgent = 0;
            liveSession.internalNotes = [];
            liveSession.updatedAt = new Date().toISOString();
            saveLiveSessionToDisk();

            broadcastWs({
              type: "chat_reset",
              session: liveSession,
            });
            break;
          }
        }
      } catch (err) {
        console.error("[WS Message Error]:", err);
      }
    });
  });

  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    const indexPath = path.join(distPath, "index.html");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      if (fs.existsSync(indexPath)) {
        res.sendFile(indexPath);
      } else {
        res.status(503).send("Servidor em inicialização.");
      }
    });
  }

  server.listen(PORT, "0.0.0.0", () => {
    console.log(`[ComIA Virtual Assistant Server] Running on http://0.0.0.0:${PORT} (WS + HTTP)`);
  });
}

startServer();