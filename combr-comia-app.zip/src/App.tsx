import React, { useState, useEffect, useRef } from "react";
import { WhatsAppSidebar } from "./components/WhatsAppSidebar";
import { WhatsAppChatHeader } from "./components/WhatsAppChatHeader";
import { WhatsAppMessageList } from "./components/WhatsAppMessageList";
import { WhatsAppInputBar } from "./components/WhatsAppInputBar";
import { WhatsAppDrawer } from "./components/WhatsAppDrawer";
import { TicketsView } from "./components/TicketsView";
import { TriageModal } from "./components/TriageModal";
import { VoiceAccessibilityModal } from "./components/VoiceAccessibilityModal";
import { AgentDeskView } from "./components/AgentDeskView";
import { CreateClientModal } from "./components/CreateClientModal";
import {
  Message,
  Ticket,
  TicketStatus,
  TriageType,
  AppViewMode,
  LiveSession,
  WhatsAppClientChat,
} from "./types";
import {
  loadStoredClientChats,
  saveStoredClientChats,
  DEFAULT_CLIENT_CHATS,
} from "./lib/mockClients";
import { speakHumanized, stopSpeech, TTS_STORAGE_KEYS } from "./lib/speechVoice";
import { liveSync } from "./lib/liveSync";
import {
  fetchRemoteTickets,
  updateRemoteOrLocalTicketStatus,
  deleteRemoteOrLocalTicket,
  syncDeletedIdsToServer,
  requestComIaChat,
} from "./lib/api";
import { Search } from "lucide-react";

const INITIAL_MESSAGES: Message[] = [
  {
    id: "welcome-comia-1",
    sender: "assistant",
    content: `Olá! Sou a **ComIA**, assistente virtual oficial da **ComBR Soluções em Nuvem**.\n\nComo posso ajudar sua empresa hoje? Selecione um dos departamentos abaixo ou envie sua dúvida sobre e-mails, servidores em nuvem ou suporte:`,
    timestamp: new Date().toISOString(),
    status: "read",
    showDepartmentOptions: true,
  },
];

const DELETED_TICKETS_STORAGE_KEY = "comia_permanently_deleted_tickets_v1";

function getLocalDeletedTicketIds(): string[] {
  try {
    const raw = localStorage.getItem(DELETED_TICKETS_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        return parsed.filter((id) => typeof id === "string" && id.trim().length > 0);
      }
    }
  } catch (err) {
    console.warn("Erro ao ler chamados excluídos do localStorage:", err);
  }
  return [];
}

function saveLocalDeletedTicketId(id: string) {
  try {
    const list = getLocalDeletedTicketIds();
    if (!list.includes(id)) {
      list.push(id);
      localStorage.setItem(DELETED_TICKETS_STORAGE_KEY, JSON.stringify(list));
    }
  } catch (err) {
    console.warn("Erro ao salvar chamado excluído no localStorage:", err);
  }
}

export default function App() {
  const [messages, setMessages] = useState<Message[]>(INITIAL_MESSAGES);
  const [loading, setLoading] = useState<boolean>(false);
  const [isTriageOpen, setIsTriageOpen] = useState<boolean>(false);
  const [triageType, setTriageType] = useState<TriageType>("support_n2");
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [activeChannel, setActiveChannel] = useState<string>("main");
  const [drawerOpen, setDrawerOpen] = useState<boolean>(false);
  const [liveSession, setLiveSession] = useState<LiveSession | null>(null);

  // WhatsApp Multi-Client State
  const [clients, setClients] = useState<WhatsAppClientChat[]>(() => loadStoredClientChats());
  const [activeClientId, setActiveClientId] = useState<string>("main");
  const [isCreateClientOpen, setIsCreateClientOpen] = useState<boolean>(false);
  const [showFictionalClients, setShowFictionalClients] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem("combr_show_fictional_clients");
      return saved !== null ? saved === "true" : true;
    } catch {
      return true;
    }
  });

  const handleToggleFictionalClients = (enabled: boolean) => {
    setShowFictionalClients(enabled);
    try {
      localStorage.setItem("combr_show_fictional_clients", String(enabled));
    } catch {}
    if (!enabled && activeClientId !== "main") {
      setActiveClientId("main");
    }
  };

  // View Mode: 'client' | 'agent'
  const [viewMode, setViewMode] = useState<AppViewMode>(() => {
    if (typeof window !== "undefined") {
      const params = new URLSearchParams(window.location.search);
      const view = params.get("view") || params.get("role");
      if (view === "agent") return "agent";
      if (view === "client") return "client";
    }
    return "client";
  });

  const [ttsEnabled, setTtsEnabled] = useState<boolean>(() => {
    try {
      return localStorage.getItem(TTS_STORAGE_KEYS.ENABLED) === "true";
    } catch {
      return false;
    }
  });

  const [selectedVoiceUri, setSelectedVoiceUri] = useState<string | null>(() => {
    try {
      return localStorage.getItem(TTS_STORAGE_KEYS.VOICE_URI);
    } catch {
      return null;
    }
  });

  const [playbackRate, setPlaybackRate] = useState<number>(() => {
    try {
      const saved = localStorage.getItem(TTS_STORAGE_KEYS.RATE);
      return saved ? parseFloat(saved) : 1.0;
    } catch {
      return 1.0;
    }
  });

  const [voiceModalOpen, setVoiceModalOpen] = useState<boolean>(false);
  const [searchOpen, setSearchOpen] = useState<boolean>(false);
  const [chatSearchQuery, setChatSearchQuery] = useState<string>("");
  const [mobileView, setMobileView] = useState<"sidebar" | "chat">("chat");

  // Fetch recent tickets on load with permanent deletion filtering
  useEffect(() => {
    const localDeleted = getLocalDeletedTicketIds();

    if (localDeleted.length > 0) {
      syncDeletedIdsToServer(localDeleted);
    }

    fetchRemoteTickets()
      .then((dataTickets) => {
        const deletedSet = new Set(getLocalDeletedTicketIds());
        const cleanTickets = dataTickets.filter(
          (t: Ticket) => t && t.id && !deletedSet.has(t.id)
        );
        setTickets(cleanTickets);
      })
      .catch(() => {});
  }, []);

  // Real-time synchronization via WebSocket and REST fallback
  useEffect(() => {
    liveSync.fetchInitialSession().then((sess) => {
      if (sess) {
        setLiveSession(sess);
        if (sess.messages && sess.messages.length > 0) {
          setMessages(sess.messages);
        }
      }
    });

    const unsubSync = liveSync.onSync((session, remoteTickets) => {
      setLiveSession(session);
      if (session.messages) {
        setMessages(session.messages);
      }
      if (remoteTickets && Array.isArray(remoteTickets)) {
        const deletedSet = new Set(getLocalDeletedTicketIds());
        setTickets(remoteTickets.filter((t) => t && t.id && !deletedSet.has(t.id)));
      }
    });

    const unsubMsg = liveSync.onNewMessage((newMsg, session) => {
      setLiveSession(session);
      if (session.messages) {
        setMessages(session.messages);
      }
      if (ttsEnabled && (newMsg.sender === "assistant" || newMsg.isHumanAgent)) {
        speakHumanized(newMsg.content, {
          voiceURI: selectedVoiceUri || undefined,
          rate: playbackRate,
        });
      }
    });

    const unsubTyping = liveSync.onTyping((who, isTyping) => {
      if (who === "comia") {
        setLoading(isTyping);
      }
    });

    const unsubReset = (session: LiveSession) => {
      setLiveSession(session);
      setMessages([]);
    };
    const unsubResetFn = liveSync.onReset(unsubReset);

    return () => {
      unsubSync();
      unsubMsg();
      unsubTyping();
      unsubResetFn();
    };
  }, [ttsEnabled, selectedVoiceUri, playbackRate]);

  // Voice toggles and settings handlers
  const handleToggleTTS = () => {
    setTtsEnabled((prev) => {
      const next = !prev;
      try {
        localStorage.setItem(TTS_STORAGE_KEYS.ENABLED, String(next));
      } catch {}
      if (!next) {
        stopSpeech();
      }
      return next;
    });
  };

  const handleSelectVoiceUri = (uri: string | null) => {
    setSelectedVoiceUri(uri);
    try {
      if (uri) localStorage.setItem(TTS_STORAGE_KEYS.VOICE_URI, uri);
      else localStorage.removeItem(TTS_STORAGE_KEYS.VOICE_URI);
    } catch {}
  };

  const handleChangePlaybackRate = (rate: number) => {
    setPlaybackRate(rate);
    try {
      localStorage.setItem(TTS_STORAGE_KEYS.RATE, String(rate));
    } catch {}
  };

  const handleSelectClient = (clientId: string) => {
    setActiveClientId(clientId);
    setActiveChannel("main");
    setMobileView("chat");
    setChatSearchQuery("");
    setClients((prev) => {
      const updated = prev.map((c) =>
        c.id === clientId ? { ...c, unreadCount: 0 } : c
      );
      saveStoredClientChats(updated);
      return updated;
    });
  };

  const handleCreateClient = (newChat: WhatsAppClientChat) => {
    setClients((prev) => {
      const updated = [newChat, ...prev.filter((c) => c.id !== newChat.id)];
      saveStoredClientChats(updated);
      return updated;
    });
    setActiveClientId(newChat.id);
    setActiveChannel("main");
    setMobileView("chat");
  };

  const handleResetToDemoClients = () => {
    setClients(DEFAULT_CLIENT_CHATS);
    saveStoredClientChats(DEFAULT_CLIENT_CHATS);
    setActiveClientId("main");
  };

  const handleDeleteClient = (clientId: string) => {
    if (clientId === "main") return;
    setClients((prev) => {
      const updated = prev.filter((c) => c.id !== clientId);
      saveStoredClientChats(updated);
      return updated;
    });
    if (activeClientId === clientId) {
      setActiveClientId("main");
    }
  };

  const handleSendMessageAsAgent = (clientId: string, text: string, agentName: string) => {
    const agentMsg: Message = {
      id: `agent-${Date.now()}`,
      sender: "assistant",
      isHumanAgent: true,
      agentName,
      agentRole: "Suporte N2 Especializado",
      content: text,
      timestamp: new Date().toISOString(),
      status: "read",
    };

    if (clientId === "main") {
      liveSync.sendAgentMessage(text, agentName);
      setMessages((prev) => [...prev, agentMsg]);
    } else {
      setClients((prev) => {
        const updated = prev.map((c) => {
          if (c.id === clientId) {
            const nextMessages = [...c.messages, agentMsg];
            return {
              ...c,
              messages: nextMessages,
              lastMessage: text,
              lastMessageTime: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
              mode: "human" as const,
              assignedAgent: { name: agentName, role: "Suporte N2 Especializado" },
              updatedAt: new Date().toISOString(),
            };
          }
          return c;
        });
        saveStoredClientChats(updated);
        return updated;
      });
    }
  };

  const handleSendMessage = async (
    text: string,
    isAudio = false,
    audioDuration?: string,
    mediaData?: {
      audioUrl?: string;
      audioBase64?: string;
      mimeType?: string;
      transcript?: string;
      imageAttachment?: import("./types").ImageAttachmentData;
      documentAttachment?: import("./types").DocumentAttachmentData;
      contactAttachment?: import("./types").ContactCardData;
    }
  ) => {
    const userTranscript =
      mediaData?.transcript ||
      (isAudio && text && !text.startsWith("🎙️") ? text : undefined);

    const userMsg: Message = {
      id: `user-${Date.now()}`,
      sender: "user",
      content: text,
      timestamp: new Date().toISOString(),
      isAudio,
      audioDuration,
      audioUrl: mediaData?.audioUrl,
      audioTranscript: userTranscript,
      imageAttachment: mediaData?.imageAttachment,
      documentAttachment: mediaData?.documentAttachment,
      contactAttachment: mediaData?.contactAttachment,
      status: "read",
    };

    if (activeClientId === "main") {
      // Optimistically show message in main chat
      setMessages((prev) => [...prev, userMsg]);
      // Send through real-time sync (broadcasts to WebSocket clients and triggers ComIA if in bot mode)
      liveSync.sendClientMessage(userMsg);
      // Update main in clients list
      setClients((prev) => {
        const updated = prev.map((c) =>
          c.id === "main"
            ? {
                ...c,
                lastMessage: text,
                lastMessageTime: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
                messages: [...c.messages, userMsg],
                updatedAt: new Date().toISOString(),
              }
            : c
        );
        saveStoredClientChats(updated);
        return updated;
      });
    } else {
      const targetClientId = activeClientId;
      const timeStr = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });

      setClients((prev) => {
        const updated = prev.map((c) => {
          if (c.id === targetClientId) {
            return {
              ...c,
              lastMessage: text,
              lastMessageTime: timeStr,
              messages: [...c.messages, userMsg],
              updatedAt: new Date().toISOString(),
            };
          }
          return c;
        });
        saveStoredClientChats(updated);
        return updated;
      });

      const current = clients.find((c) => c.id === targetClientId);
      if (current && current.mode !== "human") {
        setLoading(true);
        try {
          const history = (current.messages || []).map((m) => ({
            role: m.sender === "user" ? "user" : "model",
            content: m.content,
          }));

          const prompt = `[Contexto do Cliente WhatsApp: Nome: ${current.name}, Empresa: ${current.company || "Privada"}, Categoria: ${current.category || "Suporte Técnico"}]\n\nMensagem do cliente: ${text}`;

          const res = await requestComIaChat({
            message: prompt,
            history,
            image: mediaData?.imageAttachment
              ? {
                  dataUrl: mediaData.imageAttachment.url,
                  fileName: mediaData.imageAttachment.fileName,
                  caption: mediaData.imageAttachment.caption,
                }
              : undefined,
          });

          const botMsg: Message = {
            id: `assistant-${Date.now()}`,
            sender: "assistant",
            content: res.reply,
            timestamp: new Date().toISOString(),
            status: "read",
            showDepartmentOptions: true,
          };

          setClients((prev) => {
            const updated = prev.map((c) => {
              if (c.id === targetClientId) {
                return {
                  ...c,
                  lastMessage: res.reply.slice(0, 80) + (res.reply.length > 80 ? "..." : ""),
                  lastMessageTime: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
                  messages: [...c.messages, botMsg],
                  updatedAt: new Date().toISOString(),
                };
              }
              return c;
            });
            saveStoredClientChats(updated);
            return updated;
          });

          if (ttsEnabled) {
            speakHumanized(res.reply, {
              voiceURI: selectedVoiceUri || undefined,
              rate: playbackRate,
            });
          }
        } catch (err) {
          console.warn("Erro ao gerar resposta da ComIA para cliente:", err);
        } finally {
          setLoading(false);
        }
      }
    }
  };

  const handleOpenTriage = (type: TriageType) => {
    setTriageType(type);
    setIsTriageOpen(true);
  };

  const handleTicketCreated = (newTicket: Ticket) => {
    try {
      const list = getLocalDeletedTicketIds().filter((id) => id !== newTicket.id);
      localStorage.setItem(DELETED_TICKETS_STORAGE_KEY, JSON.stringify(list));
    } catch {}

    setTickets((prev) => [newTicket, ...prev.filter((t) => t.id !== newTicket.id)]);

    const typeLabel =
      newTicket.type === "support_n2"
        ? "Suporte Técnico N2 (Especializado)"
        : newTicket.type === "financial"
        ? "Financeiro & Faturamento"
        : "Comercial & Vendas";

    const systemConfirmMsg: Message = {
      id: `triage-confirm-${Date.now()}`,
      sender: "system",
      content: `✅ **Protocolo de Transbordo Humano Registrado:** \`${newTicket.id}\`
* **Setor:** ${typeLabel}
${newTicket.cnpjOrCorporateName ? `* **CNPJ / Razão Social:** \`${newTicket.cnpjOrCorporateName}\`\n` : ""}${newTicket.domain ? `* **Domínio:** \`${newTicket.domain}\`\n` : ""}${newTicket.affectedEmail ? `* **E-mail:** \`${newTicket.affectedEmail}\`\n` : ""}
Sua solicitação foi transferida com sucesso para a equipe da **ComBR Soluções em Nuvem**. Um atendente humano responderá em breve!`,
      timestamp: new Date().toISOString(),
      ticketData: newTicket,
      status: "read",
    };

    setMessages((prev) => [...prev, systemConfirmMsg]);
    liveSync.sendClientMessage(systemConfirmMsg);
    setActiveChannel("main");
    setMobileView("chat");
  };

  const handleUpdateTicketStatus = async (ticketId: string, newStatus: TicketStatus) => {
    setTickets((prev) =>
      prev.map((t) => (t.id === ticketId ? { ...t, status: newStatus, updatedAt: new Date().toISOString() } : t))
    );
    updateRemoteOrLocalTicketStatus(ticketId, newStatus).catch(() => {});
  };

  const handleDeleteTicket = async (ticketId: string) => {
    saveLocalDeletedTicketId(ticketId);
    setTickets((prev) => prev.filter((t) => t.id !== ticketId));
    setMessages((prev) =>
      prev.filter((m) =>
        !(m.ticketData && m.ticketData.id === ticketId) &&
        !(typeof m.content === "string" && m.content.includes(ticketId))
      )
    );
    setLiveSession((prev) =>
      prev
        ? {
            ...prev,
            messages: prev.messages.filter((m) =>
              !(m.ticketData && m.ticketData.id === ticketId) &&
              !(typeof m.content === "string" && m.content.includes(ticketId))
            ),
          }
        : prev
    );
    deleteRemoteOrLocalTicket(ticketId).catch(() => {});
  };

  const handleResetChat = () => {
    setMessages(INITIAL_MESSAGES);
    liveSync.resetChat();
    setActiveChannel("main");
  };

  const handleSwitchView = (mode: AppViewMode) => {
    setViewMode(mode);
    try {
      const url = new URL(window.location.href);
      url.searchParams.set("view", mode);
      window.history.replaceState({}, "", url.toString());
    } catch (_) {}
  };

  const lastAssistantMsg = [...messages].reverse().find((m) => m.sender === "assistant")?.content;
  const activeClient = clients.find((c) => c.id === activeClientId) || clients[0] || DEFAULT_CLIENT_CHATS[0];
  const currentMessages = activeClientId === "main" ? messages : (activeClient?.messages || []);

  // Render WhatsApp Client Component (Dedicated for the end-user customer)
  const renderWhatsAppClient = () => {
    const officialClient = clients.find((c) => c.id === "main") || DEFAULT_CLIENT_CHATS[0];

    return (
      <div
        id="whatsapp-app-container"
        className="w-full h-full bg-[#111b21] overflow-hidden flex z-10 relative"
      >
        {/* Left Sidebar (Customer Chat List: Only official ComBR support channel & tickets) */}
        <div
          className={`${
            mobileView === "sidebar" ? "flex w-full" : "hidden md:flex"
          } h-full shrink-0`}
        >
          <WhatsAppSidebar
            isCustomerView={true}
            activeClientId="main"
            clients={clients.filter((c) => c.id === "main")}
            activeChannel={activeChannel}
            onSelectChannel={(channelId) => {
              setActiveChannel(channelId);
              setMobileView("chat");
            }}
            onOpenTriage={(type) => {
              handleOpenTriage(type);
              setMobileView("chat");
            }}
            onToggleDrawer={() => setDrawerOpen(!drawerOpen)}
            onResetChat={handleResetChat}
            tickets={tickets}
            isAiTyping={loading}
            lastAssistantMessage={lastAssistantMsg}
            showTickets={false}
          />
        </div>

        {/* Right Main Area */}
        <div
          className={`flex-1 h-full flex flex-col bg-[#0b141a] overflow-hidden ${
            mobileView === "chat" ? "flex" : "hidden md:flex"
          }`}
        >
          {activeChannel === "tickets" ? (
            <TicketsView
              tickets={tickets}
              onOpenTriage={handleOpenTriage}
              onUpdateStatus={handleUpdateTicketStatus}
              onDeleteTicket={handleDeleteTicket}
              onBackToChat={() => {
                setActiveChannel("main");
                setMobileView("chat");
              }}
            />
          ) : (
            <>
              {/* Chat Header for Customer */}
              <WhatsAppChatHeader
                activeClient={officialClient}
                onBack={() => setMobileView("sidebar")}
                showBackButton={mobileView === "chat"}
                onToggleDrawer={() => setDrawerOpen(!drawerOpen)}
                onOpenTriage={handleOpenTriage}
                onResetChat={handleResetChat}
                isLoading={loading}
                ttsEnabled={ttsEnabled}
                onToggleTTS={handleToggleTTS}
                onOpenVoiceModal={() => setVoiceModalOpen(true)}
                onToggleSearch={() => setSearchOpen(!searchOpen)}
                isHumanMode={liveSession?.mode === "human"}
                assignedAgentName={liveSession?.assignedAgent?.name}
                onSwitchView={handleSwitchView}
              />

              {/* Inline Search Bar */}
              {searchOpen && (
                <div className="px-4 py-2 bg-[#202c33] border-b border-[#222e35] flex items-center gap-2 text-xs">
                  <Search className="w-4 h-4 text-[#8696a0]" />
                  <input
                    type="text"
                    placeholder="Pesquisar nesta conversa..."
                    value={chatSearchQuery}
                    onChange={(e) => setChatSearchQuery(e.target.value)}
                    className="flex-1 bg-transparent text-[#e9edef] placeholder-[#8696a0] focus:outline-none"
                    autoFocus
                  />
                  {chatSearchQuery && (
                    <button
                      onClick={() => setChatSearchQuery("")}
                      className="text-[#8696a0] hover:text-[#e9edef]"
                    >
                      ✕
                    </button>
                  )}
                  <button
                    onClick={() => {
                      setSearchOpen(false);
                      setChatSearchQuery("");
                    }}
                    className="text-xs text-[#00a884] hover:underline ml-2"
                  >
                    Fechar
                  </button>
                </div>
              )}

              {/* Message List (Customer's own messages) */}
              <WhatsAppMessageList
                messages={messages}
                loading={loading}
                onOpenTriage={handleOpenTriage}
                selectedTriageType={triageType}
                onSendQuickMessage={(msg) => handleSendMessage(msg)}
                searchQuery={chatSearchQuery}
                onSelectChannel={(channelId) => {
                  setActiveChannel(channelId);
                  setMobileView("chat");
                }}
                tickets={tickets}
                selectedVoiceUri={selectedVoiceUri}
                playbackRate={playbackRate}
              />

              {/* WhatsApp Input Bar */}
              <WhatsAppInputBar
                onSendMessage={handleSendMessage}
                loading={loading}
                onOpenTriage={handleOpenTriage}
                onOpenDrawer={() => setDrawerOpen(true)}
              />
            </>
          )}
        </div>
      </div>
    );
  };

  return (
    <div className="h-screen w-screen bg-[#0c1317] flex flex-col overflow-hidden font-sans select-none antialiased">
      {/* Main View Area */}
      <div className="flex-1 flex overflow-hidden relative">
        {/* VIEW: Customer View (WhatsApp - Clean Customer Experience) */}
        {viewMode !== "agent" && (
          <div className="w-full h-full flex flex-col overflow-hidden min-w-0">
            {renderWhatsAppClient()}
          </div>
        )}

        {/* VIEW: Support Operator View (WhatsApp Multi-Client Inbox & Support Desk) */}
        {viewMode === "agent" && (
          <div className="w-full h-full flex flex-col overflow-hidden min-w-0">
            <AgentDeskView
              session={liveSession}
              tickets={tickets}
              onOpenTriage={handleOpenTriage}
              onSwitchView={handleSwitchView}
              isSplitView={false}
              onUpdateTicketStatus={handleUpdateTicketStatus}
              onDeleteTicket={handleDeleteTicket}
              clients={clients}
              activeClientId={activeClientId}
              showFictionalClients={showFictionalClients}
              onToggleFictionalClients={handleToggleFictionalClients}
              onSelectClient={handleSelectClient}
              onOpenCreateClientModal={() => setIsCreateClientOpen(true)}
              onResetToDemoClients={handleResetToDemoClients}
              onDeleteClient={handleDeleteClient}
              onSendMessageAsAgent={handleSendMessageAsAgent}
            />
          </div>
        )}
      </div>

      {/* Slide-in WhatsApp Contact & Server Info Drawer */}
      <WhatsAppDrawer isOpen={drawerOpen} onClose={() => setDrawerOpen(false)} />

      {/* Voice & Accessibility Settings Modal */}
      <VoiceAccessibilityModal
        isOpen={voiceModalOpen}
        onClose={() => setVoiceModalOpen(false)}
        ttsEnabled={ttsEnabled}
        onToggleTTS={handleToggleTTS}
        selectedVoiceUri={selectedVoiceUri}
        onSelectVoiceUri={handleSelectVoiceUri}
        playbackRate={playbackRate}
        onChangePlaybackRate={handleChangePlaybackRate}
      />

      {/* WhatsApp Business Triage Modal */}
      <TriageModal
        key={`triage-modal-${triageType}-${isTriageOpen ? "open" : "closed"}`}
        isOpen={isTriageOpen}
        onClose={() => setIsTriageOpen(false)}
        initialType={triageType}
        onTicketCreated={handleTicketCreated}
      />

      {/* Create Client & Fictional Conversation Modal */}
      <CreateClientModal
        isOpen={isCreateClientOpen}
        onClose={() => setIsCreateClientOpen(false)}
        onCreateClient={handleCreateClient}
        onResetToDemoClients={handleResetToDemoClients}
      />
    </div>
  );
}
