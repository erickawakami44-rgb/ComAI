import React, { useState, useEffect, useRef } from "react";
import ReactMarkdown from "react-markdown";
import {
  ShieldAlert,
  Headphones,
  Bot,
  User,
  Send,
  Sparkles,
  ExternalLink,
  Copy,
  Check,
  PlusCircle,
  FileText,
  Clock,
  CheckCheck,
  AlertTriangle,
  Flame,
  MessageSquare,
  StickyNote,
  Building,
  Phone,
  Mail,
  SlidersHorizontal,
  SplitSquareVertical,
  Laptop,
  CheckCircle2,
  Wrench,
  Building2,
  CreditCard,
  Image as ImageIcon,
  X,
  Download,
  ShieldCheck,
  ChevronRight,
  Search,
  Trash2,
  Star,
  Users,
  UserPlus,
  FlaskConical,
  PanelLeftClose,
  PanelLeftOpen,
  Zap,
  Smartphone,
} from "lucide-react";
import { LiveSession, Message, Ticket, TicketStatus, TriageType, WhatsAppClientChat } from "../types";
import { liveSync } from "../lib/liveSync";
import { ComIALogo } from "./ComIALogo";

interface AgentDeskViewProps {
  session: LiveSession | null;
  tickets: Ticket[];
  onOpenTriage: (type: TriageType) => void;
  onSwitchView?: (view: "client" | "agent" | "split") => void;
  isSplitView?: boolean;
  onUpdateTicketStatus?: (id: string, status: TicketStatus) => void;
  onDeleteTicket?: (id: string) => void;
  clients?: WhatsAppClientChat[];
  activeClientId?: string;
  showFictionalClients?: boolean;
  onToggleFictionalClients?: (enabled: boolean) => void;
  onSelectClient?: (clientId: string) => void;
  onOpenCreateClientModal?: () => void;
  onResetToDemoClients?: () => void;
  onDeleteClient?: (clientId: string) => void;
  onSendMessageAsAgent?: (clientId: string, text: string, agentName: string) => void;
}

const CANNED_RESPONSES = [
  {
    title: "Saudação Humana",
    text: "Olá! Sou o especialista do suporte técnico humano da ComBR Soluções em Nuvem. Assumi seu atendimento e estou analisando seu caso agora mesmo.",
  },
  {
    title: "Checagem IMAP/SMTP",
    text: "Verifiquei nosso servidor corporativo e os serviços de e-mail estão 100% operacionais. As configurações padrão são: IMAP imap.combr.com.br (Porta 993 SSL) e SMTP smtp.combr.com.br (Porta 465 SSL).",
  },
  {
    title: "Solicitar Print de Erro",
    text: "Poderia por gentileza nos enviar um print da tela com o código do erro retornado pelo seu aplicativo de e-mail (Outlook/Thunderbird)?",
  },
  {
    title: "Liberação de IP Firewall",
    text: "Localizei a tentativa de conexão recente e realizei o desbloqueio temporário do seu IP em nosso firewall de segurança. Por favor, tente efetuar login novamente.",
  },
  {
    title: "Encaminhar Comercial",
    text: "Compreendido! Vou direcionar sua solicitação para a nossa equipe Comercial para formalizarmos uma proposta sob medida com preços e condições.",
  },
];

export const AgentDeskView: React.FC<AgentDeskViewProps> = ({
  session,
  tickets,
  onOpenTriage,
  onSwitchView,
  isSplitView = false,
  onUpdateTicketStatus,
  onDeleteTicket,
  clients = [],
  activeClientId = "main",
  showFictionalClients = true,
  onToggleFictionalClients,
  onSelectClient,
  onOpenCreateClientModal,
  onResetToDemoClients,
  onDeleteClient,
  onSendMessageAsAgent,
}) => {
  const [inputText, setInputText] = useState("");
  const [agentName, setAgentName] = useState("Erick (Suporte N2)");
  const [noteText, setNoteText] = useState("");
  const [whoIsTyping, setWhoIsTyping] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<"tickets" | "canned" | "notes" | "info">("tickets");
  const [ticketFilter, setTicketFilter] = useState<"all" | "not_started" | "in_progress" | "completed">("all");
  const [deptFilter, setDeptFilter] = useState<"all" | "support_n2" | "commercial" | "financial">("all");
  const [lightboxImage, setLightboxImage] = useState<{ url: string; name: string } | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [deletingTicketId, setDeletingTicketId] = useState<string | null>(null);
  const [activeTicketId, setActiveTicketId] = useState<string | null>(null);
  const [finishModalOpen, setFinishModalOpen] = useState<boolean>(false);
  const [ticketToFinish, setTicketToFinish] = useState<string | null>(null);
  const [clientSearchQuery, setClientSearchQuery] = useState<string>("");
  const [clientCategoryFilter, setClientCategoryFilter] = useState<
    "all" | "unread" | "support_n2" | "commercial" | "financial"
  >("all");
  const [isClientListOpen, setIsClientListOpen] = useState<boolean>(true);
  const [isToolsOpen, setIsToolsOpen] = useState<boolean>(false);
  const [showQuickRepliesPopover, setShowQuickRepliesPopover] = useState<boolean>(false);
  const messagesEndRef = useRef<HTMLDivElement | null>(null);
  const inputRef = useRef<HTMLInputElement | null>(null);

  // Available clients based on fictional clients toggle
  const availableClients = showFictionalClients
    ? clients
    : clients.filter((c) => c.id === "main");

  // Effective selected client ID
  const effectiveActiveClientId = showFictionalClients
    ? (availableClients.some((c) => c.id === activeClientId) ? activeClientId : "main")
    : "main";
  const selectedClient = availableClients.find((c) => c.id === effectiveActiveClientId) || availableClients[0] || null;
  const isSelectedClientOfficial = !showFictionalClients || !selectedClient || selectedClient.id === "main";
  const effectiveMode = isSelectedClientOfficial ? session?.mode : selectedClient?.mode;
  const isHumanMode = effectiveMode === "human";
  const messages = isSelectedClientOfficial
    ? (session?.messages && session.messages.length > 0 ? session.messages : selectedClient?.messages || [])
    : (selectedClient?.messages || []);

  const filteredClients = availableClients.filter((c) => {
    const q = clientSearchQuery.toLowerCase().trim();
    const matchSearch =
      !q ||
      c.name.toLowerCase().includes(q) ||
      (c.company && c.company.toLowerCase().includes(q)) ||
      (c.phone && c.phone.includes(q)) ||
      (c.lastMessage && c.lastMessage.toLowerCase().includes(q)) ||
      (c.domain && c.domain.toLowerCase().includes(q));

    if (!matchSearch) return false;

    if (clientCategoryFilter === "unread") return (c.unreadCount || 0) > 0;
    if (clientCategoryFilter === "support_n2") return c.category === "support_n2";
    if (clientCategoryFilter === "commercial") return c.category === "commercial";
    if (clientCategoryFilter === "financial") return c.category === "financial";
    return true;
  });

  const totalUnreadCount = availableClients.reduce((acc, c) => acc + (c.unreadCount || 0), 0);

  // Scroll to bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, whoIsTyping]);

  // Listen for typing events
  useEffect(() => {
    const unsub = liveSync.onTyping((who, isTyping) => {
      if (isTyping) {
        if (who === "client") setWhoIsTyping("Cliente está digitando...");
        else if (who === "comia") setWhoIsTyping("ComIA está gerando resposta...");
      } else {
        setWhoIsTyping(null);
      }
    });
    return unsub;
  }, []);

  const handleTakeover = () => {
    if (isSelectedClientOfficial) {
      liveSync.takeoverChat(agentName);
    } else if (onSendMessageAsAgent && selectedClient) {
      onSendMessageAsAgent(selectedClient.id, `🧑‍💼 O atendente humano ${agentName} assumiu este atendimento.`, agentName);
    }
  };

  const handleReleaseToBot = () => {
    if (isSelectedClientOfficial) {
      liveSync.releaseToBot();
    }
  };

  // Ao clicar em Iniciar: assume o atendimento, marca o chamado em andamento e entra direto na conversa com o cliente
  const handleStartTicketSupport = (ticket: Ticket) => {
    setActiveTicketId(ticket.id);
    if (onUpdateTicketStatus) {
      onUpdateTicketStatus(ticket.id, "in_progress");
    }

    // Assume o atendimento como agente humano
    liveSync.takeoverChat(agentName);

    const subject = ticket.subject || "Suporte Técnico";
    const deptName =
      ticket.type === "support_n2"
        ? "Suporte Técnico N2"
        : ticket.type === "commercial"
        ? "Comercial"
        : "Financeiro";

    // Envia mensagem direta de início para o cliente no chat
    const openingMsg = `Olá! Sou ${agentName} da equipe de ${deptName} da ComBR e assumi o seu chamado #${ticket.id} (${subject}). Estou em atendimento ao vivo com você. Como posso lhe ajudar agora?`;
    liveSync.sendAgentMessage(openingMsg, agentName);

    // Foca imediatamente no campo de entrada do chat
    setTimeout(() => {
      inputRef.current?.focus();
      messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }, 150);
  };

  const handleOpenFinishModal = (ticketId?: string) => {
    setTicketToFinish(ticketId || activeTicketId || null);
    setFinishModalOpen(true);
  };

  const handleConfirmFinish = () => {
    const targetId = ticketToFinish || activeTicketId || undefined;
    liveSync.finishAttendance(agentName, targetId);
    if (targetId && onUpdateTicketStatus) {
      onUpdateTicketStatus(targetId, "completed");
    }
    setFinishModalOpen(false);
    setTicketToFinish(null);
    setActiveTicketId(null);
  };

  const handleSendMessage = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const clean = inputText.trim();
    if (!clean) return;

    if (isSelectedClientOfficial) {
      // If bot was in control, automatically take over when human sends message
      if (!isHumanMode) {
        liveSync.takeoverChat(agentName);
      }
      liveSync.sendAgentMessage(clean, agentName);
      liveSync.sendTyping("agent", false);
    } else if (onSendMessageAsAgent && selectedClient) {
      onSendMessageAsAgent(selectedClient.id, clean, agentName);
    }
    setInputText("");
    setTimeout(() => {
      messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }, 100);
  };

  const handleApplyCanned = (text: string) => {
    setInputText(text);
  };

  const handleAddNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!noteText.trim()) return;
    liveSync.addInternalNote(noteText.trim(), agentName);
    setNoteText("");
  };

  return (
    <div
      className={`flex flex-col w-full h-full flex-1 min-w-0 bg-[#0d1418] text-[#e9edef] font-sans overflow-hidden select-none ${
        isSplitView ? "border-l border-[#222e35]" : ""
      }`}
    >
      {/* Main Agent Area (Split: WhatsApp Client Inbox + Chat Spectator + Tool Desk) */}
      <div className="flex-1 flex flex-col md:flex-row overflow-hidden w-full min-w-0">
        {/* Column 1: WhatsApp Multi-Client Inbox Sidebar */}
        <div
          className={`${
            isClientListOpen ? "flex" : "hidden"
          } flex-col w-full md:w-[300px] lg:w-[320px] bg-[#111b21] border-r border-[#222e35] shrink-0 overflow-hidden select-none z-10`}
        >
          {/* Sidebar Top: Header with clean title & Fictícios Toggle */}
          <div className="h-14 px-3 bg-[#202c33] border-b border-[#222e35] flex items-center justify-between shrink-0">
            <div className="flex items-center gap-2">
              <Users className="w-4 h-4 text-[#00a884]" />
              <span className="text-xs font-bold text-white tracking-wide">Conversas</span>
              <span className="text-[10px] text-[#8696a0]">({availableClients.length})</span>
            </div>

            <div className="flex items-center gap-1.5">
              {/* Clean Fictional Clients Toggle */}
              {onToggleFictionalClients && (
                <button
                  type="button"
                  onClick={() => onToggleFictionalClients(!showFictionalClients)}
                  className={`px-2 py-1 rounded text-[10px] font-medium flex items-center gap-1 transition-colors cursor-pointer border ${
                    showFictionalClients
                      ? "bg-[#00a884]/15 border-[#00a884]/40 text-[#00a884]"
                      : "bg-[#182229] border-[#2a3942] text-[#8696a0] hover:text-white"
                  }`}
                  title={
                    showFictionalClients
                      ? "Desativar clientes fictícios (exibir apenas cliente real)"
                      : "Ativar clientes fictícios para testes"
                  }
                >
                  <FlaskConical className="w-3 h-3" />
                  <span>{showFictionalClients ? "Simulação ON" : "Simulação OFF"}</span>
                </button>
              )}

              {/* Collapse Left Sidebar button */}
              <button
                onClick={() => setIsClientListOpen(false)}
                className="p-1 rounded text-[#8696a0] hover:text-white hover:bg-[#2a3942] transition-colors md:flex hidden"
                title="Recolher lista de conversas"
              >
                <PanelLeftClose className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Quick Actions (only when fictional clients are active) */}
          {showFictionalClients && (
            <div className="px-3 py-1.5 bg-[#182229] border-b border-[#222e35] flex items-center gap-1.5 shrink-0">
              {onOpenCreateClientModal && (
                <button
                  onClick={onOpenCreateClientModal}
                  className="flex-1 py-1 rounded bg-[#00a884]/15 hover:bg-[#00a884]/25 text-[#00a884] text-[11px] font-medium flex items-center justify-center gap-1 transition-colors cursor-pointer"
                  title="Criar novo cliente fictício"
                >
                  <UserPlus className="w-3 h-3" />
                  <span>+ Novo Cliente</span>
                </button>
              )}
              {onResetToDemoClients && (
                <button
                  onClick={onResetToDemoClients}
                  className="px-2 py-1 rounded bg-[#202c33] hover:bg-[#2a3942] text-amber-400 text-[11px] font-medium flex items-center justify-center gap-1 transition-colors cursor-pointer"
                  title="Restaurar 5 clientes de demonstração"
                >
                  <Sparkles className="w-3 h-3" />
                  <span>5 Demos</span>
                </button>
              )}
            </div>
          )}

          {/* Search Box */}
          <div className="p-2.5 bg-[#111b21] border-b border-[#222e35] shrink-0">
            <div className="relative flex items-center bg-[#202c33] rounded-lg px-2.5 py-1.5 text-xs">
              <Search className="w-3.5 h-3.5 text-[#8696a0] mr-2 shrink-0" />
              <input
                type="text"
                placeholder="Pesquisar conversa..."
                value={clientSearchQuery}
                onChange={(e) => setClientSearchQuery(e.target.value)}
                className="w-full bg-transparent text-[#e9edef] placeholder-[#8696a0] focus:outline-none text-xs"
              />
              {clientSearchQuery && (
                <button
                  onClick={() => setClientSearchQuery("")}
                  className="text-[#8696a0] hover:text-[#e9edef] text-xs px-1 cursor-pointer"
                >
                  ✕
                </button>
              )}
            </div>

            {/* Category Filter Pills (only when fictional clients active) */}
            {showFictionalClients && (
              <div className="flex items-center gap-1 overflow-x-auto no-scrollbar text-[10px] pt-1.5">
                <button
                  onClick={() => setClientCategoryFilter("all")}
                  className={`px-2 py-0.5 rounded transition-colors cursor-pointer ${
                    clientCategoryFilter === "all"
                      ? "bg-[#00a884]/20 text-[#00a884] font-medium"
                      : "text-[#8696a0] hover:text-[#e9edef]"
                  }`}
                >
                  Todas ({availableClients.length})
                </button>
                <button
                  onClick={() => setClientCategoryFilter("unread")}
                  className={`px-2 py-0.5 rounded transition-colors flex items-center gap-1 cursor-pointer ${
                    clientCategoryFilter === "unread"
                      ? "bg-[#00a884]/20 text-[#00a884] font-medium"
                      : "text-[#8696a0] hover:text-[#e9edef]"
                  }`}
                >
                  Não Lidas
                </button>
                <button
                  onClick={() => setClientCategoryFilter("support_n2")}
                  className={`px-2 py-0.5 rounded transition-colors cursor-pointer ${
                    clientCategoryFilter === "support_n2"
                      ? "bg-[#00a884]/20 text-[#00a884] font-medium"
                      : "text-[#8696a0] hover:text-[#e9edef]"
                  }`}
                >
                  N2
                </button>
                <button
                  onClick={() => setClientCategoryFilter("commercial")}
                  className={`px-2 py-0.5 rounded transition-colors cursor-pointer ${
                    clientCategoryFilter === "commercial"
                      ? "bg-[#00a884]/20 text-[#00a884] font-medium"
                      : "text-[#8696a0] hover:text-[#e9edef]"
                  }`}
                >
                  Vendas
                </button>
                <button
                  onClick={() => setClientCategoryFilter("financial")}
                  className={`px-2 py-0.5 rounded transition-colors cursor-pointer ${
                    clientCategoryFilter === "financial"
                      ? "bg-[#00a884]/20 text-[#00a884] font-medium"
                      : "text-[#8696a0] hover:text-[#e9edef]"
                  }`}
                >
                  Fin.
                </button>
              </div>
            )}
          </div>

          {/* Client List */}
          <div className="flex-1 overflow-y-auto divide-y divide-[#222e35]/60">
            {filteredClients.map((c) => {
              const isSelected = (effectiveActiveClientId || "main") === c.id;
              const isOfficial = c.id === "main";
              const hasUnread = (c.unreadCount || 0) > 0;

              return (
                <div
                  key={c.id}
                  onClick={() => onSelectClient && onSelectClient(c.id)}
                  className={`group px-3 py-2.5 flex items-center gap-2.5 cursor-pointer transition-colors relative ${
                    isSelected
                      ? "bg-[#2a3942] border-l-3 border-l-[#00a884]"
                      : "hover:bg-[#202c33]/60 border-l-3 border-l-transparent"
                  }`}
                >
                  {/* Client Avatar */}
                  <div className="relative shrink-0">
                    {isOfficial ? (
                      <div className="w-10 h-10 rounded-full bg-[#111b21] border border-[#2a3942] flex items-center justify-center overflow-hidden">
                        <ComIALogo size="sm" showText={false} />
                      </div>
                    ) : (
                      <div
                        className="w-10 h-10 rounded-full flex items-center justify-center text-white font-bold text-xs shadow-inner"
                        style={{ backgroundColor: c.avatarColor || "#3b82f6" }}
                      >
                        {c.avatarInitials || c.name.slice(0, 2).toUpperCase()}
                      </div>
                    )}
                    {c.status === "online" && (
                      <span className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-[#00a884] border-2 border-[#111b21] rounded-full"></span>
                    )}
                  </div>

                  {/* Client Details & Snippet */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-0.5">
                      <div className="flex items-center gap-1 min-w-0">
                        <span
                          className={`text-xs font-semibold truncate ${
                            hasUnread ? "text-white font-bold" : "text-[#e9edef]"
                          }`}
                        >
                          {c.name}
                        </span>

                        {isOfficial && (
                          <span
                            className="inline-flex items-center justify-center w-3 h-3 rounded-full bg-[#00a884] text-[#111b21] shrink-0"
                            title="Oficial Verificado"
                          >
                            <Check className="w-2 h-2 stroke-[3]" />
                          </span>
                        )}
                      </div>

                      <span
                        className={`text-[10px] shrink-0 ml-1 ${
                          hasUnread ? "text-[#00a884] font-bold" : "text-[#8696a0]"
                        }`}
                      >
                        {c.lastMessageTime || "--"}
                      </span>
                    </div>

                    <div className="flex items-center justify-between text-[11px] text-[#8696a0]">
                      <p
                        className={`truncate pr-1 ${
                          hasUnread ? "text-[#e9edef] font-medium" : "text-[#8696a0]"
                        }`}
                      >
                        {c.lastMessage || "Conversa vazia"}
                      </p>

                      <div className="flex items-center gap-1 shrink-0">
                        {!isOfficial && onDeleteClient && (
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              if (confirm(`Remover cliente "${c.name}"?`)) {
                                onDeleteClient(c.id);
                              }
                            }}
                            className="opacity-0 group-hover:opacity-100 p-1 text-[#8696a0] hover:text-[#f15c6d] rounded transition-opacity cursor-pointer"
                            title="Remover este cliente fictício"
                          >
                            <Trash2 className="w-3 h-3" />
                          </button>
                        )}

                        {hasUnread && (
                          <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-[#00a884] text-[#111b21] font-bold">
                            {c.unreadCount}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Column 2: Live Message Spectator & Live Input */}
        <div className="flex-1 flex flex-col bg-[#0b141a] overflow-hidden relative min-w-0 w-full">
          {/* Header of Selected Client */}
          <div className="h-14 px-3 sm:px-4 bg-[#202c33] border-b border-[#222e35] flex items-center justify-between shrink-0 select-none">
            <div className="flex items-center gap-2.5 min-w-0">
              {!isClientListOpen && (
                <button
                  onClick={() => setIsClientListOpen(true)}
                  className="p-1.5 rounded-lg bg-[#182229] border border-[#2a3942] text-[#00a884] hover:bg-[#2a3942] transition-colors cursor-pointer mr-1"
                  title="Abrir lista de conversas"
                >
                  <PanelLeftOpen className="w-4 h-4" />
                </button>
              )}

              <div className="relative shrink-0">
                {isSelectedClientOfficial ? (
                  <div className="w-9 h-9 rounded-full bg-[#111b21] border border-[#2a3942] flex items-center justify-center">
                    <ComIALogo size="sm" showText={false} />
                  </div>
                ) : (
                  <div
                    className="w-9 h-9 rounded-full flex items-center justify-center text-white font-bold text-xs"
                    style={{ backgroundColor: selectedClient?.avatarColor || "#3b82f6" }}
                  >
                    {selectedClient?.avatarInitials || selectedClient?.name.slice(0, 2).toUpperCase()}
                  </div>
                )}
                {selectedClient?.status === "online" && (
                  <span className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-[#00a884] border-2 border-[#202c33] rounded-full"></span>
                )}
              </div>

              <div className="min-w-0">
                <div className="flex items-center gap-1.5">
                  <h3 className="text-xs sm:text-sm font-bold text-white truncate">
                    {selectedClient?.name || "Cliente Conectado"}
                  </h3>
                  {selectedClient?.phone && (
                    <span className="text-[11px] text-[#8696a0] font-mono hidden md:inline">
                      ({selectedClient.phone})
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-2 text-[10px] text-[#8696a0]">
                  <span>{selectedClient?.company || "ComBR Soluções em Nuvem"}</span>
                  {selectedClient?.domain && (
                    <>
                      <span>•</span>
                      <span className="text-[#00a884]">{selectedClient.domain}</span>
                    </>
                  )}
                </div>
              </div>
            </div>

            {/* Chat Header Actions */}
            <div className="flex items-center gap-2">
              {session?.rating && (
                <div className="hidden sm:flex items-center gap-1 text-xs text-amber-400 font-semibold px-2 py-0.5 rounded bg-amber-500/10 border border-amber-500/30">
                  <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                  <span>{session.rating.stars}/5</span>
                </div>
              )}

              {/* Bot or Human Status & Action Button */}
              {isHumanMode ? (
                <div className="flex items-center gap-1.5">
                  <span className="hidden sm:flex items-center gap-1 text-[11px] text-[#00a884] font-medium bg-[#005c4b]/20 px-2 py-1 rounded">
                    <span className="w-2 h-2 rounded-full bg-[#00a884] animate-ping"></span>
                    <span>Humano</span>
                  </span>
                  <button
                    onClick={handleReleaseToBot}
                    className="px-2.5 py-1 bg-[#202c33] hover:bg-[#2a3942] active:scale-95 text-[#e9edef] text-xs font-medium rounded-lg border border-[#2a3942] transition-all flex items-center gap-1 cursor-pointer"
                    title="Devolver atendimento para a IA ComIA"
                  >
                    <Bot className="w-3.5 h-3.5 text-[#00a884]" />
                    <span className="hidden md:inline">Devolver p/ IA</span>
                  </button>
                  <button
                    onClick={() => handleOpenFinishModal()}
                    className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white text-xs font-bold rounded-lg transition-all flex items-center gap-1 shadow-sm cursor-pointer"
                    title="Finalizar atendimento"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Finalizar</span>
                  </button>
                </div>
              ) : (
                <div className="flex items-center gap-1.5">
                  <span className="hidden sm:flex items-center gap-1 text-[11px] text-[#8696a0] bg-[#182229] px-2 py-1 rounded">
                    <span className="w-2 h-2 rounded-full bg-[#00a884]"></span>
                    <span>ComIA Respondendo</span>
                  </span>
                  <button
                    onClick={handleTakeover}
                    className="px-3 py-1 bg-[#00a884] hover:bg-[#029070] active:scale-95 text-[#111b21] text-xs font-bold rounded-lg transition-all flex items-center gap-1.5 shadow-sm cursor-pointer"
                    title="Pausar a IA e assumir o atendimento humano"
                  >
                    <User className="w-3.5 h-3.5" />
                    <span>Assumir Chat</span>
                  </button>
                </div>
              )}

              {/* Switch to Client View */}
              {onSwitchView && (
                <button
                  type="button"
                  onClick={() => onSwitchView("client")}
                  className="px-2.5 py-1 rounded-lg border border-[#2a3942] bg-[#182229] hover:bg-[#202c33] text-[#8696a0] hover:text-white text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer"
                  title="Ver tela do Cliente (WhatsApp)"
                >
                  <Smartphone className="w-3.5 h-3.5 text-[#00a884]" />
                  <span className="hidden sm:inline">Cliente</span>
                </button>
              )}

              {/* Export Project ZIP */}
              <a
                href="/combr-comia-app.zip"
                download="combr-comia-app.zip"
                className="px-2.5 py-1 rounded-lg border border-[#2a3942] bg-[#182229] hover:bg-[#202c33] text-amber-400 text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer"
                title="Baixar arquivo ZIP com o código completo do projeto para publicar em outra conta"
              >
                <Download className="w-3.5 h-3.5 text-amber-400" />
                <span className="hidden md:inline">Exportar ZIP</span>
              </a>

              {/* Tools Panel Toggle */}
              <button
                onClick={() => setIsToolsOpen(!isToolsOpen)}
                className={`px-2.5 py-1 rounded-lg border text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer ${
                  isToolsOpen
                    ? "bg-[#00a884]/20 border-[#00a884] text-[#00a884]"
                    : "bg-[#182229] border-[#2a3942] text-[#8696a0] hover:text-white"
                }`}
                title="Abrir ou fechar painel de ferramentas e chamados"
              >
                <SlidersHorizontal className="w-3.5 h-3.5" />
                <span className="hidden lg:inline">Ferramentas</span>
                {tickets.length > 0 && (
                  <span className="px-1.5 py-0.1 rounded-full text-[10px] bg-[#00a884] text-[#111b21] font-bold">
                    {tickets.length}
                  </span>
                )}
              </button>
            </div>
          </div>

          {/* Messages Flow Area */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3 whatsapp-bg">
            {messages.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center p-6 text-[#8696a0]">
                <div className="w-14 h-14 rounded-2xl bg-[#182229] border border-[#222e35] flex items-center justify-center mb-3 text-[#00a884]">
                  <MessageSquare className="w-7 h-7" />
                </div>
                <h3 className="text-sm font-semibold text-white mb-1">
                  Nenhuma mensagem na sessão
                </h3>
                <p className="text-xs max-w-sm mb-4">
                  Envie uma mensagem na <strong>Tela do Cliente</strong> ou digite uma resposta abaixo para iniciar o teste do atendimento em tempo real.
                </p>
                <button
                  onClick={() => liveSync.sendAgentMessage("Olá! Sou o atendente humano da ComBR. Em que posso te ajudar hoje?", agentName)}
                  className="px-4 py-2 rounded-xl bg-[#00a884] hover:bg-[#029070] text-[#111b21] font-bold text-xs transition-colors flex items-center gap-2 shadow-lg"
                >
                  <Send className="w-3.5 h-3.5" />
                  Enviar Saudação de Teste
                </button>
              </div>
            ) : (
              messages.map((msg) => {
                const isUser = msg.sender === "user";
                const isAssistant = msg.sender === "assistant";
                const isSystem = msg.sender === "system";
                const isHuman = msg.isHumanAgent;

                if (isSystem) {
                  return (
                    <div
                      key={msg.id}
                      className="mx-auto max-w-md my-2 px-3.5 py-1.5 rounded-lg bg-[#182229] border border-[#2a3942] text-[11px] text-[#8696a0] text-center shadow-sm"
                    >
                      <ReactMarkdown
                        components={{
                          p: ({ children }) => <span>{children}</span>,
                          strong: ({ children }) => <strong className="text-[#00a884] font-semibold">{children}</strong>,
                        }}
                      >
                        {msg.content}
                      </ReactMarkdown>
                    </div>
                  );
                }

                return (
                  <div
                    key={msg.id}
                    className={`flex flex-col ${isUser ? "items-start" : "items-end"}`}
                  >
                    {/* Sender Identity Label */}
                    <div className="text-[10px] text-[#8696a0] mb-0.5 px-1 flex items-center gap-1.5">
                      {isUser ? (
                        <>
                          <User className="w-3 h-3 text-[#8696a0]" />
                          <span className="font-semibold text-white">Cliente (Visitante)</span>
                        </>
                      ) : isHuman ? (
                        <>
                          <span className="w-2 h-2 rounded-full bg-[#00a884]"></span>
                          <span className="font-semibold text-[#00a884]">
                            🧑‍💼 {msg.agentName || "Atendente Humano"}
                          </span>
                        </>
                      ) : (
                        <>
                          <Bot className="w-3 h-3 text-[#00a884]" />
                          <span className="font-semibold text-[#00a884]">
                            🤖 ComIA (IA Autônoma)
                          </span>
                        </>
                      )}
                      <span>•</span>
                      <span>
                        {new Date(msg.timestamp).toLocaleTimeString("pt-BR", {
                          hour: "2-digit",
                          minute: "2-digit",
                        })}
                      </span>
                    </div>

                    {/* Bubble Content */}
                    <div
                      className={`max-w-[90%] lg:max-w-[760px] rounded-2xl p-3.5 text-xs sm:text-[13px] shadow-md border ${
                        isUser
                          ? "bg-[#202c33] text-[#e9edef] border-[#2a3942] rounded-tl-none"
                          : isHuman
                          ? "bg-[#0b332b] text-[#e9edef] border-[#00a884]/40 rounded-tr-none"
                          : "bg-[#182229] text-[#e9edef] border-[#222e35] rounded-tr-none"
                      }`}
                    >
                      {/* Media Attachments indicators */}
                      {msg.imageAttachment && (
                        <div className="mb-2.5">
                          <img
                            src={msg.imageAttachment.url}
                            alt="Anexo"
                            className="max-h-60 rounded-lg object-cover border border-white/10"
                          />
                        </div>
                      )}

                      {msg.documentAttachment && (
                        <div className="mb-2.5 p-2 rounded-lg bg-black/20 border border-white/10 flex items-center gap-2">
                          <FileText className="w-4 h-4 text-[#00a884]" />
                          <span className="font-semibold truncate">
                            {msg.documentAttachment.name}
                          </span>
                        </div>
                      )}

                      {msg.isAudio && (
                        <div className="mb-1 text-[11px] text-[#00a884] flex items-center gap-1 font-mono">
                          <span>🎙️ Mensagem de Áudio ({msg.audioDuration || "0:05"})</span>
                        </div>
                      )}

                      {/* Markdown Rich Content */}
                      <div className="leading-relaxed break-words text-xs sm:text-[13px] text-[#e9edef]">
                        <ReactMarkdown
                          components={{
                            p: ({ children }) => <p className="my-1.5 leading-relaxed">{children}</p>,
                            strong: ({ children }) => (
                              <strong className="font-bold text-white tracking-wide">{children}</strong>
                            ),
                            ul: ({ children }) => (
                              <ul className="my-2 space-y-1.5 list-disc pl-5 text-[#d1d7db]">{children}</ul>
                            ),
                            ol: ({ children }) => (
                              <ol className="my-2 space-y-1.5 list-decimal pl-5 text-[#d1d7db]">{children}</ol>
                            ),
                            li: ({ children }) => <li className="leading-relaxed">{children}</li>,
                            code: ({ children }) => (
                              <code className="px-1.5 py-0.5 rounded bg-black/40 text-[#53bdeb] font-mono text-[11px] border border-white/10">
                                {children}
                              </code>
                            ),
                            h1: ({ children }) => (
                              <h1 className="text-sm font-bold text-white mt-2 mb-1">{children}</h1>
                            ),
                            h2: ({ children }) => (
                              <h2 className="text-xs font-bold text-white mt-2 mb-1">{children}</h2>
                            ),
                            h3: ({ children }) => (
                              <h3 className="text-xs font-semibold text-[#00a884] mt-1.5 mb-0.5">{children}</h3>
                            ),
                            blockquote: ({ children }) => (
                              <blockquote className="border-l-2 border-[#00a884] pl-2.5 my-2 italic text-[#8696a0]">
                                {children}
                              </blockquote>
                            ),
                          }}
                        >
                          {msg.content}
                        </ReactMarkdown>
                      </div>

                      {/* Sleek Ticket Summary Box (For Support Reference) */}
                      {msg.ticketData && (
                        <div className="mt-2.5 bg-[#111b21] border border-[#2a3942] rounded-xl p-3 text-left space-y-2 text-xs shadow-sm">
                          <div className="flex items-center justify-between border-b border-[#2a3942]/70 pb-2">
                            <div className="flex items-center gap-2">
                              <span className="font-mono font-bold text-white text-xs">
                                #{msg.ticketData.id}
                              </span>
                              <span
                                className={`text-[9px] font-bold px-2 py-0.5 rounded-full border uppercase tracking-wider ${
                                  msg.ticketData.type === "support_n2"
                                    ? "text-[#53bdeb] bg-[#53bdeb]/10 border-[#53bdeb]/30"
                                    : msg.ticketData.type === "commercial"
                                    ? "text-[#25d366] bg-[#25d366]/10 border-[#25d366]/30"
                                    : "text-[#ffd279] bg-[#ffd279]/10 border-[#ffd279]/30"
                                }`}
                              >
                                {msg.ticketData.type === "support_n2"
                                  ? "Suporte N2"
                                  : msg.ticketData.type === "commercial"
                                  ? "Comercial"
                                  : "Financeiro"}
                              </span>
                            </div>
                            <span
                              className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full border ${
                                msg.ticketData.status === "completed"
                                  ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/30"
                                  : msg.ticketData.status === "in_progress"
                                  ? "bg-amber-500/10 text-amber-400 border-amber-500/30"
                                  : "bg-rose-500/10 text-rose-400 border-rose-500/30"
                              }`}
                            >
                              {msg.ticketData.status === "completed"
                                ? "Concluído"
                                : msg.ticketData.status === "in_progress"
                                ? "Em andamento"
                                : "Não iniciado"}
                            </span>
                          </div>

                          {/* Concise Details */}
                          <div className="space-y-1 text-[11px] text-[#8696a0]">
                            {msg.ticketData.subject && (
                              <div className="text-white font-medium">
                                {msg.ticketData.subject}
                              </div>
                            )}
                            <div className="flex flex-wrap items-center gap-x-2 gap-y-0.5 text-[10px]">
                              {msg.ticketData.contactName && (
                                <span>Solicitante: <strong className="text-[#e9edef] font-normal">{msg.ticketData.contactName}</strong></span>
                              )}
                              {msg.ticketData.domain && (
                                <span>• Domínio: <span className="text-[#00a884] font-mono">{msg.ticketData.domain}</span></span>
                              )}
                              {msg.ticketData.affectedEmail && (
                                <span>• E-mail: <span className="text-[#e9edef] font-mono">{msg.ticketData.affectedEmail}</span></span>
                              )}
                            </div>
                          </div>

                          {/* Error Screenshot attachment if present */}
                          {msg.ticketData.attachmentImage && (
                            <div className="pt-1">
                              <button
                                type="button"
                                onClick={() =>
                                  setLightboxImage({
                                    url: msg.ticketData!.attachmentImage!.url,
                                    name: msg.ticketData!.attachmentImage!.fileName || "Evidência de Suporte",
                                  })
                                }
                                className="inline-flex items-center gap-1.5 px-2 py-1 rounded-lg bg-[#182229] hover:bg-[#202c33] border border-[#2a3942] text-[10px] text-[#00a884] transition-colors cursor-pointer"
                              >
                                <ImageIcon className="w-3 h-3" />
                                <span>Ver Print Anexado</span>
                              </button>
                            </div>
                          )}

                          {/* Action Buttons Row */}
                          <div className="flex items-center justify-between pt-1.5 border-t border-[#2a3942]/60 gap-1.5">
                            <div className="flex items-center gap-1.5">
                              {onUpdateTicketStatus && msg.ticketData.id && (
                                <>
                                  {msg.ticketData.status !== "in_progress" && msg.ticketData.status !== "completed" && (
                                    <button
                                      type="button"
                                      onClick={() => handleStartTicketSupport(msg.ticketData!)}
                                      className="px-2.5 py-1 rounded-lg bg-[#00a884] hover:bg-[#029070] text-[10px] text-[#111b21] font-bold transition-colors cursor-pointer flex items-center gap-1 shadow-sm"
                                    >
                                      ▶️ Iniciar
                                    </button>
                                  )}
                                  {msg.ticketData.status === "in_progress" && (
                                    <button
                                      type="button"
                                      onClick={() => handleOpenFinishModal(msg.ticketData!.id)}
                                      className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-[10px] text-white font-bold transition-colors cursor-pointer flex items-center gap-1 shadow-sm"
                                    >
                                      <CheckCircle2 className="w-3 h-3" />
                                      <span>Finalizar</span>
                                    </button>
                                  )}
                                </>
                              )}
                              <button
                                type="button"
                                onClick={() => {
                                  const summary = `Protocolo: ${msg.ticketData?.id}\nTipo: ${msg.ticketData?.type}\nDomínio: ${msg.ticketData?.domain || "N/A"}\nE-mail: ${msg.ticketData?.affectedEmail || "N/A"}`;
                                  navigator.clipboard.writeText(summary);
                                  setCopiedId(msg.ticketData?.id || "");
                                  setTimeout(() => setCopiedId(null), 2000);
                                }}
                                className="px-2 py-1 rounded-lg bg-[#202c33] hover:bg-[#2a3942] text-[10px] text-[#aebac1] border border-[#2a3942] transition-colors"
                              >
                                {copiedId === msg.ticketData.id ? "✓ Copiado" : "📋 Copiar"}
                              </button>
                            </div>

                            {onDeleteTicket && (
                              deletingTicketId === msg.ticketData.id ? (
                                <div className="flex items-center gap-1 bg-rose-500/20 border border-rose-500/50 rounded-lg px-1.5 py-0.5">
                                  <span className="text-[9px] text-rose-300 font-bold">Excluir?</span>
                                  <button
                                    type="button"
                                    onClick={() => {
                                      onDeleteTicket(msg.ticketData!.id);
                                      setDeletingTicketId(null);
                                    }}
                                    className="px-1.5 py-0.5 rounded bg-rose-600 hover:bg-rose-700 text-white text-[9px] font-bold"
                                  >
                                    Sim
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => setDeletingTicketId(null)}
                                    className="px-1 py-0.5 rounded bg-[#202c33] text-[#8696a0] text-[9px]"
                                  >
                                    Não
                                  </button>
                                </div>
                              ) : (
                                <button
                                  type="button"
                                  onClick={() => setDeletingTicketId(msg.ticketData.id)}
                                  className="p-1 rounded text-[#8696a0] hover:text-rose-400 hover:bg-rose-500/10 transition-colors"
                                  title="Excluir chamado"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              )
                            )}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Typing Indicator Bar */}
          {whoIsTyping && (
            <div className="px-4 py-1.5 bg-[#182229]/90 border-t border-[#222e35] text-[11px] text-[#00a884] flex items-center gap-2 font-medium animate-pulse">
              <span className="w-2 h-2 rounded-full bg-[#00a884] animate-ping"></span>
              <span>{whoIsTyping}</span>
            </div>
          )}

          {/* Quick Canned Popover (Floating above input on demand) */}
          {showQuickRepliesPopover && (
            <div className="absolute bottom-16 left-4 right-4 z-30 max-w-lg bg-[#202c33] border border-[#2a3942] rounded-xl p-3 shadow-2xl space-y-2 animate-in fade-in slide-in-from-bottom-2">
              <div className="flex items-center justify-between border-b border-[#2a3942] pb-1.5">
                <span className="text-xs font-bold text-white flex items-center gap-1.5">
                  <Zap className="w-3.5 h-3.5 text-amber-400" />
                  Modelos de Resposta Rápida
                </span>
                <button
                  type="button"
                  onClick={() => setShowQuickRepliesPopover(false)}
                  className="p-1 rounded text-[#8696a0] hover:text-white hover:bg-[#2a3942] cursor-pointer"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
              <div className="max-h-48 overflow-y-auto space-y-1.5 pr-1">
                {CANNED_RESPONSES.map((item, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => {
                      handleApplyCanned(item.text);
                      setShowQuickRepliesPopover(false);
                    }}
                    className="w-full text-left p-2 rounded-lg bg-[#182229] hover:bg-[#2a3942] border border-[#2a3942]/60 hover:border-[#00a884]/40 transition-colors group cursor-pointer"
                  >
                    <div className="text-[11px] font-bold text-white group-hover:text-[#00a884]">
                      {item.title}
                    </div>
                    <div className="text-[10px] text-[#8696a0] line-clamp-1">
                      {item.text}
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Live Agent Input Bar */}
          <form
            onSubmit={handleSendMessage}
            className="p-3 bg-[#202c33] border-t border-[#222e35] flex items-center gap-2 shrink-0 relative"
          >
            {/* Quick Canned Responses Toggle Button */}
            <button
              type="button"
              onClick={() => setShowQuickRepliesPopover(!showQuickRepliesPopover)}
              className={`p-2 rounded-xl border transition-colors cursor-pointer shrink-0 ${
                showQuickRepliesPopover
                  ? "bg-amber-400/20 text-amber-400 border-amber-400/50"
                  : "bg-[#182229] border-[#2a3942] text-[#8696a0] hover:text-amber-400 hover:border-amber-400/40"
              }`}
              title="Respostas Rápidas"
            >
              <Zap className="w-4 h-4" />
            </button>

            <input
              ref={inputRef}
              type="text"
              value={inputText}
              onChange={(e) => {
                setInputText(e.target.value);
                liveSync.sendTyping("agent", e.target.value.length > 0);
              }}
              placeholder={
                isHumanMode
                  ? "Digite sua resposta direta para o cliente..."
                  : "Digite para responder e assumir o atendimento..."
              }
              className="flex-1 bg-[#2a3942] text-[#e9edef] placeholder-[#8696a0] text-xs sm:text-sm px-4 py-2.5 rounded-xl border border-transparent focus:border-[#00a884] focus:outline-none transition-colors"
            />

            <button
              type="submit"
              disabled={!inputText.trim()}
              className="px-4 py-2.5 rounded-xl bg-[#00a884] hover:bg-[#029070] disabled:opacity-40 disabled:hover:bg-[#00a884] text-[#111b21] font-bold text-xs sm:text-sm flex items-center gap-1.5 transition-all shadow-md active:scale-95 shrink-0"
            >
              <Send className="w-4 h-4" />
              <span>{isHumanMode ? "Enviar" : "Assumir e Enviar"}</span>
            </button>
          </form>
        </div>

        {/* Right Column: Support Operator Tools & Customer Details (Collapsible Drawer) */}
        {isToolsOpen && (
          <aside
            aria-label="Painel de Ferramentas"
            className="w-full md:w-80 lg:w-96 bg-[#111b21] border-t md:border-t-0 md:border-l border-[#222e35] flex flex-col shrink-0 h-full z-20 transition-all animate-in slide-in-from-right duration-150"
          >
            {/* Header of Tools Drawer with Close Button */}
            <div className="h-14 px-4 bg-[#202c33] border-b border-[#222e35] flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2">
                <SlidersHorizontal className="w-4 h-4 text-[#00a884]" />
                <span className="text-xs font-bold text-white tracking-wide">Ferramentas do Operador</span>
              </div>
              <button
                type="button"
                onClick={() => setIsToolsOpen(false)}
                className="p-1.5 rounded-lg text-[#8696a0] hover:text-white hover:bg-[#2a3942] transition-colors cursor-pointer"
                title="Fechar painel de ferramentas"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          {/* Subheader Tabs */}
          <div className="flex border-b border-[#222e35] bg-[#182229]">
            <button
              onClick={() => setActiveTab("tickets")}
              className={`flex-1 py-2.5 text-xs font-semibold text-center border-b-2 transition-colors flex items-center justify-center gap-1 ${
                activeTab === "tickets"
                  ? "border-[#00a884] text-[#00a884] bg-[#202c33]/50"
                  : "border-transparent text-[#8696a0] hover:text-white"
              }`}
              title="Fila de Chamados e Protocolos para verificação do suporte"
            >
              <span>Chamados</span>
              {tickets.length > 0 && (
                <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-[#00a884]/20 text-[#00a884] font-bold">
                  {tickets.length}
                </span>
              )}
            </button>
            <button
              onClick={() => setActiveTab("canned")}
              className={`flex-1 py-2.5 text-xs font-semibold text-center border-b-2 transition-colors ${
                activeTab === "canned"
                  ? "border-[#00a884] text-[#00a884] bg-[#202c33]/50"
                  : "border-transparent text-[#8696a0] hover:text-white"
              }`}
            >
              Prontas
            </button>
            <button
              onClick={() => setActiveTab("notes")}
              className={`flex-1 py-2.5 text-xs font-semibold text-center border-b-2 transition-colors ${
                activeTab === "notes"
                  ? "border-[#00a884] text-[#00a884] bg-[#202c33]/50"
                  : "border-transparent text-[#8696a0] hover:text-white"
              }`}
            >
              Notas
            </button>
            <button
              onClick={() => setActiveTab("info")}
              className={`flex-1 py-2.5 text-xs font-semibold text-center border-b-2 transition-colors ${
                activeTab === "info"
                  ? "border-[#00a884] text-[#00a884] bg-[#202c33]/50"
                  : "border-transparent text-[#8696a0] hover:text-white"
              }`}
            >
              Cliente
            </button>
          </div>

          {/* Tab Content */}
          <div className="flex-1 overflow-y-auto p-3 space-y-3">
            {activeTab === "tickets" && (
              <div className="space-y-3">
                <div className="flex items-center justify-between px-1">
                  <div>
                    <h3 className="text-xs font-bold text-white uppercase tracking-wider">
                      Fila de Chamados N1/N2
                    </h3>
                    <p className="text-[10px] text-[#8696a0]">
                      {tickets.length} chamados registrados no sistema
                    </p>
                  </div>
                  <button
                    onClick={() => onOpenTriage("support_n2")}
                    className="px-2 py-1 rounded-lg bg-[#00a884] hover:bg-[#029070] text-[#111b21] font-bold text-[11px] flex items-center gap-1 transition-colors shadow-sm"
                    title="Registrar novo chamado"
                  >
                    <PlusCircle className="w-3 h-3" />
                    <span>Novo</span>
                  </button>
                </div>

                {/* Status Filter Pills */}
                <div className="flex items-center gap-1 overflow-x-auto pb-1 text-[10px] no-scrollbar">
                  {(
                    [
                      { key: "all", label: "Status: Todos" },
                      { key: "not_started", label: "Não Iniciados" },
                      { key: "in_progress", label: "Em Andamento" },
                      { key: "completed", label: "Concluídos" },
                    ] as const
                  ).map((f) => (
                    <button
                      key={f.key}
                      onClick={() => setTicketFilter(f.key)}
                      className={`px-2 py-0.5 rounded-full whitespace-nowrap transition-colors ${
                        ticketFilter === f.key
                          ? "bg-[#00a884]/20 text-[#00a884] font-semibold border border-[#00a884]/40"
                          : "bg-[#202c33] text-[#8696a0] hover:text-white"
                      }`}
                    >
                      {f.label}
                    </button>
                  ))}
                </div>

                {/* Department Filter Pills (Suporte, Comercial, Financeiro) */}
                <div className="flex items-center gap-1 overflow-x-auto pb-1 text-[10px] no-scrollbar">
                  {(
                    [
                      { key: "all", label: "Dept: Todos" },
                      { key: "support_n2", label: "🛠️ Suporte N2" },
                      { key: "commercial", label: "💼 Comercial" },
                      { key: "financial", label: "💳 Financeiro" },
                    ] as const
                  ).map((df) => (
                    <button
                      key={df.key}
                      onClick={() => setDeptFilter(df.key)}
                      className={`px-2 py-0.5 rounded-full whitespace-nowrap transition-colors ${
                        deptFilter === df.key
                          ? "bg-[#53bdeb]/20 text-[#53bdeb] font-semibold border border-[#53bdeb]/40"
                          : "bg-[#202c33] text-[#8696a0] hover:text-white"
                      }`}
                    >
                      {df.label}
                    </button>
                  ))}
                </div>

                {/* Tickets List */}
                <div className="space-y-2.5">
                  {tickets
                    .filter((t) => {
                      if (ticketFilter !== "all" && t.status !== ticketFilter) return false;
                      if (deptFilter !== "all" && t.type !== deptFilter) return false;
                      return true;
                    })
                    .map((t) => {
                      const deptName =
                        t.type === "support_n2"
                          ? "Suporte N2"
                          : t.type === "commercial"
                          ? "Comercial"
                          : "Financeiro";
                      const deptColor =
                        t.type === "support_n2"
                          ? "text-[#53bdeb] bg-[#53bdeb]/10 border-[#53bdeb]/30"
                          : t.type === "commercial"
                          ? "text-[#25d366] bg-[#25d366]/10 border-[#25d366]/30"
                          : "text-[#ffd279] bg-[#ffd279]/10 border-[#ffd279]/30";

                      return (
                        <div
                          key={t.id}
                          className="p-3 rounded-xl bg-[#182229] border border-[#222e35] hover:border-[#2a3942] transition-colors space-y-2 text-xs shadow-sm"
                        >
                          {/* Top Row: Code + Dept + Status */}
                          <div className="flex items-start justify-between gap-1.5">
                            <div>
                              <span className="font-mono font-bold text-white text-[11px] block">
                                {t.id}
                              </span>
                              <span
                                className={`inline-block px-1.5 py-0.2 rounded text-[9px] font-semibold border mt-0.5 ${deptColor}`}
                              >
                                {deptName}
                              </span>
                            </div>

                            {/* Status badge */}
                            <span
                              className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                                t.status === "completed"
                                  ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/40"
                                  : t.status === "in_progress"
                                  ? "bg-amber-500/20 text-amber-400 border border-amber-500/40"
                                  : t.status === "cancelled"
                                  ? "bg-zinc-500/20 text-zinc-400 border border-zinc-500/40"
                                  : "bg-rose-500/20 text-rose-400 border border-rose-500/40"
                              }`}
                            >
                              {t.status === "completed"
                                ? "Concluído"
                                : t.status === "in_progress"
                                ? "Em andamento"
                                : t.status === "cancelled"
                                ? "Cancelado"
                                : "Não iniciado"}
                            </span>
                          </div>

                          {/* Details */}
                          <div className="space-y-1 text-[11px] text-[#8696a0] bg-[#111b21] p-2 rounded-lg border border-[#222e35]">
                            {t.subject && (
                              <div className="text-white font-medium line-clamp-2">
                                {t.subject}
                              </div>
                            )}
                            {t.domain && (
                              <div className="truncate">
                                <span className="text-[#8696a0]">Domínio:</span>{" "}
                                <span className="text-[#e9edef] font-mono">{t.domain}</span>
                              </div>
                            )}
                            {t.affectedEmail && (
                              <div className="truncate">
                                <span className="text-[#8696a0]">E-mail:</span>{" "}
                                <span className="text-[#e9edef] font-mono">{t.affectedEmail}</span>
                              </div>
                            )}
                            {t.contactName && (
                              <div className="truncate">
                                <span className="text-[#8696a0]">Contato:</span>{" "}
                                <span className="text-[#e9edef]">{t.contactName}</span>
                              </div>
                            )}
                            {t.errorMessage && (
                              <div className="text-rose-400 line-clamp-2 font-mono text-[10px]">
                                Erro: {t.errorMessage}
                              </div>
                            )}

                            {/* Attached print for verification */}
                            {t.attachmentImage && (
                              <div className="pt-1.5 border-t border-[#222e35]">
                                <span className="text-[10px] text-[#00a884] flex items-center gap-1 font-semibold mb-1">
                                  <ImageIcon className="w-3 h-3" />
                                  Print do Erro Anexado:
                                </span>
                                <div
                                  className="relative rounded-lg overflow-hidden border border-[#2a3942] group cursor-pointer max-w-[180px]"
                                  onClick={() =>
                                    setLightboxImage({
                                      url: t.attachmentImage!.url,
                                      name: t.attachmentImage!.fileName || `Print do Chamado ${t.id}`,
                                    })
                                  }
                                >
                                  <img
                                    src={t.attachmentImage.url}
                                    alt="Print anexado"
                                    className="w-full h-20 object-cover group-hover:scale-105 transition-transform"
                                  />
                                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-white text-[10px] font-semibold gap-1">
                                    <Search className="w-3 h-3" />
                                    <span>Verificar</span>
                                  </div>
                                </div>
                              </div>
                            )}
                          </div>

                          {/* Quick Status Changers & Actions */}
                          <div className="flex items-center justify-between pt-1 gap-1.5 border-t border-[#222e35]">
                            <div className="flex items-center gap-1">
                              {t.status !== "in_progress" && t.status !== "completed" && (
                                <button
                                  onClick={() => handleStartTicketSupport(t)}
                                  className="px-2.5 py-1 rounded bg-[#202c33] hover:bg-[#2a3942] text-[10px] font-bold text-amber-400 border border-[#2a3942] hover:border-amber-400/50 transition-colors flex items-center gap-1 cursor-pointer shadow-sm"
                                  title="Iniciar atendimento direto deste chamado no chat"
                                >
                                  ▶️ Iniciar
                                </button>
                              )}
                              {t.status === "in_progress" && (
                                <>
                                  <button
                                    onClick={() => {
                                      inputRef.current?.focus();
                                      messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
                                    }}
                                    className="px-2 py-1 rounded bg-[#00a884]/20 hover:bg-[#00a884]/30 text-[10px] font-bold text-[#00a884] border border-[#00a884]/40 transition-colors flex items-center gap-1 cursor-pointer"
                                    title="Ir para a conversa ao vivo com o cliente"
                                  >
                                    💬 No Chat
                                  </button>
                                  <button
                                    onClick={() => handleOpenFinishModal(t.id)}
                                    className="px-2.5 py-1 rounded bg-emerald-600 hover:bg-emerald-500 text-[10px] font-bold text-white transition-colors flex items-center gap-1 cursor-pointer shadow-sm"
                                    title="Finalizar atendimento e solicitar avaliação do cliente"
                                  >
                                    <CheckCircle2 className="w-3 h-3" />
                                    <span>Finalizar Atendimento</span>
                                  </button>
                                </>
                              )}
                              {t.status !== "completed" && t.status !== "in_progress" && (
                                <button
                                  onClick={() => onUpdateTicketStatus && onUpdateTicketStatus(t.id, "completed")}
                                  className="px-2 py-1 rounded bg-[#202c33] hover:bg-[#2a3942] text-[10px] font-semibold text-[#00a884] border border-[#2a3942] transition-colors cursor-pointer"
                                  title="Marcar chamado como Concluído"
                                >
                                  ✅ Concluir
                                </button>
                              )}
                              <button
                                onClick={() => handleApplyCanned(`Referente ao seu chamado ${t.id} (${deptName}): já estamos verificando e retornaremos em instantes.`)}
                                className="px-2 py-1 rounded bg-[#202c33] hover:bg-[#2a3942] text-[10px] font-semibold text-[#53bdeb] border border-[#2a3942] transition-colors"
                                title="Inserir resposta sobre este chamado"
                              >
                                💬 Citar
                              </button>
                            </div>

                            {onDeleteTicket && (
                              deletingTicketId === t.id ? (
                                <div className="flex items-center gap-1.5 bg-rose-500/20 border border-rose-500/50 rounded-lg px-2 py-0.5 animate-in fade-in">
                                  <span className="text-[10px] text-rose-300 font-bold">Excluir?</span>
                                  <button
                                    type="button"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      onDeleteTicket(t.id);
                                      setDeletingTicketId(null);
                                    }}
                                    className="px-2 py-0.5 rounded bg-rose-600 hover:bg-rose-700 text-white text-[10px] font-bold transition-colors shadow-sm cursor-pointer"
                                    title="Confirmar exclusão definitiva do chamado"
                                  >
                                    Sim
                                  </button>
                                  <button
                                    type="button"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      setDeletingTicketId(null);
                                    }}
                                    className="px-1.5 py-0.5 rounded bg-[#202c33] hover:bg-[#2a3942] text-[#8696a0] hover:text-white text-[10px] transition-colors cursor-pointer"
                                    title="Cancelar"
                                  >
                                    Não
                                  </button>
                                </div>
                              ) : (
                                <button
                                  type="button"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setDeletingTicketId(t.id);
                                  }}
                                  className="p-1.5 rounded-lg text-[#8696a0] hover:text-rose-400 hover:bg-rose-500/15 border border-transparent hover:border-rose-500/30 transition-all cursor-pointer flex items-center gap-1"
                                  title="Excluir chamado da fila"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              )
                            )}
                          </div>
                        </div>
                      );
                    })}

                  {tickets.filter((t) => ticketFilter === "all" || t.status === ticketFilter).length === 0 && (
                    <div className="text-center py-6 text-xs text-[#8696a0]">
                      Nenhum chamado com este filtro.
                    </div>
                  )}
                </div>
              </div>
            )}

            {activeTab === "canned" && (
              <div className="space-y-2">
                <div className="text-[11px] font-semibold text-[#8696a0] uppercase tracking-wider px-1">
                  Modelos de Resposta Humana
                </div>
                {CANNED_RESPONSES.map((item, idx) => (
                  <div
                    key={idx}
                    className="p-2.5 rounded-xl bg-[#182229] border border-[#222e35] hover:border-[#00a884]/40 transition-colors group cursor-pointer"
                    onClick={() => handleApplyCanned(item.text)}
                  >
                    <div className="flex items-center justify-between text-xs font-bold text-white mb-1">
                      <span>{item.title}</span>
                      <span className="text-[10px] text-[#00a884] group-hover:underline">
                        Inserir ↵
                      </span>
                    </div>
                    <p className="text-[11px] text-[#8696a0] line-clamp-2 leading-relaxed">
                      {item.text}
                    </p>
                  </div>
                ))}
              </div>
            )}

            {activeTab === "notes" && (
              <div className="space-y-3">
                <div className="text-[11px] font-semibold text-[#8696a0] uppercase tracking-wider px-1">
                  Notas Privadas do Suporte (Cliente não vê)
                </div>

                <form onSubmit={handleAddNote} className="space-y-2">
                  <textarea
                    value={noteText}
                    onChange={(e) => setNoteText(e.target.value)}
                    placeholder="Adicionar nota interna sobre este chamado..."
                    rows={2}
                    className="w-full bg-[#182229] text-[#e9edef] placeholder-[#8696a0] text-xs p-2.5 rounded-xl border border-[#222e35] focus:border-[#00a884] focus:outline-none"
                  />
                  <button
                    type="submit"
                    disabled={!noteText.trim()}
                    className="w-full py-1.5 rounded-lg bg-[#202c33] hover:bg-[#2a3942] disabled:opacity-40 text-xs font-semibold text-[#00a884] border border-[#2a3942] transition-colors"
                  >
                    Salvar Nota Interna
                  </button>
                </form>

                <div className="space-y-2">
                  {(session?.internalNotes || []).length === 0 ? (
                    <div className="text-center py-4 text-xs text-[#8696a0]">
                      Nenhuma nota registrada nesta conversa.
                    </div>
                  ) : (
                    session?.internalNotes?.map((note) => (
                      <div
                        key={note.id}
                        className="p-2.5 rounded-xl bg-[#182229] border border-[#222e35] text-xs"
                      >
                        <div className="flex items-center justify-between text-[10px] text-[#8696a0] mb-1">
                          <span className="font-bold text-[#00a884]">{note.author}</span>
                          <span>
                            {new Date(note.timestamp).toLocaleTimeString("pt-BR", {
                              hour: "2-digit",
                              minute: "2-digit",
                            })}
                          </span>
                        </div>
                        <p className="text-white text-xs leading-relaxed">{note.text}</p>
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}

            {activeTab === "info" && (
              <div className="space-y-3 text-xs">
                <div className="p-3 rounded-xl bg-[#182229] border border-[#222e35] space-y-2">
                  <div className="text-[11px] font-bold text-[#8696a0] uppercase tracking-wide">
                    Identificação do Atendimento
                  </div>
                  <div className="flex items-center gap-2">
                    <User className="w-4 h-4 text-[#00a884]" />
                    <span className="font-semibold text-white">
                      {selectedClient?.name || session?.clientInfo.name || "Cliente Conectado"}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 text-[#8696a0]">
                    <Building className="w-4 h-4 text-[#8696a0]" />
                    <span>{selectedClient?.company || session?.clientInfo.company || "Empresa sob Consulta"}</span>
                  </div>
                  <div className="flex items-center gap-2 text-[#8696a0]">
                    <Phone className="w-4 h-4 text-[#8696a0]" />
                    <span>{selectedClient?.phone || session?.clientInfo.phone || "+55 (14) 99895-1113"}</span>
                  </div>
                </div>

                {/* Operator Identity config */}
                <div className="p-3 rounded-xl bg-[#182229] border border-[#222e35] space-y-2">
                  <div className="text-[11px] font-bold text-[#8696a0] uppercase tracking-wide">
                    Nome do Operador Ativo
                  </div>
                  <input
                    type="text"
                    value={agentName}
                    onChange={(e) => setAgentName(e.target.value)}
                    placeholder="Seu nome / Cargo"
                    className="w-full bg-[#202c33] text-white text-xs px-3 py-2 rounded-lg border border-[#2a3942] focus:border-[#00a884] focus:outline-none"
                  />
                  <p className="text-[10px] text-[#8696a0]">
                    Este nome aparecerá para o cliente como o atendente humano responsável.
                  </p>
                </div>

                {/* Transbordo e Abertura de Chamados (Exclusivo do Suporte) */}
                <div className="p-3.5 rounded-xl bg-[#182229] border border-[#222e35] space-y-2.5">
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                      <ShieldCheck className="w-3.5 h-3.5 text-[#00a884]" />
                      Transbordo & Chamados
                    </span>
                    <span className="text-[10px] text-[#00a884] font-semibold">Exclusivo do Suporte</span>
                  </div>
                  <p className="text-[10px] text-[#8696a0] leading-relaxed">
                    Opções internas para registrar ocorrências, direcionar para setores especializados e verificar informações do cliente.
                  </p>
                  <div className="grid grid-cols-1 gap-2 pt-1">
                    {/* 1. Suporte N2 */}
                    <button
                      onClick={() => onOpenTriage("support_n2")}
                      className="w-full p-2.5 rounded-xl bg-[#202c33] hover:bg-[#2a3942] text-left text-xs border border-[#53bdeb]/30 hover:border-[#53bdeb] transition-all flex items-center justify-between group shadow-sm"
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <div className="w-8 h-8 rounded-lg bg-[#53bdeb]/20 border border-[#53bdeb]/40 text-[#53bdeb] flex items-center justify-center shrink-0">
                          <Wrench className="w-4 h-4" />
                        </div>
                        <div className="min-w-0">
                          <div className="font-bold text-[#e9edef] group-hover:text-[#53bdeb] transition-colors truncate">
                            Suporte Técnico N2
                          </div>
                          <div className="text-[10px] text-[#8696a0] truncate">
                            Logs, IMAP/SMTP, Antispam, DNS e Servidores
                          </div>
                        </div>
                      </div>
                      <ChevronRight className="w-4 h-4 text-[#8696a0] group-hover:text-[#53bdeb] group-hover:translate-x-0.5 transition-all shrink-0 ml-1" />
                    </button>

                    {/* 2. Comercial */}
                    <button
                      onClick={() => onOpenTriage("commercial")}
                      className="w-full p-2.5 rounded-xl bg-[#202c33] hover:bg-[#2a3942] text-left text-xs border border-[#25d366]/30 hover:border-[#25d366] transition-all flex items-center justify-between group shadow-sm"
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <div className="w-8 h-8 rounded-lg bg-[#25d366]/20 border border-[#25d366]/40 text-[#25d366] flex items-center justify-center shrink-0">
                          <Building2 className="w-4 h-4" />
                        </div>
                        <div className="min-w-0">
                          <div className="font-bold text-[#e9edef] group-hover:text-[#25d366] transition-colors truncate">
                            Comercial & Propostas
                          </div>
                          <div className="text-[10px] text-[#8696a0] truncate">
                            Propostas Cloud, VPS Linux, E-mail e Upgrades
                          </div>
                        </div>
                      </div>
                      <ChevronRight className="w-4 h-4 text-[#8696a0] group-hover:text-[#25d366] group-hover:translate-x-0.5 transition-all shrink-0 ml-1" />
                    </button>

                    {/* 3. Financeiro */}
                    <button
                      onClick={() => onOpenTriage("financial")}
                      className="w-full p-2.5 rounded-xl bg-[#202c33] hover:bg-[#2a3942] text-left text-xs border border-[#ffd279]/30 hover:border-[#ffd279] transition-all flex items-center justify-between group shadow-sm"
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <div className="w-8 h-8 rounded-lg bg-[#ffd279]/20 border border-[#ffd279]/40 text-[#ffd279] flex items-center justify-center shrink-0">
                          <CreditCard className="w-4 h-4" />
                        </div>
                        <div className="min-w-0">
                          <div className="font-bold text-[#e9edef] group-hover:text-[#ffd279] transition-colors truncate">
                            Financeiro & Faturamento
                          </div>
                          <div className="text-[10px] text-[#8696a0] truncate">
                            2ª via de boleto, notas fiscais e faturas
                          </div>
                        </div>
                      </div>
                      <ChevronRight className="w-4 h-4 text-[#8696a0] group-hover:text-[#ffd279] group-hover:translate-x-0.5 transition-all shrink-0 ml-1" />
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </aside>
      )}
      </div>

      {/* Verification Lightbox Modal */}
      {lightboxImage && (
        <div
          className="fixed inset-0 z-50 bg-black/85 flex items-center justify-center p-4 backdrop-blur-sm animate-in fade-in"
          onClick={() => setLightboxImage(null)}
        >
          <div
            className="relative max-w-4xl max-h-[90vh] bg-[#111b21] border border-[#2a3942] rounded-2xl overflow-hidden flex flex-col shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="px-4 py-3 bg-[#202c33] border-b border-[#2a3942] flex items-center justify-between">
              <div className="flex items-center gap-2">
                <ImageIcon className="w-4 h-4 text-[#00a884]" />
                <span className="text-xs font-semibold text-white truncate max-w-md">
                  {lightboxImage.name}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <a
                  href={lightboxImage.url}
                  download={lightboxImage.name}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-1.5 rounded-lg text-[#aebac1] hover:text-white hover:bg-[#374248] transition-colors"
                  title="Baixar imagem"
                >
                  <Download className="w-4 h-4" />
                </a>
                <button
                  onClick={() => setLightboxImage(null)}
                  className="p-1.5 rounded-lg text-[#aebac1] hover:text-white hover:bg-[#374248] transition-colors"
                  title="Fechar (Esc)"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>
            <div className="p-2 overflow-auto flex items-center justify-center bg-[#0b141a]">
              <img
                src={lightboxImage.url}
                alt={lightboxImage.name}
                className="max-h-[75vh] w-auto object-contain rounded-lg"
              />
            </div>
          </div>
        </div>
      )}

      {/* Modal de Confirmação para Finalizar Atendimento */}
      {finishModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs animate-in fade-in">
          <div className="bg-[#202c33] border border-[#2a3942] rounded-2xl w-full max-w-md p-5 shadow-2xl space-y-4">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-emerald-500/20 text-emerald-400">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">Finalizar Atendimento?</h3>
                <p className="text-xs text-[#8696a0]">
                  Encerramento da sessão direta com o cliente
                </p>
              </div>
            </div>

            <p className="text-xs text-[#d1d7db] leading-relaxed bg-[#111b21] p-3 rounded-xl border border-[#2a3942]">
              Ao finalizar, o sistema enviará a mensagem de agradecimento e a <strong>pesquisa de avaliação por estrelas (CSAT)</strong> para o cliente avaliar o suporte prestado por <strong>{agentName}</strong>.
              {ticketToFinish && (
                <span className="block mt-2 text-amber-300 font-semibold">
                  📌 O chamado #{ticketToFinish} será marcado como Concluído.
                </span>
              )}
            </p>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => {
                  setFinishModalOpen(false);
                  setTicketToFinish(null);
                }}
                className="px-4 py-2 rounded-xl text-xs font-medium text-[#8696a0] hover:text-[#e9edef] hover:bg-[#2a3942] transition-colors cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={handleConfirmFinish}
                className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-md transition-all flex items-center gap-1.5 cursor-pointer active:scale-95"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Sim, Finalizar Atendimento</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
