import React, { useState, useRef, useEffect } from "react";
import ReactMarkdown from "react-markdown";
import {
  Send,
  User,
  Copy,
  Check,
  Building2,
  CreditCard,
  Wrench,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  Globe,
  KeyRound,
  Inbox,
  AlertTriangle,
  RefreshCw,
} from "lucide-react";
import { ComIALogo } from "./ComIALogo";
import { Message, TriageType } from "../types";

interface ChatWindowProps {
  messages: Message[];
  loading: boolean;
  onSendMessage: (text: string) => void;
  onOpenTriage: (type: TriageType) => void;
}

export const ChatWindow: React.FC<ChatWindowProps> = ({
  messages,
  loading,
  onSendMessage,
  onOpenTriage,
}) => {
  const [inputText, setInputText] = useState("");
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement | null>(null);
  const inputRef = useRef<HTMLInputElement | null>(null);

  const quickPrompts = [
    { label: "⚙️ Portas IMAP/SMTP/POP3", text: "Quais são as portas e servidores oficiais de IMAP, POP e SMTP da ComBR?" },
    { label: "🔑 Esqueceu a Senha", text: "Esqueci a senha do meu e-mail corporativo. Como redefinir?" },
    { label: "📥 Caixa Cheia / Cota Excedida", text: "Minha caixa postal está cheia e atingiu o limite de espaço. O que fazer?" },
    { label: "🚫 Erro de Envio / Bounce", text: "Meu e-mail retornou com erro de entrega (Undelivered / Bounce). Como resolver?" },
    { label: "🛡️ Mensagens no AntiSpam", text: "Como liberar mensagens retidas no filtro de AntiSpam pelo Webmail?" },
    { label: "💳 2ª Via de Boleto / NF", text: "Preciso da segunda via do meu boleto e nota fiscal da ComBR." },
    { label: "💼 Orçamento de E-mail & Cloud", text: "Gostaria de solicitar um orçamento para novas contas de e-mail corporativo e hospedagem Cloud." },
    { label: "🛠️ Problemas de DNS / Migração (N2)", text: "Estou com falha grave de DNS e preciso de suporte N2 para migração de e-mail." },
  ];

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, loading]);

  const handleSend = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const trimmed = inputText.trim();
    if (!trimmed || loading) return;
    onSendMessage(trimmed);
    setInputText("");
  };

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const formatTime = (isoString: string) => {
    try {
      const date = new Date(isoString);
      return date.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });
    } catch {
      return "";
    }
  };

  return (
    <div id="chat-window-container" className="flex flex-col h-[740px] max-h-[82vh] bg-slate-900/90 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden backdrop-blur-sm">
      {/* Header bar in chat */}
      <div className="px-5 py-3 border-b border-slate-800 bg-slate-950/70 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="relative">
            <ComIALogo size="sm" showText={false} />
            <span className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 bg-emerald-400 border-2 border-slate-950 rounded-full"></span>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-slate-100">ComIA</span>
              <span className="text-[10px] text-sky-400 bg-sky-500/10 px-1.5 py-0.2 rounded border border-sky-500/30">
                Atendimento Inteligente
              </span>
            </div>
            <p className="text-[11px] text-slate-400">Suporte N1 ComBR • Disponível 24/7</p>
          </div>
        </div>

        <div className="flex items-center gap-1.5 text-xs text-slate-400">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
          <span className="text-[11px]">Online</span>
        </div>
      </div>

      {/* Messages viewport */}
      <div id="chat-messages-viewport" className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
        {messages.map((msg) => {
          const isAssistant = msg.sender === "assistant";
          const isSystem = msg.sender === "system";
          const isCopied = copiedId === msg.id;

          const contentLower = msg.content.toLowerCase();

          // Triage detectors
          const isFinanceTopic =
            contentLower.includes("financeir") ||
            contentLower.includes("boleto") ||
            contentLower.includes("fatura") ||
            contentLower.includes("nota fiscal");

          const isSalesTopic =
            contentLower.includes("comercial") ||
            contentLower.includes("vendas") ||
            contentLower.includes("orçamento") ||
            contentLower.includes("cotação") ||
            contentLower.includes("contratar") ||
            contentLower.includes("aws") ||
            contentLower.includes("oracle");

          const isN2Topic =
            contentLower.includes("n2") ||
            contentLower.includes("dns") ||
            contentLower.includes("migração") ||
            contentLower.includes("migracao") ||
            contentLower.includes("servidor dedicado") ||
            contentLower.includes("erro persistente") ||
            contentLower.includes("especializado");

          const mentionsTriage =
            isAssistant &&
            (contentLower.includes("transferir") ||
              contentLower.includes("atendente humano") ||
              contentLower.includes("equipe humana") ||
              contentLower.includes("cnpj") ||
              contentLower.includes("razão social") ||
              contentLower.includes("suporte n2") ||
              contentLower.includes("domínio"));

          return (
            <div
              key={msg.id}
              className={`flex gap-3 ${isAssistant ? "justify-start" : isSystem ? "justify-center" : "justify-end"}`}
            >
              {isAssistant && (
                <div className="shrink-0 mt-0.5">
                  <div className="w-8 h-8 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-center shadow-md">
                    <ComIALogo size="sm" showText={false} />
                  </div>
                </div>
              )}

              <div
                className={`group relative max-w-[88%] sm:max-w-[82%] rounded-2xl p-4 text-xs sm:text-sm transition-all ${
                  isAssistant
                    ? "bg-slate-950/85 border border-slate-800/90 text-slate-100 shadow-sm"
                    : isSystem
                    ? "bg-sky-950/40 border border-sky-500/30 text-sky-200 text-center text-xs py-2.5 px-4"
                    : "bg-sky-600 text-white shadow-md shadow-sky-600/20"
                }`}
              >
                {/* Header label & time */}
                <div className="flex items-center justify-between gap-3 mb-1.5 opacity-75 text-[11px]">
                  <span className="font-semibold">
                    {isAssistant ? "ComIA • Suporte N1" : isSystem ? "Protocolo de Sistema" : "Você"}
                  </span>
                  <span>{formatTime(msg.timestamp)}</span>
                </div>

                {/* Message Body */}
                <div className="leading-relaxed break-words space-y-2 prose prose-invert max-w-none text-xs sm:text-sm prose-p:my-1.5 prose-ul:my-1.5 prose-ol:my-1.5 prose-li:my-0.5 prose-pre:my-2 prose-pre:bg-slate-900 prose-pre:border prose-pre:border-slate-800 prose-code:text-sky-300 prose-code:bg-slate-900/90 prose-code:px-1.5 prose-code:py-0.5 prose-code:rounded prose-code:text-[11px] prose-code:before:content-none prose-code:after:content-none">
                  <ReactMarkdown>{msg.content}</ReactMarkdown>
                </div>

                {/* Interactive Triage Buttons when appropriate */}
                {mentionsTriage && (
                  <div className="mt-3.5 pt-3 border-t border-slate-800/80 flex flex-wrap items-center gap-2">
                    {isFinanceTopic && (
                      <button
                        id={`btn-triage-fin-${msg.id}`}
                        onClick={() => onOpenTriage("financial")}
                        className="px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors border bg-amber-500/10 hover:bg-amber-500/20 border-amber-500/30 text-amber-300"
                      >
                        <CreditCard className="w-3.5 h-3.5 text-amber-400" />
                        <span>Transferir para Financeiro (Informar CNPJ)</span>
                        <ArrowRight className="w-3 h-3 ml-0.5" />
                      </button>
                    )}

                    {isSalesTopic && (
                      <button
                        id={`btn-triage-com-${msg.id}`}
                        onClick={() => onOpenTriage("commercial")}
                        className="px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors border bg-emerald-500/10 hover:bg-emerald-500/20 border-emerald-500/30 text-emerald-300"
                      >
                        <Building2 className="w-3.5 h-3.5 text-emerald-400" />
                        <span>Transferir para Comercial (Informar Dados)</span>
                        <ArrowRight className="w-3 h-3 ml-0.5" />
                      </button>
                    )}

                    {isN2Topic && (
                      <button
                        id={`btn-triage-n2-${msg.id}`}
                        onClick={() => onOpenTriage("support_n2")}
                        className="px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors border bg-sky-500/10 hover:bg-sky-500/20 border-sky-500/30 text-sky-300"
                      >
                        <Wrench className="w-3.5 h-3.5 text-sky-400" />
                        <span>Abrir Chamado Suporte N2 Especializado</span>
                        <ArrowRight className="w-3 h-3 ml-0.5" />
                      </button>
                    )}

                    {!isFinanceTopic && !isSalesTopic && !isN2Topic && (
                      <button
                        id={`btn-triage-general-${msg.id}`}
                        onClick={() => onOpenTriage("support_n2")}
                        className="px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors border bg-sky-500/10 hover:bg-sky-500/20 border-sky-500/30 text-sky-300"
                      >
                        <Wrench className="w-3.5 h-3.5 text-sky-400" />
                        <span>Transferir Atendimento para Humano</span>
                        <ArrowRight className="w-3 h-3 ml-0.5" />
                      </button>
                    )}
                  </div>
                )}

                {/* Copy button */}
                {isAssistant && (
                  <button
                    id={`btn-copy-msg-${msg.id}`}
                    onClick={() => handleCopy(msg.content, msg.id)}
                    className="absolute top-3 right-3 opacity-0 group-hover:opacity-100 transition-opacity p-1 text-slate-400 hover:text-sky-400 bg-slate-900/90 border border-slate-800 rounded-md"
                    title="Copiar mensagem"
                  >
                    {isCopied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                )}
              </div>

              {!isAssistant && !isSystem && (
                <div className="w-8 h-8 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center text-slate-300 shrink-0">
                  <User className="w-4 h-4" />
                </div>
              )}
            </div>
          );
        })}

        {/* Typing indicator */}
        {loading && (
          <div className="flex gap-3 justify-start items-center">
            <div className="w-8 h-8 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-center shrink-0">
              <ComIALogo size="sm" showText={false} />
            </div>
            <div className="bg-slate-950/80 border border-slate-800 rounded-2xl px-4 py-3 text-xs text-slate-400 flex items-center gap-2">
              <div className="flex items-center gap-1.5 h-3 px-1">
                <span className="typing-dot !bg-sky-400"></span>
                <span className="typing-dot !bg-sky-400"></span>
                <span className="typing-dot !bg-sky-400"></span>
              </div>
              <span className="ml-1 text-[11px]">ComIA digitando...</span>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Suggested prompts carousel */}
      <div id="quick-prompts-bar" className="px-4 py-2.5 bg-slate-950/60 border-t border-slate-800/80 overflow-x-auto no-scrollbar flex items-center gap-2">
        <span className="text-[11px] text-slate-400 shrink-0 font-medium flex items-center gap-1">
          <Sparkles className="w-3 h-3 text-sky-400" />
          Atalhos N1:
        </span>
        {quickPrompts.map((prompt, index) => (
          <button
            key={index}
            id={`btn-quick-prompt-${index}`}
            onClick={() => onSendMessage(prompt.text)}
            className="px-2.5 py-1 text-xs text-slate-300 bg-slate-900 hover:bg-slate-800 hover:text-sky-300 border border-slate-800 hover:border-sky-500/40 rounded-full transition-all whitespace-nowrap shrink-0"
          >
            {prompt.label}
          </button>
        ))}
      </div>

      {/* Message input bar */}
      <form onSubmit={handleSend} className="p-3 sm:p-4 bg-slate-950/80 border-t border-slate-800">
        <div className="relative flex items-center">
          <input
            id="chat-input-text"
            ref={inputRef}
            type="text"
            placeholder="Pergunte sobre e-mail corporativo, webmail, senhas, erros, ou triagem comercial/financeira..."
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            disabled={loading}
            className="w-full pl-4 pr-12 py-3 bg-slate-900/90 border border-slate-800 focus:border-sky-500 rounded-xl text-xs sm:text-sm text-slate-100 placeholder-slate-400 focus:outline-none transition-all shadow-inner"
          />
          <button
            id="btn-send-chat-message"
            type="submit"
            disabled={!inputText.trim() || loading}
            className="absolute right-2 p-2 bg-sky-600 hover:bg-sky-500 disabled:opacity-40 disabled:hover:bg-sky-600 text-white rounded-lg transition-colors shadow-sm"
            title="Enviar mensagem"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
        <div className="flex items-center justify-between mt-2 px-1 text-[11px] text-slate-400">
          <span>Pressione <strong>Enter</strong> para enviar</span>
          <span>ComBR Soluções em Nuvem • ComIA</span>
        </div>
      </form>
    </div>
  );
};
