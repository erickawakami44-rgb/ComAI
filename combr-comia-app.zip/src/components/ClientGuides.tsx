import React, { useState } from "react";
import {
  Smartphone,
  Laptop,
  CheckCircle2,
  ChevronDown,
  KeyRound,
  Inbox,
  AlertTriangle,
  ShieldCheck,
  Globe,
  ExternalLink,
} from "lucide-react";

export const ClientGuides: React.FC = () => {
  const [activeTab, setActiveTab] = useState<"outlook" | "thunderbird" | "ios" | "android" | "n1troubleshoot">("outlook");

  return (
    <div id="combr-client-guides" className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl backdrop-blur-sm">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-4 mb-4 border-b border-slate-800">
        <div>
          <h3 className="text-sm font-semibold text-slate-100">Guias de Configuração & Soluções N1</h3>
          <p className="text-xs text-slate-400">Passo a passo resumido para aplicativos e diagnósticos</p>
        </div>

        {/* Tab selector */}
        <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-xl border border-slate-800 overflow-x-auto no-scrollbar">
          <button
            id="tab-guide-outlook"
            onClick={() => setActiveTab("outlook")}
            className={`px-2.5 py-1 text-xs font-semibold rounded-lg transition-all whitespace-nowrap ${
              activeTab === "outlook"
                ? "bg-sky-600 text-white shadow-sm"
                : "text-slate-400 hover:text-slate-200"
            }`}
          >
            Outlook
          </button>
          <button
            id="tab-guide-thunderbird"
            onClick={() => setActiveTab("thunderbird")}
            className={`px-2.5 py-1 text-xs font-semibold rounded-lg transition-all whitespace-nowrap ${
              activeTab === "thunderbird"
                ? "bg-sky-600 text-white shadow-sm"
                : "text-slate-400 hover:text-slate-200"
            }`}
          >
            Thunderbird
          </button>
          <button
            id="tab-guide-ios"
            onClick={() => setActiveTab("ios")}
            className={`px-2.5 py-1 text-xs font-semibold rounded-lg transition-all whitespace-nowrap ${
              activeTab === "ios"
                ? "bg-sky-600 text-white shadow-sm"
                : "text-slate-400 hover:text-slate-200"
            }`}
          >
            iPhone (iOS)
          </button>
          <button
            id="tab-guide-android"
            onClick={() => setActiveTab("android")}
            className={`px-2.5 py-1 text-xs font-semibold rounded-lg transition-all whitespace-nowrap ${
              activeTab === "android"
                ? "bg-sky-600 text-white shadow-sm"
                : "text-slate-400 hover:text-slate-200"
            }`}
          >
            Android
          </button>
          <button
            id="tab-guide-n1"
            onClick={() => setActiveTab("n1troubleshoot")}
            className={`px-2.5 py-1 text-xs font-semibold rounded-lg transition-all whitespace-nowrap ${
              activeTab === "n1troubleshoot"
                ? "bg-indigo-600 text-white shadow-sm"
                : "text-slate-400 hover:text-slate-200"
            }`}
          >
            Diagnósticos N1
          </button>
        </div>
      </div>

      {/* Guide Content */}
      <div className="text-xs text-slate-300">
        {activeTab === "outlook" && (
          <div className="space-y-3">
            <h4 className="font-semibold text-slate-100 flex items-center gap-1.5 text-xs">
              <Laptop className="w-4 h-4 text-sky-400" />
              Configuração no Microsoft Outlook (Windows / Mac):
            </h4>
            <ol className="space-y-2 list-decimal list-inside text-slate-300 pl-1">
              <li>Acesse <strong>Arquivo &gt; Adicionar Conta</strong>.</li>
              <li>Digite seu e-mail corporativo completo (<code className="text-sky-300">seuemail@seudominio.com.br</code>), marque <strong>Configurar conta manualmente</strong> e clique em <strong>Conectar</strong>.</li>
              <li>Escolha a opção <strong>IMAP</strong>.</li>
              <li>Preencha os servidores de entrada e saída:
                <div className="mt-1.5 ml-4 p-2.5 bg-slate-950/80 rounded-xl border border-slate-800 font-mono space-y-1 text-[11px]">
                  <div>• Entrada (IMAP): <span className="text-sky-300 font-semibold">imap.combr.com.br</span> | Porta: <span className="text-sky-300 font-semibold">993</span> | Método: <span className="text-emerald-300">SSL/TLS</span></div>
                  <div>• Saída (SMTP): <span className="text-sky-300 font-semibold">smtp.combr.com.br</span> | Porta: <span className="text-sky-300 font-semibold">465</span> (SSL/TLS) ou <span className="text-sky-300 font-semibold">587</span> (STARTTLS)</div>
                </div>
              </li>
              <li>Em <strong>Servidor de Saída</strong>, certifique-se de que a opção <strong>"Meu servidor de saída (SMTP) requer autenticação"</strong> está marcada e usando as mesmas credenciais.</li>
              <li>Digite sua senha e clique em <strong>Avançar/Concluir</strong>.</li>
            </ol>
          </div>
        )}

        {activeTab === "thunderbird" && (
          <div className="space-y-3">
            <h4 className="font-semibold text-slate-100 flex items-center gap-1.5 text-xs">
              <Laptop className="w-4 h-4 text-sky-400" />
              Configuração no Mozilla Thunderbird:
            </h4>
            <ol className="space-y-2 list-decimal list-inside text-slate-300 pl-1">
              <li>Abra o Thunderbird e selecione <strong>Configurações de Conta &gt; Ações de Conta &gt; Nova Conta de E-mail</strong>.</li>
              <li>Informe seu Nome, E-mail completo e Senha. Clique em <strong>Configurar manualmente</strong>.</li>
              <li>Configure os seguintes dados:
                <div className="mt-1.5 ml-4 p-2.5 bg-slate-950/80 rounded-xl border border-slate-800 font-mono space-y-1 text-[11px]">
                  <div>• Recebimento: <span className="text-sky-300">IMAP</span> | Host: <span className="text-sky-300 font-semibold">imap.combr.com.br</span> | Porta: <span className="text-sky-300 font-semibold">993</span> | SSL/TLS | Senha normal</div>
                  <div>• Envio: <span className="text-sky-300">SMTP</span> | Host: <span className="text-sky-300 font-semibold">smtp.combr.com.br</span> | Porta: <span className="text-sky-300 font-semibold">465</span> | SSL/TLS | Senha normal</div>
                  <div>• Nome de Usuário: Sempre o e-mail completo</div>
                </div>
              </li>
              <li>Clique em <strong>Testar novamente</strong> e depois em <strong>Pronto</strong>.</li>
            </ol>
          </div>
        )}

        {activeTab === "ios" && (
          <div className="space-y-3">
            <h4 className="font-semibold text-slate-100 flex items-center gap-1.5 text-xs">
              <Smartphone className="w-4 h-4 text-sky-400" />
              Configuração no iPhone / iPad (Apple Mail iOS):
            </h4>
            <ol className="space-y-2 list-decimal list-inside text-slate-300 pl-1">
              <li>Vá em <strong>Ajustes &gt; Mail &gt; Contas &gt; Adicionar Conta</strong>.</li>
              <li>Escolha <strong>Outra &gt; Adicionar Conta de E-mail</strong>.</li>
              <li>Preencha Nome, E-mail completo, Senha e Descrição. Clique em <strong>Seguinte</strong>.</li>
              <li>Certifique-se de que a aba <strong>IMAP</strong> está selecionada:
                <div className="mt-1.5 ml-4 p-2.5 bg-slate-950/80 rounded-xl border border-slate-800 font-mono space-y-1 text-[11px]">
                  <div>• Servidor de Entrada: Nome do Host: <span className="text-sky-300 font-semibold">imap.combr.com.br</span> | Usuário: seu e-mail completo | Senha: sua senha</div>
                  <div>• Servidor de Saída: Nome do Host: <span className="text-sky-300 font-semibold">smtp.combr.com.br</span> | Usuário: seu e-mail completo | Senha: sua senha</div>
                </div>
              </li>
              <li>Clique em <strong>Salvar</strong>. O iOS validará automaticamente com SSL nas portas 993 e 465.</li>
            </ol>
          </div>
        )}

        {activeTab === "android" && (
          <div className="space-y-3">
            <h4 className="font-semibold text-slate-100 flex items-center gap-1.5 text-xs">
              <Smartphone className="w-4 h-4 text-sky-400" />
              Configuração no Android (Gmail App ou Samsung Mail):
            </h4>
            <ol className="space-y-2 list-decimal list-inside text-slate-300 pl-1">
              <li>Abra o aplicativo de e-mail e vá em <strong>Adicionar conta &gt; Outra</strong>.</li>
              <li>Digite seu e-mail corporativo completo e toque em <strong>Configuração manual &gt; Pessoal (IMAP)</strong>.</li>
              <li>Insira a senha do e-mail.</li>
              <li>Na tela de entrada: Servidor: <code className="text-sky-300">imap.combr.com.br</code> | Porta: <code className="text-sky-300">993</code> | Tipo de segurança: <code className="text-emerald-300">SSL/TLS</code>.</li>
              <li>Na tela de saída: Servidor: <code className="text-sky-300">smtp.combr.com.br</code> | Porta: <code className="text-sky-300">465</code> | Tipo de segurança: <code className="text-emerald-300">SSL/TLS</code> | Exigir login: <strong>Ativado</strong>.</li>
              <li>Conclua o assistente.</li>
            </ol>
          </div>
        )}

        {activeTab === "n1troubleshoot" && (
          <div className="space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {/* Esqueceu Senha */}
              <div className="bg-slate-950/80 p-3 rounded-xl border border-slate-800 space-y-1.5">
                <div className="flex items-center gap-1.5 text-sky-400 font-semibold text-xs">
                  <KeyRound className="w-4 h-4" />
                  <span>Esqueceu a Senha?</span>
                </div>
                <p className="text-[11px] text-slate-300">
                  Solicite a redefinição diretamente ao <strong>Administrador de TI</strong> da sua empresa. Se for o titular do contrato ComBR, acesse o painel administrativo.
                </p>
              </div>

              {/* Caixa Cheia */}
              <div className="bg-slate-950/80 p-3 rounded-xl border border-slate-800 space-y-1.5">
                <div className="flex items-center gap-1.5 text-amber-400 font-semibold text-xs">
                  <Inbox className="w-4 h-4" />
                  <span>Caixa Cheia / Cota</span>
                </div>
                <p className="text-[11px] text-slate-300">
                  Acesse o Webmail (webmail.combr.com.br) e esvazie mensagens antigas e a pasta <strong>Lixeira</strong>. Ou solicite aumento de espaço comercial.
                </p>
              </div>

              {/* Bounce */}
              <div className="bg-slate-950/80 p-3 rounded-xl border border-slate-800 space-y-1.5">
                <div className="flex items-center gap-1.5 text-rose-400 font-semibold text-xs">
                  <AlertTriangle className="w-4 h-4" />
                  <span>E-mail Retornou (Bounce)</span>
                </div>
                <p className="text-[11px] text-slate-300">
                  Envie o código de erro (ex: 550, 554) contido no relatório de entrega para que a ComIA ou o Suporte N2 analise a causa do bloqueio.
                </p>
              </div>

              {/* AntiSpam */}
              <div className="bg-slate-950/80 p-3 rounded-xl border border-slate-800 space-y-1.5">
                <div className="flex items-center gap-1.5 text-emerald-400 font-semibold text-xs">
                  <ShieldCheck className="w-4 h-4" />
                  <span>Filtro AntiSpam</span>
                </div>
                <p className="text-[11px] text-slate-300">
                  Mensagens retidas podem ser liberadas diretamente pelo Webmail marcando o remetente como <strong>Confiável / Não é Spam</strong>.
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
