import React from "react";

interface ComIALogoProps {
  size?: "xs" | "sm" | "md" | "lg" | "xl";
  showText?: boolean;
  withBackground?: boolean;
  className?: string;
}

export const ComIALogo: React.FC<ComIALogoProps> = ({
  size = "md",
  showText = true,
  withBackground = false,
  className = "",
}) => {
  const iconDimensions = {
    xs: "w-5 h-5",
    sm: "w-8 h-8",
    md: "w-10 h-10",
    lg: "w-16 h-16",
    xl: "w-24 h-24",
  };

  const textSizes = {
    xs: "text-xs",
    sm: "text-base",
    md: "text-xl",
    lg: "text-3xl",
    xl: "text-5xl",
  };

  const emblem = (
    <div
      className={`relative flex items-center justify-center shrink-0 rounded-full select-none ${iconDimensions[size]}`}
      style={{ aspectRatio: "1/1" }}
    >
      <svg
        viewBox="0 0 200 200"
        className="w-full h-full block"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          {/* Deep Navy Circular Background Gradient */}
          <radialGradient id="navyBgGrad" cx="50%" cy="50%" r="65%">
            <stop offset="0%" stopColor="#08183c" />
            <stop offset="60%" stopColor="#040e24" />
            <stop offset="100%" stopColor="#020612" />
          </radialGradient>

          {/* Outer Royal/Cobalt Blue Gradient */}
          <linearGradient id="crescentOuterBlue" x1="15%" y1="10%" x2="85%" y2="90%">
            <stop offset="0%" stopColor="#2563eb" />
            <stop offset="30%" stopColor="#1d4ed8" />
            <stop offset="70%" stopColor="#1e40af" />
            <stop offset="100%" stopColor="#172554" />
          </linearGradient>

          {/* Middle Lime-Green Gradient */}
          <linearGradient id="crescentMiddleLime" x1="20%" y1="10%" x2="80%" y2="90%">
            <stop offset="0%" stopColor="#d9f99d" />
            <stop offset="25%" stopColor="#bef264" />
            <stop offset="65%" stopColor="#84cc16" />
            <stop offset="100%" stopColor="#4d7c0f" />
          </linearGradient>

          {/* Inner Sky-Blue Gradient */}
          <linearGradient id="crescentInnerBlue" x1="25%" y1="15%" x2="75%" y2="85%">
            <stop offset="0%" stopColor="#60a5fa" />
            <stop offset="35%" stopColor="#3b82f6" />
            <stop offset="75%" stopColor="#1d4ed8" />
            <stop offset="100%" stopColor="#1e3a8a" />
          </linearGradient>

          {/* Drop Shadows for 3D Depth */}
          <filter id="crescentShadow" x="-20%" y="-20%" width="140%" height="140%">
            <feDropShadow dx="-2" dy="4" stdDeviation="4" floodColor="#000000" floodOpacity="0.6" />
          </filter>
        </defs>

        {/* Circular Deep Navy Background */}
        <circle cx="100" cy="100" r="100" fill="url(#navyBgGrad)" />

        {/* 3D Crescent Graphic Group */}
        <g filter="url(#crescentShadow)">
          {/* 1. Outer Royal Blue Arc */}
          <path
            d="M 100 24
               C 124 24, 146 33, 162 48
               C 142 42, 118 42, 94 52
               C 66 65, 50 94, 52 124
               C 55 152, 78 174, 108 176
               C 134 178, 158 164, 172 144
               C 174 141, 170 138, 166 141
               C 150 155, 130 162, 108 160
               C 84 158, 66 140, 64 116
               C 62 92, 76 68, 98 56
               C 118 46, 140 48, 158 56
               C 162 58, 164 54, 160 50
               C 144 34, 122 24, 100 24 Z"
            fill="url(#crescentOuterBlue)"
          />

          {/* 1b. Outer Blue Back Extension */}
          <path
            d="M 100 24
               C 120 24, 138 30, 152 42
               C 155 45, 151 48, 147 46
               C 133 38, 117 34, 100 34
               C 63 34, 34 63, 34 100
               C 34 137, 63 166, 100 166
               C 126 166, 149 151, 160 130
               C 163 125, 168 130, 164 135
               C 151 160, 127 176, 100 176
               C 58 176, 24 142, 24 100
               C 24 58, 58 24, 100 24 Z"
            fill="url(#crescentOuterBlue)"
            opacity="0.95"
          />

          {/* 2. Middle Lime-Green Arc */}
          <path
            d="M 106 28
               C 128 28, 148 38, 164 54
               C 146 48, 124 48, 102 56
               C 76 66, 62 92, 64 120
               C 66 146, 86 166, 112 168
               C 134 170, 154 158, 166 140
               C 168 137, 164 134, 161 137
               C 146 150, 128 156, 110 154
               C 88 152, 72 136, 70 114
               C 68 92, 80 72, 100 62
               C 118 52, 138 54, 154 62
               C 158 64, 160 60, 156 56
               C 142 40, 124 28, 106 28 Z"
            fill="url(#crescentMiddleLime)"
          />

          {/* 3. Inner Sky-Blue Arc */}
          <path
            d="M 114 42
               C 134 44, 152 56, 164 74
               C 148 68, 128 66, 108 74
               C 84 84, 72 106, 74 130
               C 76 150, 92 164, 114 164
               C 132 164, 148 154, 158 140
               C 160 137, 156 134, 153 137
               C 141 146, 127 150, 112 148
               C 94 146, 82 134, 80 118
               C 78 100, 88 84, 104 76
               C 120 68, 136 70, 150 78
               C 154 80, 156 76, 152 72
               C 142 58, 128 46, 114 42 Z"
            fill="url(#crescentInnerBlue)"
          />
        </g>
      </svg>
    </div>
  );

  if (withBackground) {
    return (
      <div
        className={`relative inline-flex items-center justify-center p-2 rounded-full select-none ${className}`}
      >
        <div className="flex items-center gap-3">
          {emblem}
          {showText && (
            <div className="flex items-baseline font-bold tracking-tight">
              <span className={`${textSizes[size]} text-white font-extrabold`}>Com</span>
              <span className={`${textSizes[size]} text-[#84cc16] font-extrabold`}>I</span>
              <span className={`${textSizes[size]} text-[#3b82f6] font-extrabold`}>A</span>
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className={`inline-flex items-center gap-2.5 select-none ${className}`}>
      {emblem}
      {showText && (
        <div className="flex items-baseline font-bold tracking-tight">
          <span className={`${textSizes[size]} text-white font-extrabold tracking-tight`}>Com</span>
          <span className={`${textSizes[size]} text-[#84cc16] font-extrabold`}>I</span>
          <span className={`${textSizes[size]} text-[#3b82f6] font-extrabold`}>A</span>
        </div>
      )}
    </div>
  );
};
