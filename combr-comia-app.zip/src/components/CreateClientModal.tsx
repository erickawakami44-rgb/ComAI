import React, { useState } from "react";
import {
  X,
  UserPlus,
  Sparkles,
  MessageSquare,
  Building,
  Phone,
  Globe,
  Check,
  RotateCcw,
  Bot,
  Zap,
} from "lucide-react";
import { WhatsAppClientChat, Message } from "../types";
import {
  PRESET_SCENARIOS,
  RANDOM_NAMES,
  AVATAR_COLORS,
  getInitials,
} from "../lib/mockClients";

interface CreateClientModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCreateClient: (newChat: WhatsAppClientChat) => void;
  onResetToDemoClients: () => void;
}

export const CreateClientModal: React.FC<CreateClientModalProps> = ({
  isOpen,
  onClose,
  onCreateClient,
  onResetToDemoClients,
}) => {
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [company, setCompany] = useState("");
  const [domain, setDomain] = useState("");
  const [category, setCategory] = useState<"support_n2" | "commercial" | "financial" | "general">("support_n2");
  const [selectedScenarioId, setSelectedScenarioId] = useState<string>("smtp_error");
  const [firstMessage, setFirstMessage] = useState(PRESET_SCENARIOS[0].firstMessage);
  const [includeBotReply, setIncludeBotReply] = useState(true);
  const [markAsUnread, setMarkAsUnread] = useState(true);

  if (!isOpen) return null;

  const handleSelectScenario = (scenarioId: string) => {
    setSelectedScenarioId(scenarioId);
    const scen = PRESET_SCENARIOS.find((s) => s.id === scenarioId);
    if (scen) {
      setCategory(scen.category);
      setFirstMessage(scen.firstMessage);
    }
  };

  const handleFillRandomData = () => {
    const randomPick = RANDOM_NAMES[Math.floor(Math.random() * RANDOM_NAMES.length)];
    setName(randomPick.name);
    setPhone(randomPick.phone);
    setCompany(randomPick.company);
    const simpleDomain = randomPick.company
      .toLowerCase()
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/[^a-z0-9]/g, "")
      .slice(0, 15) + ".com.br";
    setDomain(simpleDomain);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const finalName = name.trim() || "Cliente " + Math.floor(100 + Math.random() * 900);
    const finalPhone = phone.trim() || "+55 (11) 9" + Math.floor(1000 + Math.random() * 9000) + "-" + Math.floor(1000 + Math.random() * 9000);
    const finalCompany = company.trim() || "Empresa Privada";
    const clientId = `cli-custom-${Date.now()}`;
    const initials = getInitials(finalName);
    const color = AVATAR_COLORS[Math.floor(Math.random() * AVATAR_COLORS.length)];

    const now = new Date();
    const userMsg: Message = {
      id: `msg-u-${Date.now()}`,
      sender: "user",
      content: firstMessage.trim() || "Olá, gostaria de suporte para meu e-mail.",
      timestamp: new Date(now.getTime() - 2 * 60 * 1000).toISOString(),
      status: markAsUnread ? "delivered" : "read",
    };

    const messages: Message[] = [userMsg];

    if (includeBotReply) {
      const scen = PRESET_SCENARIOS.find((s) => s.id === selectedScenarioId);
      const replyContent = scen
        ? scen.botReply
        : `Olá ${finalName}! Sou a ComIA da ComBR Soluções em Nuvem. Recebemos sua mensagem sobre a empresa ${finalCompany} e já estamos analisando. Como podemos ajudar hoje?`;

      const botMsg: Message = {
        id: `msg-b-${Date.now() + 1}`,
        sender: "assistant",
        content: replyContent,
        timestamp: new Date(now.getTime() - 1 * 60 * 1000).toISOString(),
        status: "read",
        showDepartmentOptions: true,
      };
      messages.push(botMsg);
    }

    const lastMsgContent = messages[messages.length - 1].content;
    const timeStr = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });

    const newChat: WhatsAppClientChat = {
      id: clientId,
      name: finalName,
      phone: finalPhone,
      company: finalCompany,
      domain: domain.trim() || undefined,
      email: domain ? `contato@${domain.trim()}` : undefined,
      category,
      avatarColor: color,
      avatarInitials: initials,
      isVerified: false,
      isPinned: false,
      unreadCount: markAsUnread ? 1 : 0,
      lastMessage: lastMsgContent.slice(0, 80) + (lastMsgContent.length > 80 ? "..." : ""),
      lastMessageTime: timeStr,
      status: "online",
      lastSeen: "online agora",
      mode: "bot",
      messages,
      createdAt: now.toISOString(),
      updatedAt: now.toISOString(),
    };

    onCreateClient(newChat);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-[#1f2c34] text-[#e9edef] rounded-2xl w-full max-w-xl border border-[#2a3942] shadow-2xl flex flex-col max-h-[90vh] overflow-hidden">
        {/* Modal Header */}
        <div className="px-5 py-4 bg-[#202c33] border-b border-[#2a3942] flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-full bg-[#00a884]/20 border border-[#00a884]/40 flex items-center justify-center text-[#00a884]">
              <UserPlus className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white leading-tight">
                Criar Novo Cliente & Conversa Fictícia
              </h2>
              <p className="text-xs text-[#8696a0]">
                Simule múltiplos clientes enviando mensagens no WhatsApp
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-[#8696a0] hover:text-[#e9edef] hover:bg-[#2a3942] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <form onSubmit={handleSubmit} className="p-5 overflow-y-auto space-y-4 text-xs">
          {/* Top Quick Actions Bar */}
          <div className="flex items-center justify-between p-2.5 rounded-xl bg-[#111b21] border border-[#2a3942]">
            <div className="flex items-center gap-2 text-[#8696a0]">
              <Zap className="w-4 h-4 text-amber-400" />
              <span>Preenchimento rápido:</span>
            </div>
            <button
              type="button"
              onClick={handleFillRandomData}
              className="px-2.5 py-1 rounded-lg bg-[#202c33] hover:bg-[#2a3942] text-[#00a884] font-semibold text-xs flex items-center gap-1.5 transition-colors cursor-pointer border border-[#00a884]/30"
            >
              <Sparkles className="w-3.5 h-3.5" />
              Gerar Dados Aleatórios
            </button>
          </div>

          {/* Scenario Presets */}
          <div>
            <label className="block text-xs font-semibold text-[#8696a0] uppercase tracking-wider mb-2">
              Escolha um Cenário de Atendimento
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {PRESET_SCENARIOS.map((s) => (
                <button
                  type="button"
                  key={s.id}
                  onClick={() => handleSelectScenario(s.id)}
                  className={`p-2.5 rounded-xl text-left border transition-all cursor-pointer flex flex-col justify-between ${
                    selectedScenarioId === s.id
                      ? "bg-[#00a884]/15 border-[#00a884] text-[#e9edef] shadow-sm"
                      : "bg-[#111b21] border-[#2a3942] text-[#8696a0] hover:text-[#e9edef] hover:border-[#374248]"
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-semibold text-xs text-[#e9edef] truncate">{s.title}</span>
                    {selectedScenarioId === s.id && (
                      <span className="w-2 h-2 rounded-full bg-[#00a884] shrink-0"></span>
                    )}
                  </div>
                  <span className="text-[10px] text-[#8696a0] line-clamp-1">
                    {s.firstMessage}
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* Client Details Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-[#8696a0] mb-1">
                Nome Completo do Cliente *
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Ex: Mariana Silva"
                className="w-full bg-[#111b21] border border-[#2a3942] rounded-lg px-3 py-2 text-xs text-[#e9edef] focus:outline-none focus:border-[#00a884]"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-[#8696a0] mb-1">
                WhatsApp / Telefone *
              </label>
              <div className="relative">
                <Phone className="w-3.5 h-3.5 text-[#8696a0] absolute left-3 top-2.5" />
                <input
                  type="text"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="+55 (11) 98765-4321"
                  className="w-full bg-[#111b21] border border-[#2a3942] rounded-lg pl-8 pr-3 py-2 text-xs text-[#e9edef] focus:outline-none focus:border-[#00a884]"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-[#8696a0] mb-1">
                Empresa / Razão Social
              </label>
              <div className="relative">
                <Building className="w-3.5 h-3.5 text-[#8696a0] absolute left-3 top-2.5" />
                <input
                  type="text"
                  value={company}
                  onChange={(e) => setCompany(e.target.value)}
                  placeholder="Ex: Alfa Design Soluções"
                  className="w-full bg-[#111b21] border border-[#2a3942] rounded-lg pl-8 pr-3 py-2 text-xs text-[#e9edef] focus:outline-none focus:border-[#00a884]"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-[#8696a0] mb-1">
                Domínio Corporativo (Opcional)
              </label>
              <div className="relative">
                <Globe className="w-3.5 h-3.5 text-[#8696a0] absolute left-3 top-2.5" />
                <input
                  type="text"
                  value={domain}
                  onChange={(e) => setDomain(e.target.value)}
                  placeholder="Ex: alfadesign.com.br"
                  className="w-full bg-[#111b21] border border-[#2a3942] rounded-lg pl-8 pr-3 py-2 text-xs text-[#e9edef] focus:outline-none focus:border-[#00a884]"
                />
              </div>
            </div>
          </div>

          {/* Department / Category Pills */}
          <div>
            <label className="block text-xs font-medium text-[#8696a0] mb-1.5">
              Departamento / Fila de Atendimento
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {[
                { id: "support_n2", label: "🛠️ Suporte N2" },
                { id: "commercial", label: "💼 Comercial" },
                { id: "financial", label: "💳 Financeiro" },
                { id: "general", label: "💬 Geral / N1" },
              ].map((cat) => (
                <button
                  type="button"
                  key={cat.id}
                  onClick={() => setCategory(cat.id as any)}
                  className={`py-1.5 px-2 rounded-lg text-xs font-medium border transition-colors cursor-pointer text-center ${
                    category === cat.id
                      ? "bg-[#00a884]/20 border-[#00a884] text-[#00a884]"
                      : "bg-[#111b21] border-[#2a3942] text-[#8696a0] hover:text-[#e9edef]"
                  }`}
                >
                  {cat.label}
                </button>
              ))}
            </div>
          </div>

          {/* Initial Message Textarea */}
          <div>
            <label className="block text-xs font-medium text-[#8696a0] mb-1">
              Primeira Mensagem enviada pelo Cliente
            </label>
            <textarea
              rows={3}
              value={firstMessage}
              onChange={(e) => setFirstMessage(e.target.value)}
              placeholder="Digite a mensagem que o cliente enviou no WhatsApp..."
              className="w-full bg-[#111b21] border border-[#2a3942] rounded-lg p-3 text-xs text-[#e9edef] focus:outline-none focus:border-[#00a884] resize-none"
            />
          </div>

          {/* Checkbox Options */}
          <div className="space-y-2 p-3 rounded-xl bg-[#111b21] border border-[#2a3942]">
            <label className="flex items-center gap-2.5 cursor-pointer">
              <input
                type="checkbox"
                checked={includeBotReply}
                onChange={(e) => setIncludeBotReply(e.target.checked)}
                className="w-4 h-4 rounded text-[#00a884] accent-[#00a884] cursor-pointer"
              />
              <span className="text-xs text-[#d1d7db]">
                Incluir resposta automática inteligente da <strong>ComIA</strong>
              </span>
            </label>

            <label className="flex items-center gap-2.5 cursor-pointer">
              <input
                type="checkbox"
                checked={markAsUnread}
                onChange={(e) => setMarkAsUnread(e.target.checked)}
                className="w-4 h-4 rounded text-[#00a884] accent-[#00a884] cursor-pointer"
              />
              <span className="text-xs text-[#d1d7db]">
                Marcar como <strong>Não lida</strong> (exibe bolinha verde de notificação no WhatsApp)
              </span>
            </label>
          </div>

          {/* Buttons Footer */}
          <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-2">
            <button
              type="button"
              onClick={() => {
                onResetToDemoClients();
                onClose();
              }}
              className="text-[11px] text-[#8696a0] hover:text-[#00a884] underline flex items-center gap-1 cursor-pointer order-2 sm:order-1"
            >
              <RotateCcw className="w-3 h-3" />
              Restaurar 5 Clientes Demonstrativos
            </button>

            <div className="flex items-center gap-2 w-full sm:w-auto order-1 sm:order-2">
              <button
                type="button"
                onClick={onClose}
                className="flex-1 sm:flex-none px-4 py-2 rounded-xl bg-[#202c33] text-[#8696a0] hover:text-white text-xs font-semibold cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="submit"
                className="flex-1 sm:flex-none px-5 py-2 rounded-xl bg-[#00a884] hover:bg-[#02906f] text-[#111b21] font-bold text-xs shadow-lg transition-all flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <UserPlus className="w-4 h-4" />
                Criar Cliente e Abrir Chat
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
