import React from "react";
import { ComIALogo } from "./ComIALogo";
import { Wrench, Building2, CreditCard, Globe, ExternalLink, RotateCcw } from "lucide-react";
import { TriageType } from "../types";

interface HeaderProps {
  onOpenTriage: (type: TriageType) => void;
  onResetChat: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onOpenTriage, onResetChat }) => {
  return (
    <header id="main-header" className="sticky top-0 z-30 bg-slate-950/85 backdrop-blur-md border-b border-slate-800/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex flex-col sm:flex-row items-center justify-between gap-3">
        {/* Brand identity */}
        <div className="flex items-center gap-3 w-full sm:w-auto justify-between sm:justify-start">
          <div className="flex items-center gap-3">
            <ComIALogo size="md" />

            <div className="border-l border-slate-800 pl-3">
              <div className="flex items-center gap-2">
                <span className="text-xs font-semibold text-slate-300">ComBR Soluções em Nuvem</span>
                <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-sky-500/10 text-sky-400 border border-sky-500/30">
                  Suporte N1 & Triagem
                </span>
              </div>
              <p className="text-[11px] text-slate-400">
                Assistente Virtual Oficial
              </p>
            </div>
          </div>

          {/* Reset button on mobile */}
          <button
            id="btn-reset-chat-mobile"
            onClick={onResetChat}
            className="sm:hidden p-2 text-slate-400 hover:text-slate-200 hover:bg-slate-900 rounded-lg transition-colors"
            title="Reiniciar conversa"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>

        {/* Quick Triage Buttons & Status */}
        <div className="flex items-center gap-2 w-full sm:w-auto justify-end flex-wrap">
          <button
            id="btn-header-n2-support"
            onClick={() => onOpenTriage("support_n2")}
            className="px-2.5 py-1.5 text-xs font-medium text-sky-300 bg-sky-950/40 hover:bg-sky-900/60 border border-sky-500/30 rounded-xl transition-all flex items-center gap-1.5"
            title="Encaminhar para Suporte N2 Especializado"
          >
            <Wrench className="w-3.5 h-3.5 text-sky-400" />
            <span>Suporte N2</span>
          </button>

          <button
            id="btn-header-commercial-triage"
            onClick={() => onOpenTriage("commercial")}
            className="px-2.5 py-1.5 text-xs font-medium text-emerald-300 bg-emerald-950/40 hover:bg-emerald-900/60 border border-emerald-500/30 rounded-xl transition-all flex items-center gap-1.5"
            title="Orçamentos e novos planos"
          >
            <Building2 className="w-3.5 h-3.5 text-emerald-400" />
            <span>Comercial</span>
          </button>

          <button
            id="btn-header-financial-triage"
            onClick={() => onOpenTriage("financial")}
            className="px-2.5 py-1.5 text-xs font-medium text-amber-300 bg-amber-950/40 hover:bg-amber-900/60 border border-amber-500/30 rounded-xl transition-all flex items-center gap-1.5"
            title="2ª via de boleto e faturas"
          >
            <CreditCard className="w-3.5 h-3.5 text-amber-400" />
            <span>Financeiro</span>
          </button>

          <a
            id="btn-header-webmail"
            href="https://webmail.combr.com.br"
            target="_blank"
            rel="noopener noreferrer"
            className="px-2.5 py-1.5 text-xs font-medium text-slate-200 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-xl transition-all flex items-center gap-1.5"
          >
            <Globe className="w-3.5 h-3.5 text-sky-400" />
            <span>Webmail</span>
            <ExternalLink className="w-3 h-3 text-slate-400" />
          </a>

          {/* Desktop reset */}
          <button
            id="btn-reset-chat-desktop"
            onClick={onResetChat}
            className="hidden sm:flex p-2 text-slate-400 hover:text-slate-200 hover:bg-slate-900 rounded-xl transition-colors border border-transparent hover:border-slate-800"
            title="Reiniciar conversa"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
};
