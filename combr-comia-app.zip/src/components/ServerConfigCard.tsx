import React, { useState } from "react";
import { Server, ShieldCheck, Mail, Globe, Check, Copy, ExternalLink, HardDrive, KeyRound, AlertCircle, ShieldAlert } from "lucide-react";

export const ServerConfigCard: React.FC = () => {
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const copyToClipboard = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const configs = [
    {
      id: "imap",
      name: "IMAP (Entrada)",
      badge: "Recomendado",
      badgeColor: "bg-emerald-500/10 text-emerald-400 border-emerald-500/30",
      host: "imap.combr.com.br",
      port: "993",
      security: "SSL / TLS",
      description: "Sincroniza todas as mensagens e pastas em tempo real entre celulares, tablets e computadores.",
      icon: Server,
    },
    {
      id: "smtp",
      name: "SMTP (Saída)",
      badge: "Envio Seguro",
      badgeColor: "bg-sky-500/10 text-sky-400 border-sky-500/30",
      host: "smtp.combr.com.br",
      port: "465 ou 587",
      security: "SSL/TLS (465) / STARTTLS (587)",
      description: 'Requer autenticação: "Meu servidor de saída requer autenticação" deve estar ativada.',
      icon: Mail,
    },
    {
      id: "pop",
      name: "POP3 (Entrada)",
      badge: "Opcional",
      badgeColor: "bg-slate-500/10 text-slate-300 border-slate-500/30",
      host: "pop.combr.com.br",
      port: "995",
      security: "SSL / TLS",
      description: "Baixa os e-mails para um único dispositivo (não sincroniza pastas ou status lido).",
      icon: HardDrive,
    },
  ];

  return (
    <div id="combr-server-config-card" className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl backdrop-blur-sm">
      <div className="flex items-center justify-between pb-4 mb-4 border-b border-slate-800">
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded-lg bg-sky-500/10 border border-sky-500/30 text-sky-400">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-slate-100">Parâmetros Oficiais de E-mail Corporativo</h3>
            <p className="text-xs text-slate-400">ComBR Soluções em Nuvem • Base N1</p>
          </div>
        </div>
        <a
          id="btn-open-webmail-link"
          href="https://webmail.combr.com.br"
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-sky-300 bg-sky-950/60 hover:bg-sky-900/80 border border-sky-500/30 rounded-lg transition-colors"
        >
          <Globe className="w-3.5 h-3.5" />
          <span>Webmail</span>
          <ExternalLink className="w-3 h-3 ml-0.5 opacity-70" />
        </a>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        {configs.map((cfg) => {
          const Icon = cfg.icon;
          const isCopied = copiedKey === cfg.id;
          return (
            <div
              key={cfg.id}
              className="group relative bg-slate-950/70 border border-slate-800/80 hover:border-sky-500/40 rounded-xl p-3.5 transition-all duration-200"
            >
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-1.5">
                  <Icon className="w-4 h-4 text-sky-400" />
                  <span className="text-xs font-bold text-slate-200">{cfg.name}</span>
                </div>
                <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full border ${cfg.badgeColor}`}>
                  {cfg.badge}
                </span>
              </div>

              <div className="space-y-1.5 text-xs mb-2.5">
                <div className="flex items-center justify-between bg-slate-900/90 px-2.5 py-1.5 rounded-lg border border-slate-800 font-mono">
                  <span className="text-slate-400 text-[11px]">Host:</span>
                  <span className="font-semibold text-slate-100">{cfg.host}</span>
                  <button
                    id={`btn-copy-${cfg.id}`}
                    onClick={() => copyToClipboard(cfg.host, cfg.id)}
                    className="text-slate-400 hover:text-sky-400 transition-colors ml-1 p-0.5"
                    title="Copiar host"
                  >
                    {isCopied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>

                <div className="flex items-center justify-between px-1 text-[11px]">
                  <span className="text-slate-400">Porta:</span>
                  <span className="font-mono font-medium text-sky-300">{cfg.port}</span>
                </div>

                <div className="flex items-center justify-between px-1 text-[11px]">
                  <span className="text-slate-400">Criptografia:</span>
                  <span className="text-slate-300 font-medium">{cfg.security}</span>
                </div>
              </div>

              <p className="text-[11px] text-slate-400 leading-tight">{cfg.description}</p>
            </div>
          );
        })}
      </div>

      {/* Mandatory Notice */}
      <div className="mt-3.5 pt-3 border-t border-slate-800/80 grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-slate-300">
        <div className="flex items-center gap-2 bg-slate-950/50 p-2 rounded-lg border border-slate-800/60">
          <span className="w-2 h-2 rounded-full bg-emerald-400 shrink-0"></span>
          <span className="text-[11px]">
            <strong>Usuário / Login:</strong> E-mail corporativo completo (<code className="text-sky-300">nome@seudominio.com.br</code>)
          </span>
        </div>
        <div className="flex items-center gap-2 bg-slate-950/50 p-2 rounded-lg border border-slate-800/60">
          <span className="w-2 h-2 rounded-full bg-sky-400 shrink-0"></span>
          <span className="text-[11px]">
            <strong>Autenticação SMTP:</strong> Obrigatória (mesmas credenciais de login)
          </span>
        </div>
      </div>
    </div>
  );
};
