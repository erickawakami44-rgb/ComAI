import React, { useState } from "react";
import { Ticket, TicketStatus, TriageType } from "../types";
import {
  Wrench,
  Building2,
  CreditCard,
  Clock,
  CheckCircle2,
  AlertCircle,
  Ban,
  Trash2,
  SlidersHorizontal,
  Image as ImageIcon,
} from "lucide-react";
import { TicketStatusDrawer } from "./TicketStatusDrawer";

interface TicketHistoryProps {
  tickets: Ticket[];
  onOpenTriage: (type: TriageType) => void;
  onUpdateStatus?: (ticketId: string, newStatus: TicketStatus) => void;
  onDeleteTicket?: (ticketId: string) => void;
}

export const TicketHistory: React.FC<TicketHistoryProps> = ({
  tickets,
  onOpenTriage,
  onUpdateStatus,
  onDeleteTicket,
}) => {
  const [drawerTicket, setDrawerTicket] = useState<Ticket | null>(null);

  const getBadge = (type: TriageType) => {
    switch (type) {
      case "support_n2":
        return {
          label: "Suporte N2",
          color: "bg-sky-500/10 text-sky-400 border-sky-500/30",
          icon: Wrench,
        };
      case "commercial":
        return {
          label: "Comercial",
          color: "bg-emerald-500/10 text-emerald-400 border-emerald-500/30",
          icon: Building2,
        };
      case "financial":
        return {
          label: "Financeiro",
          color: "bg-amber-500/10 text-amber-400 border-amber-500/30",
          icon: CreditCard,
        };
    }
  };

  const getStatusBadge = (status?: TicketStatus) => {
    const s = status || "not_started";
    switch (s) {
      case "completed":
        return {
          label: "Concluído",
          badgeClass: "bg-emerald-500/15 text-emerald-400 border-emerald-500/30",
          dotClass: "bg-emerald-500",
          icon: CheckCircle2,
        };
      case "in_progress":
        return {
          label: "Em andamento",
          badgeClass: "bg-amber-500/15 text-amber-400 border-amber-500/30",
          dotClass: "bg-amber-500",
          icon: Clock,
        };
      case "cancelled":
        return {
          label: "Cancelado",
          badgeClass: "bg-slate-500/15 text-slate-400 border-slate-500/30",
          dotClass: "bg-slate-500",
          icon: Ban,
        };
      case "not_started":
      default:
        return {
          label: "Não iniciado",
          badgeClass: "bg-rose-500/15 text-rose-400 border-rose-500/30",
          dotClass: "bg-rose-500",
          icon: AlertCircle,
        };
    }
  };

  const formatDate = (iso: string) => {
    try {
      return new Date(iso).toLocaleString("pt-BR", {
        day: "2-digit",
        month: "2-digit",
        hour: "2-digit",
        minute: "2-digit",
      });
    } catch {
      return "";
    }
  };

  return (
    <div id="combr-ticket-history-card" className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl backdrop-blur-sm">
      <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <div className="p-1.5 rounded-lg bg-sky-500/10 border border-sky-500/30 text-sky-400">
            <Clock className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-xs font-bold text-slate-100 uppercase tracking-wider">
              Fila de Transbordo Humano
            </h3>
            <p className="text-[11px] text-slate-400">Atendimentos e Chamados ComBr</p>
          </div>
        </div>

        <span className="text-xs font-mono font-bold text-slate-300 bg-slate-950 px-2 py-0.5 rounded-full border border-slate-800">
          {tickets.length} chamados
        </span>
      </div>

      {tickets.length === 0 ? (
        <div className="py-6 text-center text-slate-400 text-xs space-y-2">
          <p>Nenhum chamado de transbordo aberto nesta sessão.</p>
          <div className="flex items-center justify-center gap-2 pt-1">
            <button
              onClick={() => onOpenTriage("support_n2")}
              className="text-[11px] text-sky-400 hover:text-sky-300 underline"
            >
              Abrir N2
            </button>
            <span>•</span>
            <button
              onClick={() => onOpenTriage("commercial")}
              className="text-[11px] text-emerald-400 hover:text-emerald-300 underline"
            >
              Comercial
            </button>
            <span>•</span>
            <button
              onClick={() => onOpenTriage("financial")}
              className="text-[11px] text-amber-400 hover:text-amber-300 underline"
            >
              Financeiro
            </button>
          </div>
        </div>
      ) : (
        <div className="space-y-2.5 max-h-72 overflow-y-auto pr-1">
          {tickets.map((t) => {
            const badge = getBadge(t.type);
            const Icon = badge.icon;
            const statusBadge = getStatusBadge(t.status);
            const StatusIcon = statusBadge.icon;
            const currentStatus = t.status || "not_started";

            return (
              <div
                key={t.id}
                className="bg-slate-950/70 border border-slate-800/80 rounded-xl p-3 text-xs space-y-2 hover:border-slate-700 transition-colors"
              >
                <div className="flex items-center justify-between flex-wrap gap-1">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border flex items-center gap-1 ${badge.color}`}>
                      <Icon className="w-3 h-3" />
                      {badge.label}
                    </span>
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border flex items-center gap-1 ${statusBadge.badgeClass}`}>
                      <span className={`w-1.5 h-1.5 rounded-full ${statusBadge.dotClass}`}></span>
                      <StatusIcon className="w-2.5 h-2.5" />
                      {statusBadge.label}
                    </span>
                    <span className="font-mono font-bold text-slate-200 text-[11px]">{t.id}</span>
                  </div>
                  <span className="text-[10px] text-slate-400">{formatDate(t.createdAt)}</span>
                </div>

                <p className="text-slate-300 font-medium line-clamp-1">{t.subject}</p>

                <div className="text-[11px] text-slate-400 flex flex-wrap gap-x-3 gap-y-1">
                  {t.cnpjOrCorporateName && <span>🏢 {t.cnpjOrCorporateName}</span>}
                  {t.domain && <span>🌐 @{t.domain}</span>}
                  {t.affectedEmail && <span>📧 {t.affectedEmail}</span>}
                  {t.phone && <span>📞 {t.phone}</span>}
                </div>

                {t.attachmentImage && (
                  <div className="p-2 rounded-lg bg-slate-900 border border-slate-800 flex items-center gap-2">
                    <img
                      src={t.attachmentImage.url}
                      alt="Print"
                      className="w-10 h-10 object-cover rounded border border-slate-700"
                    />
                    <div className="text-[11px] text-slate-300">
                      <span className="font-semibold text-emerald-400 flex items-center gap-1">
                        <ImageIcon className="w-3 h-3" /> Foto / Print do erro anexado
                      </span>
                      <span className="text-[10px] text-slate-400">
                        {t.attachmentImage.fileName || "Print do usuário"}
                      </span>
                    </div>
                  </div>
                )}

                {/* Status and Action Buttons */}
                {onUpdateStatus && (
                  <div className="flex items-center justify-between pt-1.5 border-t border-slate-800 text-[11px] flex-wrap gap-1">
                    <button
                      onClick={() => setDrawerTicket(t)}
                      className="px-2 py-0.5 rounded text-[10px] font-semibold bg-slate-800 hover:bg-slate-700 text-sky-400 border border-slate-700 flex items-center gap-1 transition-colors"
                      title="Abrir gaveta para alterar status"
                    >
                      <SlidersHorizontal className="w-2.5 h-2.5" />
                      <span>Alterar Status (Gaveta)</span>
                    </button>

                    <div className="flex items-center gap-1.5">
                      {currentStatus !== "cancelled" && (
                        <button
                          onClick={() => onUpdateStatus(t.id, "cancelled")}
                          className="text-[10px] text-slate-400 hover:text-slate-200 underline"
                        >
                          Cancelar
                        </button>
                      )}
                      {onDeleteTicket && (
                        <button
                          onClick={() => onDeleteTicket(t.id)}
                          className="text-[10px] text-rose-400 hover:text-rose-300 flex items-center gap-0.5"
                          title="Excluir chamado"
                        >
                          <Trash2 className="w-3 h-3" />
                        </button>
                      )}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Ticket Status Drawer */}
      {onUpdateStatus && (
        <TicketStatusDrawer
          isOpen={!!drawerTicket}
          ticket={drawerTicket}
          onClose={() => setDrawerTicket(null)}
          onSelectStatus={onUpdateStatus}
          onDeleteTicket={(id) => {
            setDrawerTicket(null);
            if (onDeleteTicket) onDeleteTicket(id);
          }}
        />
      )}
    </div>
  );
};

