import React, { useState } from "react";
import {
  X,
  CheckCircle2,
  Clock,
  AlertCircle,
  Ban,
  Check,
  FileText,
  Building2,
  Wrench,
  CreditCard,
  Trash2,
  Image as ImageIcon,
  ZoomIn,
  Eye,
} from "lucide-react";
import { Ticket, TicketStatus, TriageType } from "../types";

interface TicketStatusDrawerProps {
  isOpen: boolean;
  ticket: Ticket | null;
  onClose: () => void;
  onSelectStatus: (ticketId: string, newStatus: TicketStatus) => void;
  onDeleteTicket?: (ticketId: string) => void;
}

export const TicketStatusDrawer: React.FC<TicketStatusDrawerProps> = ({
  isOpen,
  ticket,
  onClose,
  onSelectStatus,
  onDeleteTicket,
}) => {
  if (!isOpen || !ticket) return null;

  const currentStatus: TicketStatus = ticket.status || "not_started";
  const [selectedStatus, setSelectedStatus] = useState<TicketStatus>(currentStatus);
  const [drawerImagePreview, setDrawerImagePreview] = useState<string | null>(null);
  const [isConfirmingDelete, setIsConfirmingDelete] = useState<boolean>(false);

  // Status definitions with required colors: Concluído (Verde), Em andamento (Amarelo), Não iniciado (Vermelho)
  const statusOptions: Array<{
    id: TicketStatus;
    title: string;
    description: string;
    colorName: string;
    icon: React.FC<{ className?: string }>;
    cardBg: string;
    cardBorder: string;
    selectedRing: string;
    badgeBg: string;
    badgeText: string;
    dotColor: string;
  }> = [
    {
      id: "completed",
      title: "Concluído",
      description: "Atendimento finalizado com sucesso e problema solucionado pelo time.",
      colorName: "Verde",
      icon: CheckCircle2,
      cardBg: "hover:bg-emerald-950/30 bg-emerald-950/15",
      cardBorder: "border-emerald-500/40",
      selectedRing: "ring-2 ring-emerald-500 bg-emerald-950/40 border-emerald-500",
      badgeBg: "bg-emerald-500/20",
      badgeText: "text-emerald-400",
      dotColor: "bg-emerald-500",
    },
    {
      id: "in_progress",
      title: "Em andamento",
      description: "Chamado em análise técnica, execução ou contato comercial ativo.",
      colorName: "Amarelo",
      icon: Clock,
      cardBg: "hover:bg-amber-950/30 bg-amber-950/15",
      cardBorder: "border-amber-500/40",
      selectedRing: "ring-2 ring-amber-500 bg-amber-950/40 border-amber-500",
      badgeBg: "bg-amber-500/20",
      badgeText: "text-amber-400",
      dotColor: "bg-amber-500",
    },
    {
      id: "not_started",
      title: "Não iniciado",
      description: "Aguardando triagem na fila de atendimento da equipe ComBr.",
      colorName: "Vermelho",
      icon: AlertCircle,
      cardBg: "hover:bg-rose-950/30 bg-rose-950/15",
      cardBorder: "border-rose-500/40",
      selectedRing: "ring-2 ring-rose-500 bg-rose-950/40 border-rose-500",
      badgeBg: "bg-rose-500/20",
      badgeText: "text-rose-400",
      dotColor: "bg-rose-500",
    },
    {
      id: "cancelled",
      title: "Cancelado",
      description: "Chamado cancelado pelo cliente ou encerrado sem necessidade de ação.",
      colorName: "Cinza",
      icon: Ban,
      cardBg: "hover:bg-slate-900/40 bg-slate-900/20",
      cardBorder: "border-slate-600/40",
      selectedRing: "ring-2 ring-slate-400 bg-slate-800/60 border-slate-400",
      badgeBg: "bg-slate-500/20",
      badgeText: "text-slate-300",
      dotColor: "bg-slate-400",
    },
  ];

  const getTypeLabel = (type: TriageType) => {
    switch (type) {
      case "support_n2":
        return { label: "Suporte N2 Especializado", icon: Wrench, text: "text-[#53bdeb]" };
      case "financial":
        return { label: "Financeiro & Faturamento", icon: CreditCard, text: "text-[#ffd279]" };
      case "commercial":
      default:
        return { label: "Comercial & Propostas", icon: Building2, text: "text-[#00a884]" };
    }
  };

  const typeInfo = getTypeLabel(ticket.type);
  const TypeIcon = typeInfo.icon;

  const handleApply = (statusToApply?: TicketStatus) => {
    const target = statusToApply || selectedStatus;
    onSelectStatus(ticket.id, target);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Dark backdrop */}
      <div
        onClick={onClose}
        className="absolute inset-0 bg-black/70 backdrop-blur-xs transition-opacity duration-300 animate-in fade-in"
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        {/* Slide-over Drawer Panel */}
        <div className="w-screen max-w-md bg-[#111b21] border-l border-[#2a3942] shadow-2xl flex flex-col animate-in slide-in-from-right duration-300">
          {/* Drawer Header */}
          <div className="p-4 bg-[#202c33] border-b border-[#222e35] flex items-center justify-between shrink-0">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-[#111b21] border border-[#2a3942] flex items-center justify-center text-[#00a884]">
                <FileText className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-[#e9edef] flex items-center gap-1.5">
                  <span>Alterar Status do Chamado</span>
                </h3>
                <p className="text-[11px] font-mono text-[#00a884] font-semibold">
                  #{ticket.id}
                </p>
              </div>
            </div>

            <button
              onClick={onClose}
              className="p-1.5 rounded-full hover:bg-[#374248] text-[#8696a0] hover:text-[#e9edef] transition-colors"
              title="Fechar gaveta"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Drawer Content */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {/* Ticket Summary Card */}
            <div className="bg-[#202c33] border border-[#2a3942] rounded-xl p-3.5 space-y-2">
              <div className="flex items-center justify-between gap-2">
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full bg-[#111b21] border border-[#2a3942] flex items-center gap-1 ${typeInfo.text}`}>
                  <TypeIcon className="w-3 h-3" />
                  <span>{typeInfo.label}</span>
                </span>
                <span className="text-[11px] text-[#8696a0]">
                  {new Date(ticket.createdAt).toLocaleDateString("pt-BR", {
                    day: "2-digit",
                    month: "2-digit",
                    hour: "2-digit",
                    minute: "2-digit",
                  })}
                </span>
              </div>

              <h4 className="text-xs font-semibold text-[#e9edef] leading-snug">
                {ticket.subject}
              </h4>

              <div className="text-[11px] text-[#8696a0] space-y-0.5 pt-1 border-t border-[#2a3942]/60">
                {ticket.domain && (
                  <div>
                    Domínio: <span className="text-[#e9edef] font-semibold">@{ticket.domain}</span>
                  </div>
                )}
                {ticket.affectedEmail && (
                  <div>
                    E-mail: <span className="text-[#e9edef] font-mono">{ticket.affectedEmail}</span>
                  </div>
                )}
                {ticket.cnpjOrCorporateName && (
                  <div>
                    CNPJ / Razão: <span className="text-[#e9edef]">{ticket.cnpjOrCorporateName}</span>
                  </div>
                )}
                {ticket.contactName && (
                  <div>
                    Contato: <span className="text-[#e9edef]">{ticket.contactName}</span>
                  </div>
                )}
                {ticket.errorMessage && (
                  <div className="pt-1.5 border-t border-[#2a3942]/60">
                    <span className="text-[10px] uppercase font-bold text-[#8696a0] block">Erro / Descrição:</span>
                    <span className="text-[#53bdeb] font-mono text-[11px] block">{ticket.errorMessage}</span>
                  </div>
                )}
                {ticket.attachmentImage && (
                  <div className="pt-2 border-t border-[#2a3942] space-y-1.5">
                    <div className="flex items-center justify-between text-[11px]">
                      <span className="text-[#00a884] font-semibold flex items-center gap-1">
                        <ImageIcon className="w-3.5 h-3.5" />
                        Print / Foto Anexada:
                      </span>
                      <button
                        type="button"
                        onClick={() => setDrawerImagePreview(ticket.attachmentImage!.url)}
                        className="text-[#53bdeb] hover:underline flex items-center gap-0.5 text-[10px]"
                      >
                        <ZoomIn className="w-3 h-3" />
                        <span>Ver ampliado</span>
                      </button>
                    </div>
                    <div
                      className="relative rounded-lg overflow-hidden border border-[#2a3942] bg-black/40 cursor-pointer group"
                      onClick={() => setDrawerImagePreview(ticket.attachmentImage!.url)}
                    >
                      <img
                        src={ticket.attachmentImage.url}
                        alt="Anexo do chamado"
                        className="w-full max-h-36 object-cover hover:scale-102 transition-transform"
                      />
                      <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                        <span className="text-[10px] text-white bg-black/70 px-2 py-1 rounded-full font-medium">
                          Clique para expandir
                        </span>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Instruction */}
            <div>
              <label className="block text-xs font-bold text-[#e9edef] uppercase tracking-wider mb-1">
                Selecione o novo status:
              </label>
              <p className="text-[11px] text-[#8696a0]">
                Escolha a situação atual para atualizar a fila de atendimento.
              </p>
            </div>

            {/* Status Options Cards */}
            <div className="space-y-2.5">
              {statusOptions.map((opt) => {
                const Icon = opt.icon;
                const isSelected = selectedStatus === opt.id;
                const isCurrent = currentStatus === opt.id;

                return (
                  <div
                    key={opt.id}
                    onClick={() => {
                      setSelectedStatus(opt.id);
                      handleApply(opt.id);
                    }}
                    className={`cursor-pointer rounded-xl p-3.5 border transition-all relative flex items-start gap-3 ${
                      opt.cardBg
                    } ${
                      isSelected ? opt.selectedRing : opt.cardBorder
                    }`}
                  >
                    {/* Status Icon */}
                    <div
                      className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 border ${opt.badgeBg} ${opt.badgeText} ${opt.cardBorder}`}
                    >
                      <Icon className="w-5 h-5" />
                    </div>

                    {/* Title, Badge and Description */}
                    <div className="flex-1 space-y-1">
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-bold text-[#e9edef]">
                            {opt.title}
                          </span>
                          <span
                            className={`text-[10px] font-bold px-1.5 py-0.5 rounded-full flex items-center gap-1 ${opt.badgeBg} ${opt.badgeText}`}
                          >
                            <span className={`w-1.5 h-1.5 rounded-full ${opt.dotColor}`}></span>
                            <span>{opt.colorName}</span>
                          </span>
                        </div>

                        {isCurrent && (
                          <span className="text-[10px] uppercase font-bold text-[#00a884] bg-[#111b21] px-1.5 py-0.5 rounded border border-[#2a3942]">
                            Atual
                          </span>
                        )}
                      </div>

                      <p className="text-[11px] text-[#8696a0] leading-relaxed">
                        {opt.description}
                      </p>
                    </div>

                    {/* Radio/Check indicator */}
                    <div
                      className={`w-5 h-5 rounded-full border flex items-center justify-center shrink-0 transition-colors mt-0.5 ${
                        isSelected
                          ? "bg-[#00a884] border-[#00a884] text-[#111b21]"
                          : "border-[#8696a0]/50 bg-transparent"
                      }`}
                    >
                      {isSelected && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Drawer Footer */}
          <div className="p-4 bg-[#202c33] border-t border-[#222e35] flex items-center justify-between gap-2 shrink-0">
            {onDeleteTicket ? (
              isConfirmingDelete ? (
                <div className="flex items-center gap-1.5 bg-rose-500/20 border border-rose-500/50 rounded-xl px-2.5 py-1.5 animate-in fade-in">
                  <span className="text-[11px] text-rose-300 font-bold">Excluir?</span>
                  <button
                    type="button"
                    onClick={() => {
                      onDeleteTicket(ticket.id);
                      setIsConfirmingDelete(false);
                      onClose();
                    }}
                    className="px-2 py-1 rounded-lg bg-rose-600 hover:bg-rose-700 text-white text-[11px] font-bold cursor-pointer"
                  >
                    Sim
                  </button>
                  <button
                    type="button"
                    onClick={() => setIsConfirmingDelete(false)}
                    className="px-1.5 py-1 rounded-lg bg-[#202c33] text-[#8696a0] hover:text-white text-[11px] cursor-pointer"
                  >
                    Não
                  </button>
                </div>
              ) : (
                <button
                  onClick={() => setIsConfirmingDelete(true)}
                  className="px-3 py-2 rounded-xl text-xs font-semibold bg-red-950/40 hover:bg-red-900/60 text-red-400 border border-red-800/40 flex items-center gap-1.5 transition-colors cursor-pointer"
                  title="Excluir chamado permanentemente"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Excluir Chamado</span>
                </button>
              )
            ) : (
              <div></div>
            )}

            <div className="flex items-center gap-2">
              <button
                onClick={onClose}
                className="px-4 py-2 rounded-xl text-xs font-semibold bg-[#111b21] hover:bg-[#182229] text-[#e9edef] border border-[#2a3942] transition-colors"
              >
                Fechar
              </button>
              <button
                onClick={() => handleApply()}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-[#00a884] hover:bg-[#02906f] text-[#111b21] transition-colors flex items-center gap-1.5 shadow-sm"
              >
                <Check className="w-4 h-4 stroke-[2.5]" />
                <span>Confirmar Status</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Fullscreen Image Preview from Drawer */}
      {drawerImagePreview && (
        <div
          className="fixed inset-0 bg-black/90 backdrop-blur-md z-60 flex flex-col items-center justify-center p-4 animate-in fade-in duration-150"
          onClick={() => setDrawerImagePreview(null)}
        >
          <div className="absolute top-4 right-4 flex items-center gap-2 z-10">
            <button
              onClick={() => setDrawerImagePreview(null)}
              className="p-2.5 rounded-full bg-[#202c33]/80 hover:bg-[#374248] text-white transition-colors border border-white/10"
              title="Fechar"
            >
              <X className="w-6 h-6" />
            </button>
          </div>
          <div
            className="max-w-4xl max-h-[85vh] flex flex-col items-center gap-2"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="w-full flex items-center justify-between px-2 text-xs text-[#8696a0]">
              <span className="font-semibold text-[#e9edef] truncate">
                #{ticket.id} - Anexo do Chamado
              </span>
              <span className="text-[11px] text-[#00a884]">Visualização em Alta Definição</span>
            </div>
            <img
              src={drawerImagePreview}
              alt="Print ampliado do chamado"
              className="max-w-full max-h-[80vh] object-contain rounded-xl border border-[#2a3942] shadow-2xl bg-black/60"
            />
          </div>
        </div>
      )}
    </div>
  );
};
