import React, { useState } from "react";
import {
  FileText,
  Plus,
  ArrowLeft,
  Search,
  CheckCircle2,
  Clock,
  AlertCircle,
  Ban,
  Trash2,
  Wrench,
  Building2,
  CreditCard,
  ChevronDown,
  RefreshCw,
  ExternalLink,
  Filter,
  SlidersHorizontal,
  ChevronRight,
  Image as ImageIcon,
  ZoomIn,
  Eye,
  X,
  MessageSquare,
} from "lucide-react";
import { Ticket, TicketStatus, TriageType } from "../types";
import { TicketStatusDrawer } from "./TicketStatusDrawer";

interface TicketsViewProps {
  tickets: Ticket[];
  onOpenTriage: (type: TriageType) => void;
  onUpdateStatus: (ticketId: string, newStatus: TicketStatus) => void;
  onDeleteTicket: (ticketId: string) => void;
  onBackToChat: () => void;
}

export const TicketsView: React.FC<TicketsViewProps> = ({
  tickets,
  onOpenTriage,
  onUpdateStatus,
  onDeleteTicket,
  onBackToChat,
}) => {
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [typeFilter, setTypeFilter] = useState<string>("all");
  const [ticketToDelete, setTicketToDelete] = useState<Ticket | null>(null);
  const [deletingTicketId, setDeletingTicketId] = useState<string | null>(null);
  const [ticketForDrawer, setTicketForDrawer] = useState<Ticket | null>(null);
  const [previewImage, setPreviewImage] = useState<{ url: string; title: string } | null>(null);

  // Status configuration with exact colors requested:
  // Concluído = Verde, Em andamento = Amarelo, Não iniciado = Vermelho
  const statusConfig: Record<
    TicketStatus,
    { label: string; bg: string; text: string; border: string; dot: string; icon: React.FC<{ className?: string }> }
  > = {
    completed: {
      label: "Concluído",
      bg: "bg-emerald-500/15",
      text: "text-emerald-400",
      border: "border-emerald-500/30",
      dot: "bg-emerald-500",
      icon: CheckCircle2,
    },
    in_progress: {
      label: "Em andamento",
      bg: "bg-amber-500/15",
      text: "text-amber-400",
      border: "border-amber-500/30",
      dot: "bg-amber-500",
      icon: Clock,
    },
    not_started: {
      label: "Não iniciado",
      bg: "bg-rose-500/15",
      text: "text-rose-400",
      border: "border-rose-500/30",
      dot: "bg-rose-500",
      icon: AlertCircle,
    },
    cancelled: {
      label: "Cancelado",
      bg: "bg-slate-500/15",
      text: "text-slate-400",
      border: "border-slate-500/30",
      dot: "bg-slate-500",
      icon: Ban,
    },
  };

  const getTypeBadge = (type: TriageType) => {
    switch (type) {
      case "support_n2":
        return {
          label: "Suporte N2",
          bg: "bg-[#53bdeb]/10",
          text: "text-[#53bdeb]",
          border: "border-[#53bdeb]/30",
          icon: Wrench,
        };
      case "financial":
        return {
          label: "Financeiro",
          bg: "bg-[#ffd279]/10",
          text: "text-[#ffd279]",
          border: "border-[#ffd279]/30",
          icon: CreditCard,
        };
      case "commercial":
      default:
        return {
          label: "Comercial",
          bg: "bg-[#00a884]/10",
          text: "text-[#00a884]",
          border: "border-[#00a884]/30",
          icon: Building2,
        };
    }
  };

  // Filtered tickets
  const filteredTickets = tickets.filter((t) => {
    const currentStatus = t.status || "not_started";
    const matchStatus = statusFilter === "all" || currentStatus === statusFilter;
    const matchType = typeFilter === "all" || t.type === typeFilter;

    const query = searchQuery.toLowerCase().trim();
    const matchSearch =
      !query ||
      t.id.toLowerCase().includes(query) ||
      (t.domain && t.domain.toLowerCase().includes(query)) ||
      (t.affectedEmail && t.affectedEmail.toLowerCase().includes(query)) ||
      (t.cnpjOrCorporateName && t.cnpjOrCorporateName.toLowerCase().includes(query)) ||
      (t.companyName && t.companyName.toLowerCase().includes(query)) ||
      (t.contactName && t.contactName.toLowerCase().includes(query)) ||
      (t.subject && t.subject.toLowerCase().includes(query));

    return matchStatus && matchType && matchSearch;
  });

  // Counters
  const countNotStarted = tickets.filter((t) => (t.status || "not_started") === "not_started").length;
  const countInProgress = tickets.filter((t) => t.status === "in_progress").length;
  const countCompleted = tickets.filter((t) => t.status === "completed").length;
  const countCancelled = tickets.filter((t) => t.status === "cancelled").length;

  const formatDate = (iso: string) => {
    try {
      return new Date(iso).toLocaleString("pt-BR", {
        day: "2-digit",
        month: "2-digit",
        hour: "2-digit",
        minute: "2-digit",
      });
    } catch {
      return "";
    }
  };

  const confirmDelete = () => {
    if (ticketToDelete) {
      onDeleteTicket(ticketToDelete.id);
      setTicketToDelete(null);
    }
  };

  return (
    <div className="flex-1 flex flex-col bg-[#111b21] text-[#e9edef] overflow-hidden">
      {/* Top Header */}
      <div className="h-16 px-4 bg-[#202c33] border-b border-[#222e35] flex items-center justify-between shrink-0">
        <div className="flex items-center gap-3">
          <button
            onClick={onBackToChat}
            className="p-2 rounded-full hover:bg-[#374248] text-[#aebac1] hover:text-[#e9edef] transition-colors"
            title="Voltar para a conversa"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h2 className="text-sm font-bold text-[#e9edef] flex items-center gap-2">
              <span>Gestão de Chamados & Protocolos</span>
              <span className="text-[11px] font-mono font-semibold px-2 py-0.5 rounded-full bg-[#111b21] text-[#00a884] border border-[#2a3942]">
                {tickets.length} total
              </span>
            </h2>
            <p className="text-[11px] text-[#8696a0]">
              Controle de status, cancelamento e exclusão de transbordos
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => onOpenTriage("support_n2")}
            className="px-3.5 py-1.5 bg-[#00a884] hover:bg-[#02906f] text-[#111b21] rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors shadow-sm"
          >
            <Plus className="w-4 h-4" />
            <span>Novo Chamado</span>
          </button>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="p-4 bg-[#182229] border-b border-[#222e35] space-y-3 shrink-0">
        {/* Search Field */}
        <div className="relative">
          <Search className="w-4 h-4 text-[#8696a0] absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Buscar por protocolo, domínio, e-mail, CNPJ ou assunto..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-[#202c33] border border-[#2a3942] rounded-xl pl-9 pr-8 py-2 text-xs text-[#e9edef] placeholder-[#8696a0] focus:outline-none focus:border-[#00a884] transition-colors"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery("")}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-[#8696a0] hover:text-[#e9edef] text-xs"
            >
              ✕
            </button>
          )}
        </div>

        {/* Status Filter Chips */}
        <div className="flex flex-wrap items-center gap-1.5 text-xs">
          <span className="text-[11px] text-[#8696a0] mr-1 font-medium flex items-center gap-1">
            <Filter className="w-3 h-3" /> Status:
          </span>

          <button
            onClick={() => setStatusFilter("all")}
            className={`px-2.5 py-1 rounded-lg font-medium text-[11px] transition-colors ${
              statusFilter === "all"
                ? "bg-[#00a884] text-[#111b21] font-bold"
                : "bg-[#202c33] text-[#8696a0] hover:text-[#e9edef] hover:bg-[#2a3942]"
            }`}
          >
            Todos ({tickets.length})
          </button>

          {/* Não iniciado - Vermelho */}
          <button
            onClick={() => setStatusFilter("not_started")}
            className={`px-2.5 py-1 rounded-lg font-medium text-[11px] flex items-center gap-1.5 transition-colors border ${
              statusFilter === "not_started"
                ? "bg-rose-500 text-white font-bold border-rose-500"
                : "bg-rose-500/10 text-rose-400 border-rose-500/30 hover:bg-rose-500/20"
            }`}
          >
            <span className="w-2 h-2 rounded-full bg-rose-500"></span>
            <span>Não iniciado ({countNotStarted})</span>
          </button>

          {/* Em andamento - Amarelo */}
          <button
            onClick={() => setStatusFilter("in_progress")}
            className={`px-2.5 py-1 rounded-lg font-medium text-[11px] flex items-center gap-1.5 transition-colors border ${
              statusFilter === "in_progress"
                ? "bg-amber-500 text-[#111b21] font-bold border-amber-500"
                : "bg-amber-500/10 text-amber-400 border-amber-500/30 hover:bg-amber-500/20"
            }`}
          >
            <span className="w-2 h-2 rounded-full bg-amber-500"></span>
            <span>Em andamento ({countInProgress})</span>
          </button>

          {/* Concluído - Verde */}
          <button
            onClick={() => setStatusFilter("completed")}
            className={`px-2.5 py-1 rounded-lg font-medium text-[11px] flex items-center gap-1.5 transition-colors border ${
              statusFilter === "completed"
                ? "bg-emerald-500 text-[#111b21] font-bold border-emerald-500"
                : "bg-emerald-500/10 text-emerald-400 border-emerald-500/30 hover:bg-emerald-500/20"
            }`}
          >
            <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
            <span>Concluído ({countCompleted})</span>
          </button>

          {/* Cancelado */}
          <button
            onClick={() => setStatusFilter("cancelled")}
            className={`px-2.5 py-1 rounded-lg font-medium text-[11px] flex items-center gap-1.5 transition-colors border ${
              statusFilter === "cancelled"
                ? "bg-slate-600 text-white font-bold border-slate-500"
                : "bg-slate-500/10 text-slate-400 border-slate-500/30 hover:bg-slate-500/20"
            }`}
          >
            <span className="w-2 h-2 rounded-full bg-slate-500"></span>
            <span>Cancelado ({countCancelled})</span>
          </button>
        </div>
      </div>

      {/* Tickets List Area */}
      <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-3">
        {filteredTickets.length === 0 ? (
          <div className="h-full min-h-[300px] flex flex-col items-center justify-center text-center p-6 text-[#8696a0] space-y-3">
            <div className="w-14 h-14 rounded-full bg-[#202c33] border border-[#2a3942] flex items-center justify-center text-[#8696a0]">
              <FileText className="w-7 h-7" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-[#e9edef]">Nenhum chamado encontrado</h3>
              <p className="text-xs max-w-sm mt-1">
                {searchQuery || statusFilter !== "all"
                  ? "Tente ajustar a busca ou os filtros de status acima."
                  : "Abra um novo chamado de Suporte N2, Comercial ou Financeiro para gerenciar os protocolos."}
              </p>
            </div>
            {(searchQuery || statusFilter !== "all") && (
              <button
                onClick={() => {
                  setSearchQuery("");
                  setStatusFilter("all");
                }}
                className="px-3 py-1.5 bg-[#202c33] hover:bg-[#2a3942] text-[#00a884] rounded-lg text-xs font-semibold transition-colors"
              >
                Limpar Filtros
              </button>
            )}
          </div>
        ) : (
          filteredTickets.map((t) => {
            const currentStatus: TicketStatus = t.status || "not_started";
            const statusInfo = statusConfig[currentStatus] || statusConfig.not_started;
            const StatusIcon = statusInfo.icon;
            const typeBadge = getTypeBadge(t.type);
            const TypeIcon = typeBadge.icon;

            return (
              <div
                key={t.id}
                className="bg-[#202c33] border border-[#2a3942] rounded-xl p-4 space-y-3 hover:border-[#374248] transition-all shadow-sm relative group"
              >
                {/* Card Top Row: Protocol, Type Badge, Status Selector and Actions */}
                <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#2a3942] pb-3">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-mono text-xs font-bold text-[#00a884] bg-[#111b21] px-2 py-0.5 rounded border border-[#2a3942]">
                      #{t.id}
                    </span>

                    {/* Sector Badge */}
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full border flex items-center gap-1 ${typeBadge.bg} ${typeBadge.text} ${typeBadge.border}`}
                    >
                      <TypeIcon className="w-3 h-3" />
                      {typeBadge.label}
                    </span>

                    {/* Active Status Badge (clickable to open drawer) */}
                    <button
                      onClick={() => setTicketForDrawer(t)}
                      className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full border flex items-center gap-1.5 hover:opacity-90 transition-all cursor-pointer ${statusInfo.bg} ${statusInfo.text} ${statusInfo.border}`}
                      title="Clique para abrir a gaveta de alteração de status"
                    >
                      <span className={`w-1.5 h-1.5 rounded-full ${statusInfo.dot}`}></span>
                      <StatusIcon className="w-3 h-3" />
                      <span>{statusInfo.label}</span>
                      <ChevronDown className="w-3 h-3 opacity-70" />
                    </button>
                  </div>

                  <span className="text-[11px] text-[#8696a0] flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    <span>{formatDate(t.createdAt)}</span>
                  </span>
                </div>

                {/* Subject & Description */}
                <div>
                  <h4 className="text-sm font-semibold text-[#e9edef]">{t.subject}</h4>
                </div>

                {/* Details Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2 text-xs bg-[#111b21]/60 p-3 rounded-lg border border-[#2a3942]/60">
                  {t.domain && (
                    <div className="text-[#8696a0]">
                      <span className="block text-[10px] uppercase font-bold text-[#8696a0]">Domínio:</span>
                      <span className="text-[#e9edef] font-semibold">@{t.domain}</span>
                    </div>
                  )}
                  {t.affectedEmail && (
                    <div className="text-[#8696a0]">
                      <span className="block text-[10px] uppercase font-bold text-[#8696a0]">E-mail Afetado:</span>
                      <span className="text-[#e9edef] font-mono text-[11px]">{t.affectedEmail}</span>
                    </div>
                  )}
                  {t.cnpjOrCorporateName && (
                    <div className="text-[#8696a0]">
                      <span className="block text-[10px] uppercase font-bold text-[#8696a0]">CNPJ / Razão:</span>
                      <span className="text-[#e9edef]">{t.cnpjOrCorporateName}</span>
                    </div>
                  )}
                  {t.contactName && (
                    <div className="text-[#8696a0]">
                      <span className="block text-[10px] uppercase font-bold text-[#8696a0]">Contato:</span>
                      <span className="text-[#e9edef]">{t.contactName}</span>
                    </div>
                  )}
                  {t.phone && (
                    <div className="text-[#8696a0]">
                      <span className="block text-[10px] uppercase font-bold text-[#8696a0]">Telefone:</span>
                      <span className="text-[#e9edef]">{t.phone}</span>
                    </div>
                  )}
                  {t.approxAccountsOrResources && (
                    <div className="text-[#8696a0]">
                      <span className="block text-[10px] uppercase font-bold text-[#8696a0]">Contas / Recursos:</span>
                      <span className="text-[#e9edef]">{t.approxAccountsOrResources}</span>
                    </div>
                  )}
                </div>

                {t.errorMessage && (
                  <div className="p-2.5 bg-[#111b21] rounded-lg text-[11px] font-mono text-[#53bdeb] border border-[#2a3942] leading-relaxed">
                    <span className="text-[#8696a0] font-sans font-bold block mb-0.5 text-[10px] uppercase">
                      Log / Mensagem de Erro:
                    </span>
                    {t.errorMessage}
                  </div>
                )}

                {/* Print / Foto Anexada do Erro ou Demanda */}
                {t.attachmentImage && (
                  <div className="p-3 bg-[#111b21] rounded-xl border border-[#2a3942] space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1.5 text-xs font-semibold text-[#e9edef]">
                        <ImageIcon className="w-4 h-4 text-[#00a884]" />
                        <span>Print / Foto do Erro Anexada:</span>
                        {t.attachmentImage.fileName && (
                          <span className="text-[11px] font-normal text-[#8696a0] hidden sm:inline">
                            ({t.attachmentImage.fileName})
                          </span>
                        )}
                      </div>
                      <button
                        type="button"
                        onClick={() =>
                          setPreviewImage({
                            url: t.attachmentImage!.url,
                            title: `Anexo do Chamado #${t.id} - ${t.subject}`,
                          })
                        }
                        className="text-[11px] font-medium text-[#00a884] hover:text-[#02906f] hover:underline flex items-center gap-1"
                      >
                        <ZoomIn className="w-3.5 h-3.5" />
                        <span>Ampliar Imagem</span>
                      </button>
                    </div>

                    <div className="relative group/thumb rounded-lg overflow-hidden border border-[#2a3942] bg-black/40 max-w-md">
                      <img
                        src={t.attachmentImage.url}
                        alt={t.attachmentImage.fileName || "Print anexado"}
                        className="w-full max-h-56 object-cover cursor-pointer hover:scale-102 transition-transform duration-200"
                        onClick={() =>
                          setPreviewImage({
                            url: t.attachmentImage!.url,
                            title: `Anexo do Chamado #${t.id} - ${t.subject}`,
                          })
                        }
                      />
                      <div
                        onClick={() =>
                          setPreviewImage({
                            url: t.attachmentImage!.url,
                            title: `Anexo do Chamado #${t.id} - ${t.subject}`,
                          })
                        }
                        className="absolute inset-0 bg-black/40 opacity-0 group-hover/thumb:opacity-100 transition-opacity flex items-center justify-center cursor-pointer"
                      >
                        <span className="px-3 py-1.5 rounded-full bg-black/70 text-white text-xs font-semibold flex items-center gap-1.5 shadow-md">
                          <Eye className="w-3.5 h-3.5 text-[#00a884]" />
                          <span>Clique para ver tela cheia</span>
                        </span>
                      </div>
                    </div>
                  </div>
                )}

                {/* Status Changer & Action Buttons Bar */}
                <div className="flex flex-wrap items-center justify-between gap-2.5 pt-2.5 border-t border-[#2a3942]">
                  {/* Direct Status Selector */}
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span className="text-[10px] text-[#8696a0] font-medium mr-0.5">Status:</span>
                    <button
                      onClick={() => onUpdateStatus(t.id, "not_started")}
                      className={`px-2 py-0.5 rounded-lg text-[10px] font-semibold transition-all border cursor-pointer ${
                        currentStatus === "not_started"
                          ? "bg-rose-500/25 text-rose-300 border-rose-500/60 shadow-sm"
                          : "bg-[#111b21] text-[#8696a0] border-[#2a3942] hover:text-rose-300"
                      }`}
                      title="Marcar como Não Iniciado"
                    >
                      🔴 Não iniciado
                    </button>
                    <button
                      onClick={() => onUpdateStatus(t.id, "in_progress")}
                      className={`px-2 py-0.5 rounded-lg text-[10px] font-semibold transition-all border cursor-pointer ${
                        currentStatus === "in_progress"
                          ? "bg-amber-500/25 text-amber-300 border-amber-500/60 shadow-sm"
                          : "bg-[#111b21] text-[#8696a0] border-[#2a3942] hover:text-amber-300"
                      }`}
                      title="Marcar como Em Andamento"
                    >
                      🟡 Em andamento
                    </button>
                    <button
                      onClick={() => onUpdateStatus(t.id, "completed")}
                      className={`px-2 py-0.5 rounded-lg text-[10px] font-semibold transition-all border cursor-pointer ${
                        currentStatus === "completed"
                          ? "bg-emerald-500/25 text-emerald-300 border-emerald-500/60 shadow-sm"
                          : "bg-[#111b21] text-[#8696a0] border-[#2a3942] hover:text-emerald-300"
                      }`}
                      title="Marcar como Concluído"
                    >
                      🟢 Concluído
                    </button>
                  </div>

                  {/* Actions: Atender, Detalhes & Excluir */}
                  <div className="flex items-center gap-2">
                    {onBackToChat && (
                      <button
                        onClick={() => {
                          onUpdateStatus(t.id, "in_progress");
                          onBackToChat();
                        }}
                        className="px-2.5 py-1 rounded-lg text-[11px] font-bold bg-[#00a884]/20 hover:bg-[#00a884]/30 text-[#00a884] border border-[#00a884]/40 flex items-center gap-1 transition-colors cursor-pointer shadow-sm"
                        title="Iniciar atendimento direto deste chamado no chat"
                      >
                        <MessageSquare className="w-3.5 h-3.5" />
                        <span>Atender no Chat</span>
                      </button>
                    )}

                    <button
                      onClick={() => setTicketForDrawer(t)}
                      className="px-2.5 py-1 rounded-lg text-[11px] font-medium bg-[#111b21] hover:bg-[#202c33] text-[#00a884] border border-[#2a3942] hover:border-[#00a884]/50 flex items-center gap-1 transition-colors cursor-pointer"
                      title="Ver detalhes e histórico completo"
                    >
                      <SlidersHorizontal className="w-3.5 h-3.5" />
                      <span>Detalhes</span>
                    </button>

                    {deletingTicketId === t.id ? (
                      <div className="flex items-center gap-1.5 bg-rose-500/20 border border-rose-500/50 rounded-lg px-2 py-0.5 animate-in fade-in">
                        <span className="text-[10px] text-rose-300 font-bold">Excluir?</span>
                        <button
                          type="button"
                          onClick={() => {
                            onDeleteTicket(t.id);
                            setDeletingTicketId(null);
                          }}
                          className="px-2 py-0.5 rounded bg-rose-600 hover:bg-rose-700 text-white text-[10px] font-bold transition-colors cursor-pointer shadow-sm"
                          title="Confirmar exclusão definitiva"
                        >
                          Sim, Excluir
                        </button>
                        <button
                          type="button"
                          onClick={() => setDeletingTicketId(null)}
                          className="px-1.5 py-0.5 rounded bg-[#202c33] hover:bg-[#2a3942] text-[#8696a0] hover:text-white text-[10px] transition-colors cursor-pointer"
                          title="Cancelar"
                        >
                          Não
                        </button>
                      </div>
                    ) : (
                      <button
                        onClick={() => setDeletingTicketId(t.id)}
                        className="px-2.5 py-1 rounded-lg text-[11px] font-medium bg-red-950/40 hover:bg-red-900/60 text-red-400 hover:text-red-300 border border-red-800/40 hover:border-red-700/60 flex items-center gap-1 transition-colors cursor-pointer"
                        title="Excluir este chamado permanentemente"
                      >
                        <Trash2 className="w-3.5 h-3.5 text-red-400" />
                        <span>Excluir</span>
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Slide-over Ticket Status Drawer */}
      <TicketStatusDrawer
        isOpen={!!ticketForDrawer}
        ticket={ticketForDrawer}
        onClose={() => setTicketForDrawer(null)}
        onSelectStatus={onUpdateStatus}
        onDeleteTicket={(id) => {
          onDeleteTicket(id);
          setTicketForDrawer(null);
        }}
      />

      {/* Preview Fullscreen Image Modal */}
      {previewImage && (
        <div
          className="fixed inset-0 bg-black/90 backdrop-blur-md z-60 flex flex-col items-center justify-center p-4 animate-in fade-in duration-200"
          onClick={() => setPreviewImage(null)}
        >
          <div className="absolute top-4 right-4 flex items-center gap-2 z-10">
            <button
              onClick={() => setPreviewImage(null)}
              className="p-2.5 rounded-full bg-[#202c33]/80 hover:bg-[#374248] text-white transition-colors border border-white/10"
              title="Fechar visualização"
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          <div
            className="max-w-4xl max-h-[85vh] flex flex-col items-center gap-2"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="w-full flex items-center justify-between px-2 text-xs text-[#8696a0]">
              <span className="font-semibold text-[#e9edef] truncate">{previewImage.title}</span>
              <span className="text-[11px] text-[#00a884]">Visualização em Alta Resolução</span>
            </div>
            <img
              src={previewImage.url}
              alt="Print ampliado do erro"
              className="max-w-full max-h-[80vh] object-contain rounded-xl border border-[#2a3942] shadow-2xl bg-black/60"
            />
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {ticketToDelete && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[#202c33] border border-[#2a3942] rounded-2xl p-5 max-w-md w-full space-y-4 shadow-2xl animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center gap-3 text-red-400">
              <div className="p-2 rounded-xl bg-red-500/10 border border-red-500/30">
                <Trash2 className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-[#e9edef]">Excluir Chamado</h3>
                <p className="text-xs text-[#8696a0]">Protocolo: #{ticketToDelete.id}</p>
              </div>
            </div>

            <p className="text-xs text-[#8696a0] leading-relaxed">
              Tem certeza que deseja excluir permanentemente o chamado{" "}
              <strong className="text-[#e9edef]">{ticketToDelete.subject}</strong>? Esta ação não pode ser desfeita.
            </p>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-[#2a3942]">
              <button
                onClick={() => setTicketToDelete(null)}
                className="px-3.5 py-2 rounded-xl text-xs font-semibold bg-[#111b21] hover:bg-[#182229] text-[#e9edef] border border-[#2a3942] transition-colors"
              >
                Manter Chamado
              </button>
              <button
                onClick={confirmDelete}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-red-600 hover:bg-red-500 text-white transition-colors flex items-center gap-1.5"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Sim, Excluir</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
