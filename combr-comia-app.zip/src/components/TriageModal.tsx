import React, { useState, useEffect, useRef } from "react";
import {
  X,
  Building2,
  Globe,
  User,
  Mail,
  Phone,
  Send,
  CheckCircle2,
  ShieldAlert,
  Wrench,
  CreditCard,
  FileText,
  HelpCircle,
  Sparkles,
  Paperclip,
  Image as ImageIcon,
  Trash2,
  ExternalLink,
} from "lucide-react";
import confetti from "canvas-confetti";
import { Ticket, TriageType } from "../types";
import { createRemoteOrLocalTicket } from "../lib/api";

interface TriageModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialType?: TriageType;
  onTicketCreated?: (ticket: Ticket) => void;
}

export const TriageModal: React.FC<TriageModalProps> = ({
  isOpen,
  onClose,
  initialType = "support_n2",
  onTicketCreated,
}) => {
  const [type, setType] = useState<TriageType>(initialType);

  // Synchronize internal type whenever modal opens or initialType changes from parent
  useEffect(() => {
    if (isOpen && initialType) {
      setType(initialType);
      setCreatedTicket(null);
      setError(null);
    }
  }, [isOpen, initialType]);

  // Clear errors when user toggles tab
  useEffect(() => {
    setError(null);
  }, [type]);

  // Common fields
  const [companyName, setCompanyName] = useState("");
  const [cnpjOrCorporateName, setCnpjOrCorporateName] = useState("");
  const [domain, setDomain] = useState("");
  const [contactName, setContactName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [subject, setSubject] = useState("");

  // N2 Specific
  const [affectedEmail, setAffectedEmail] = useState("");
  const [errorMessage, setErrorMessage] = useState("");

  // Commercial Specific
  const [approxAccountsOrResources, setApproxAccountsOrResources] = useState("");

  // Attachment state (Image or Print of error / request)
  const [attachedImage, setAttachedImage] = useState<{
    url: string;
    fileName: string;
    size: string;
  } | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const [loading, setLoading] = useState(false);
  const [createdTicket, setCreatedTicket] = useState<Ticket | null>(null);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith("image/")) {
      setError("Por favor, selecione um arquivo de imagem (PNG, JPG, WEBP, GIF).");
      return;
    }

    if (file.size > 15 * 1024 * 1024) {
      setError("A imagem deve ter no máximo 15 MB.");
      return;
    }

    setError(null);
    const sizeStr = file.size < 1024 * 1024
      ? `${(file.size / 1024).toFixed(0)} KB`
      : `${(file.size / (1024 * 1024)).toFixed(1)} MB`;

    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === "string") {
        setAttachedImage({
          url: reader.result,
          fileName: file.name,
          size: sizeStr,
        });
      }
    };
    reader.readAsDataURL(file);
    e.target.value = "";
  };

  const handleRemoveAttachment = () => {
    setAttachedImage(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    // Validate per type
    if (type === "support_n2") {
      if (!domain.trim() || !affectedEmail.trim()) {
        setError("Por favor, preencha o Domínio (@empresa.com.br) e o E-mail afetado para o Suporte N2.");
        return;
      }
    } else if (type === "commercial") {
      if (!cnpjOrCorporateName.trim() || !phone.trim()) {
        setError("Por favor, preencha o CNPJ/Razão Social e o Telefone de contato para a equipe Comercial.");
        return;
      }
    } else if (type === "financial") {
      if (!cnpjOrCorporateName.trim()) {
        setError("Por favor, preencha o CNPJ ou Razão Social cadastrada na ComBR.");
        return;
      }
    }

    setLoading(true);

    try {
      const newTicket = await createRemoteOrLocalTicket({
        type,
        domain,
        cnpjOrCorporateName,
        companyName,
        contactName,
        phone,
        email,
        subject:
          subject ||
          (type === "support_n2"
            ? "Suporte N2 - Erro / DNS / Migração"
            : type === "financial"
            ? "Financeiro - 2ª Via Boleto / Fatura / NF"
            : "Comercial - Orçamento / Novos Recursos Cloud"),
        affectedEmail,
        errorMessage,
        approxAccountsOrResources,
        attachmentImage: attachedImage ? {
          url: attachedImage.url,
          fileName: attachedImage.fileName,
          size: attachedImage.size,
        } : undefined,
      });

      setCreatedTicket(newTicket);
      if (onTicketCreated) {
        onTicketCreated(newTicket);
      }

      try {
        confetti({
          particleCount: 70,
          spread: 80,
          origin: { y: 0.6 },
        });
      } catch (err) {}
    } catch (err: any) {
      setError(err.message || "Ocorreu um erro ao registrar o chamado.");
    } finally {
      setLoading(false);
    }
  };

  const handleReset = () => {
    setCreatedTicket(null);
    setCnpjOrCorporateName("");
    setDomain("");
    setCompanyName("");
    setContactName("");
    setEmail("");
    setPhone("");
    setSubject("");
    setAffectedEmail("");
    setErrorMessage("");
    setApproxAccountsOrResources("");
    setAttachedImage(null);
    setError(null);
    onClose();
  };

  const getTypeName = (t: TriageType) => {
    switch (t) {
      case "support_n2":
        return "Suporte Técnico N2 (Especializado)";
      case "commercial":
        return "Comercial & Vendas (Cloud / E-mails)";
      case "financial":
        return "Financeiro & Faturamento";
    }
  };

  return (
    <div
      id="triage-modal-overlay"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-[#0c1317]/85 backdrop-blur-sm select-none"
    >
      <div
        id="triage-modal-container"
        className="w-full max-w-lg bg-[#111b21] border border-[#2a3942] rounded-2xl shadow-2xl overflow-hidden transition-all max-h-[92vh] flex flex-col text-[#e9edef]"
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-[#222e35] bg-[#202c33] shrink-0">
          <div className="flex items-center gap-3">
            <div
              className={`p-2 rounded-xl border ${
                type === "support_n2"
                  ? "bg-[#53bdeb]/10 border-[#53bdeb]/30 text-[#53bdeb]"
                  : type === "financial"
                  ? "bg-[#ffd279]/10 border-[#ffd279]/30 text-[#ffd279]"
                  : "bg-[#00a884]/10 border-[#00a884]/30 text-[#00a884]"
              }`}
            >
              {type === "support_n2" ? (
                <Wrench className="w-5 h-5" />
              ) : type === "financial" ? (
                <CreditCard className="w-5 h-5" />
              ) : (
                <Building2 className="w-5 h-5" />
              )}
            </div>
            <div>
              <h2 className="text-sm font-bold text-[#e9edef]">
                {createdTicket
                  ? "Atendimento Encaminhado"
                  : type === "financial"
                  ? "Financeiro & Faturamento"
                  : type === "commercial"
                  ? "Comercial & Propostas ComBr"
                  : "Suporte Técnico N2 Especializado"}
              </h2>
              <p className="text-[11px] text-[#8696a0]">WhatsApp Business • Transferência para Especialista</p>
            </div>
          </div>
          <button
            id="btn-close-triage-modal"
            onClick={handleReset}
            className="text-[#8696a0] hover:text-[#e9edef] p-1.5 rounded-full hover:bg-[#374248] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="overflow-y-auto p-4 sm:p-5 flex-1 space-y-4">
          {createdTicket ? (
            <div className="text-center space-y-4 py-2">
              <div className="w-14 h-14 bg-[#00a884]/15 border border-[#00a884]/40 rounded-full flex items-center justify-center mx-auto text-[#00a884] shadow-lg">
                <CheckCircle2 className="w-8 h-8" />
              </div>

              <div className="space-y-1">
                <span className="text-xs font-semibold px-3 py-1 rounded-full bg-[#00a884]/15 text-[#00a884] border border-[#00a884]/30">
                  Protocolo Criado com Sucesso
                </span>
                <h3 className="text-lg font-mono font-bold text-[#e9edef] mt-2">#{createdTicket.id}</h3>
                <p className="text-xs text-[#8696a0] max-w-sm mx-auto">
                  Sua solicitação foi encaminhada para a fila humana de{" "}
                  <strong className="text-[#00a884]">{getTypeName(createdTicket.type)}</strong>.
                </p>
              </div>

              <div className="bg-[#202c33] border border-[#2a3942] rounded-xl p-3.5 text-left text-xs space-y-2 font-mono">
                {createdTicket.cnpjOrCorporateName && (
                  <div className="flex justify-between text-[#8696a0]">
                    <span>CNPJ / Razão:</span>
                    <span className="text-[#e9edef] font-semibold">{createdTicket.cnpjOrCorporateName}</span>
                  </div>
                )}
                {createdTicket.domain && (
                  <div className="flex justify-between text-[#8696a0]">
                    <span>Domínio:</span>
                    <span className="text-[#e9edef] font-semibold">{createdTicket.domain}</span>
                  </div>
                )}
                {createdTicket.affectedEmail && (
                  <div className="flex justify-between text-[#8696a0]">
                    <span>E-mail Afetado:</span>
                    <span className="text-[#e9edef]">{createdTicket.affectedEmail}</span>
                  </div>
                )}
                {createdTicket.phone && (
                  <div className="flex justify-between text-[#8696a0]">
                    <span>Telefone/WhatsApp:</span>
                    <span className="text-[#e9edef]">{createdTicket.phone}</span>
                  </div>
                )}
                {createdTicket.attachmentImage && (
                  <div className="pt-2 border-t border-[#2a3942] space-y-1.5">
                    <span className="text-[#8696a0] flex items-center gap-1.5 text-[11px]">
                      <ImageIcon className="w-3 h-3 text-[#00a884]" />
                      Print / Imagem Anexada:
                    </span>
                    <div className="flex items-center gap-2 p-1.5 bg-[#111b21] rounded-lg border border-[#2a3942]">
                      <img
                        src={createdTicket.attachmentImage.url}
                        alt="Anexo"
                        className="w-10 h-10 object-cover rounded-md border border-[#2a3942]"
                      />
                      <span className="text-[11px] text-[#e9edef] truncate">
                        {createdTicket.attachmentImage.fileName || "Print do erro"}
                      </span>
                    </div>
                  </div>
                )}
                <div className="flex justify-between text-[#8696a0] pt-1.5 border-t border-[#2a3942]">
                  <span>Status:</span>
                  <span className="text-[#00a884] font-semibold flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#00a884] animate-pulse"></span>
                    Transferido
                  </span>
                </div>
              </div>

              <button
                id="btn-confirm-ticket-done"
                onClick={handleReset}
                className="w-full py-2.5 px-4 bg-[#00a884] hover:bg-[#02906f] text-[#111b21] rounded-xl text-xs font-bold transition-all shadow-md"
              >
                Voltar à Conversa no WhatsApp
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Type Switcher 3 Tabs */}
              <div className="grid grid-cols-3 gap-1.5 p-1 bg-[#202c33] border border-[#2a3942] rounded-xl">
                <button
                  type="button"
                  id="btn-select-n2"
                  onClick={() => setType("support_n2")}
                  className={`py-2 px-2 text-[11px] font-semibold rounded-lg transition-all flex flex-col sm:flex-row items-center justify-center gap-1 ${
                    type === "support_n2"
                      ? "bg-[#53bdeb] text-[#111b21] font-bold shadow-sm"
                      : "text-[#8696a0] hover:text-[#e9edef]"
                  }`}
                >
                  <Wrench className="w-3.5 h-3.5" />
                  <span>Suporte N2</span>
                </button>

                <button
                  type="button"
                  id="btn-select-commercial"
                  onClick={() => setType("commercial")}
                  className={`py-2 px-2 text-[11px] font-semibold rounded-lg transition-all flex flex-col sm:flex-row items-center justify-center gap-1 ${
                    type === "commercial"
                      ? "bg-[#00a884] text-[#111b21] font-bold shadow-sm"
                      : "text-[#8696a0] hover:text-[#e9edef]"
                  }`}
                >
                  <Building2 className="w-3.5 h-3.5" />
                  <span>Comercial</span>
                </button>

                <button
                  type="button"
                  id="btn-select-financial"
                  onClick={() => setType("financial")}
                  className={`py-2 px-2 text-[11px] font-semibold rounded-lg transition-all flex flex-col sm:flex-row items-center justify-center gap-1 ${
                    type === "financial"
                      ? "bg-[#ffd279] text-[#111b21] font-bold shadow-sm"
                      : "text-[#8696a0] hover:text-[#e9edef]"
                  }`}
                >
                  <CreditCard className="w-3.5 h-3.5" />
                  <span>Financeiro</span>
                </button>
              </div>

              {/* Informative Guidance */}
              <div className="bg-[#202c33]/80 border border-[#2a3942] rounded-xl p-3 text-[11px] text-[#d1d7db] flex items-start gap-2.5">
                <ShieldAlert className="w-4 h-4 mt-0.5 shrink-0 text-[#00a884]" />
                <div>
                  {type === "support_n2" && (
                    <span>
                      <strong>Suporte N2 Especializado:</strong> Para erros de conexão, DNS, migração e servidores. Preencha o <strong>Domínio</strong> e o <strong>E-mail afetado</strong>.
                    </span>
                  )}
                  {type === "commercial" && (
                    <span>
                      <strong>Comercial ComBR:</strong> Para orçamentos, novas contas de e-mail e servidores Cloud. Preencha <strong>CNPJ</strong> e <strong>Telefone</strong>.
                    </span>
                  )}
                  {type === "financial" && (
                    <span>
                      <strong>Financeiro & Faturamento:</strong> Para 2ª via de boleto e notas fiscais. Informe o <strong>CNPJ</strong> ou <strong>Razão Social</strong> cadastrada.
                    </span>
                  )}
                </div>
              </div>

              {error && (
                <div className="p-2.5 text-xs bg-[#f15c6d]/15 border border-[#f15c6d]/30 text-[#f15c6d] rounded-xl">
                  {error}
                </div>
              )}

              {/* Form inputs */}
              {type === "support_n2" && (
                <div className="space-y-3">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[11px] font-medium text-[#8696a0] mb-1">
                        Domínio da Empresa <span className="text-[#f15c6d]">*</span>
                      </label>
                      <div className="relative">
                        <Globe className="w-4 h-4 text-[#8696a0] absolute left-3 top-2.5" />
                        <input
                          id="input-n2-domain"
                          type="text"
                          required
                          placeholder="empresa.com.br"
                          value={domain}
                          onChange={(e) => setDomain(e.target.value)}
                          className="w-full pl-9 pr-3 py-2 bg-[#202c33] border border-[#2a3942] rounded-xl text-xs text-[#e9edef] placeholder-[#8696a0] focus:outline-none focus:border-[#00a884] transition-colors"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-[11px] font-medium text-[#8696a0] mb-1">
                        E-mail Afetado <span className="text-[#f15c6d]">*</span>
                      </label>
                      <div className="relative">
                        <Mail className="w-4 h-4 text-[#8696a0] absolute left-3 top-2.5" />
                        <input
                          id="input-n2-affected-email"
                          type="email"
                          required
                          placeholder="contato@empresa.com.br"
                          value={affectedEmail}
                          onChange={(e) => setAffectedEmail(e.target.value)}
                          className="w-full pl-9 pr-3 py-2 bg-[#202c33] border border-[#2a3942] rounded-xl text-xs text-[#e9edef] placeholder-[#8696a0] focus:outline-none focus:border-[#00a884] transition-colors"
                        />
                      </div>
                    </div>
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="text-[11px] font-medium text-[#8696a0]">
                        Código ou Mensagem de Erro / Descrição
                      </label>
                      <button
                        type="button"
                        onClick={() => fileInputRef.current?.click()}
                        className="text-[11px] text-[#00a884] hover:underline flex items-center gap-1 cursor-pointer"
                        title="Anexar foto ou print do erro"
                      >
                        <Paperclip className="w-3 h-3" />
                        <span>{attachedImage ? "Print anexado ✓" : "Anexar print do erro"}</span>
                      </button>
                    </div>
                    <textarea
                      id="input-n2-error-message"
                      rows={2}
                      placeholder="Ex: Erro 550 Relay Access Denied, Falha SSL, Bounce de e-mail..."
                      value={errorMessage}
                      onChange={(e) => setErrorMessage(e.target.value)}
                      className="w-full px-3 py-2 bg-[#202c33] border border-[#2a3942] rounded-xl text-xs text-[#e9edef] placeholder-[#8696a0] focus:outline-none focus:border-[#00a884] transition-colors resize-none font-mono"
                    ></textarea>
                  </div>
                </div>
              )}

              {type === "commercial" && (
                <div className="space-y-3">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[11px] font-medium text-[#8696a0] mb-1">
                        Nome da Empresa
                      </label>
                      <div className="relative">
                        <Building2 className="w-4 h-4 text-[#8696a0] absolute left-3 top-2.5" />
                        <input
                          id="input-com-company"
                          type="text"
                          placeholder="Empresa LTDA"
                          value={companyName}
                          onChange={(e) => setCompanyName(e.target.value)}
                          className="w-full pl-9 pr-3 py-2 bg-[#202c33] border border-[#2a3942] rounded-xl text-xs text-[#e9edef] placeholder-[#8696a0] focus:outline-none focus:border-[#00a884] transition-colors"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-[11px] font-medium text-[#8696a0] mb-1">
                        CNPJ <span className="text-[#f15c6d]">*</span>
                      </label>
                      <input
                        id="input-com-cnpj"
                        type="text"
                        required
                        placeholder="00.000.000/0001-00"
                        value={cnpjOrCorporateName}
                        onChange={(e) => setCnpjOrCorporateName(e.target.value)}
                        className="w-full px-3 py-2 bg-[#202c33] border border-[#2a3942] rounded-xl text-xs text-[#e9edef] placeholder-[#8696a0] focus:outline-none focus:border-[#00a884] transition-colors"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[11px] font-medium text-[#8696a0] mb-1">
                        Telefone / WhatsApp <span className="text-[#f15c6d]">*</span>
                      </label>
                      <div className="relative">
                        <Phone className="w-4 h-4 text-[#8696a0] absolute left-3 top-2.5" />
                        <input
                          id="input-com-phone"
                          type="text"
                          required
                          placeholder="(11) 99999-9999"
                          value={phone}
                          onChange={(e) => setPhone(e.target.value)}
                          className="w-full pl-9 pr-3 py-2 bg-[#202c33] border border-[#2a3942] rounded-xl text-xs text-[#e9edef] placeholder-[#8696a0] focus:outline-none focus:border-[#00a884] transition-colors"
                        />
                      </div>
                    </div>

                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <label className="text-[11px] font-medium text-[#8696a0]">
                          Contas / Recursos Desejados
                        </label>
                        <button
                          type="button"
                          onClick={() => fileInputRef.current?.click()}
                          className="text-[11px] text-[#00a884] hover:underline flex items-center gap-1 cursor-pointer"
                          title="Anexar print ou cotação"
                        >
                          <Paperclip className="w-3 h-3" />
                          <span>{attachedImage ? "Print anexado ✓" : "Anexar print"}</span>
                        </button>
                      </div>
                      <input
                        id="input-com-resources"
                        type="text"
                        placeholder="Ex: 25 contas, 100GB, Cloud AWS"
                        value={approxAccountsOrResources}
                        onChange={(e) => setApproxAccountsOrResources(e.target.value)}
                        className="w-full px-3 py-2 bg-[#202c33] border border-[#2a3942] rounded-xl text-xs text-[#e9edef] placeholder-[#8696a0] focus:outline-none focus:border-[#00a884] transition-colors"
                      />
                    </div>
                  </div>
                </div>
              )}

              {type === "financial" && (
                <div className="space-y-3">
                  <div>
                    <label className="block text-[11px] font-medium text-[#8696a0] mb-1">
                      CNPJ ou Razão Social na ComBR <span className="text-[#f15c6d]">*</span>
                    </label>
                    <div className="relative">
                      <CreditCard className="w-4 h-4 text-[#8696a0] absolute left-3 top-2.5" />
                      <input
                        id="input-fin-cnpj-corporate"
                        type="text"
                        required
                        placeholder="Informe o CNPJ ou a Razão Social"
                        value={cnpjOrCorporateName}
                        onChange={(e) => setCnpjOrCorporateName(e.target.value)}
                        className="w-full pl-9 pr-3 py-2 bg-[#202c33] border border-[#2a3942] rounded-xl text-xs text-[#e9edef] placeholder-[#8696a0] focus:outline-none focus:border-[#00a884] transition-colors"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[11px] font-medium text-[#8696a0] mb-1">
                        Nome do Solicitante
                      </label>
                      <div className="relative">
                        <User className="w-4 h-4 text-[#8696a0] absolute left-3 top-2.5" />
                        <input
                          id="input-fin-name"
                          type="text"
                          placeholder="Seu nome"
                          value={contactName}
                          onChange={(e) => setContactName(e.target.value)}
                          className="w-full pl-9 pr-3 py-2 bg-[#202c33] border border-[#2a3942] rounded-xl text-xs text-[#e9edef] placeholder-[#8696a0] focus:outline-none focus:border-[#00a884] transition-colors"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-[11px] font-medium text-[#8696a0] mb-1">
                        E-mail de Retorno
                      </label>
                      <div className="relative">
                        <Mail className="w-4 h-4 text-[#8696a0] absolute left-3 top-2.5" />
                        <input
                          id="input-fin-email"
                          type="email"
                          placeholder="financeiro@empresa.com.br"
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          className="w-full pl-9 pr-3 py-2 bg-[#202c33] border border-[#2a3942] rounded-xl text-xs text-[#e9edef] placeholder-[#8696a0] focus:outline-none focus:border-[#00a884] transition-colors"
                        />
                      </div>
                    </div>
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="text-[11px] font-medium text-[#8696a0]">
                        Assunto / Solicitação
                      </label>
                      <button
                        type="button"
                        onClick={() => fileInputRef.current?.click()}
                        className="text-[11px] text-[#00a884] hover:underline flex items-center gap-1 cursor-pointer"
                        title="Anexar comprovante ou documento"
                      >
                        <Paperclip className="w-3 h-3" />
                        <span>{attachedImage ? "Anexo pronto ✓" : "Anexar comprovante/foto"}</span>
                      </button>
                    </div>
                    <textarea
                      id="input-fin-subject"
                      rows={2}
                      placeholder="Ex: Solicito 2ª via do boleto vencimento 10/09..."
                      value={subject}
                      onChange={(e) => setSubject(e.target.value)}
                      className="w-full px-3 py-2 bg-[#202c33] border border-[#2a3942] rounded-xl text-xs text-[#e9edef] placeholder-[#8696a0] focus:outline-none focus:border-[#00a884] transition-colors resize-none"
                    ></textarea>
                  </div>
                </div>
              )}

              <div className="bg-[#182229] border border-[#2a3942] rounded-xl p-3 space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 rounded-lg bg-[#00a884]/15 text-[#00a884] flex items-center justify-center">
                      <ImageIcon className="w-3.5 h-3.5" />
                    </div>
                    <div>
                      <span className="text-xs font-semibold text-[#e9edef] block">
                        Anexar Imagem / Print
                      </span>
                      <span className="text-[11px] text-[#8696a0] block">
                        {type === "support_n2"
                          ? "Print do erro na tela, aviso do Outlook ou log"
                          : type === "financial"
                          ? "Comprovante, boleto anterior ou documento"
                          : "Foto da demanda, print de cotação ou escopo"}
                      </span>
                    </div>
                  </div>

                  <input
                    ref={fileInputRef}
                    id="input-triage-attachment"
                    type="file"
                    accept="image/*"
                    onChange={handleFileChange}
                    className="hidden"
                  />

                  <button
                    type="button"
                    id="btn-triage-attach-image"
                    onClick={() => fileInputRef.current?.click()}
                    className="px-3 py-1.5 bg-[#202c33] hover:bg-[#2a3942] border border-[#2a3942] hover:border-[#00a884]/50 text-[#e9edef] rounded-lg text-xs font-medium flex items-center gap-1.5 transition-all shadow-xs"
                  >
                    <Paperclip className="w-3.5 h-3.5 text-[#00a884]" />
                    <span>{attachedImage ? "Trocar Foto" : "Anexar Foto"}</span>
                  </button>
                </div>

                {attachedImage && (
                  <div className="relative mt-2 p-2 bg-[#111b21] border border-[#2a3942] rounded-lg flex items-center gap-3">
                    <img
                      src={attachedImage.url}
                      alt="Print anexado"
                      className="w-14 h-14 object-cover rounded-md border border-[#2a3942]"
                    />
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-medium text-[#e9edef] truncate">
                        {attachedImage.fileName}
                      </p>
                      <p className="text-[11px] text-[#8696a0]">
                        {attachedImage.size} • Imagem anexada com sucesso
                      </p>
                    </div>
                    <button
                      type="button"
                      id="btn-remove-triage-attachment"
                      onClick={handleRemoveAttachment}
                      className="p-1.5 text-[#8696a0] hover:text-[#f15c6d] rounded-lg hover:bg-[#202c33] transition-colors"
                      title="Remover anexo"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                )}
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  id="btn-submit-triage"
                  disabled={loading}
                  className="w-full py-2.5 px-4 bg-[#00a884] hover:bg-[#02906f] disabled:opacity-50 text-[#111b21] rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all shadow-md"
                >
                  {loading ? (
                    <span className="inline-block w-4 h-4 border-2 border-[#111b21]/40 border-t-[#111b21] rounded-full animate-spin"></span>
                  ) : (
                    <>
                      <Send className="w-3.5 h-3.5" />
                      <span>Transferir para Atendente Humano</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
