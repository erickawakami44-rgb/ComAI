import React, { useState, useEffect } from "react";
import {
  Volume2,
  VolumeX,
  Sparkles,
  Play,
  Square,
  X,
  Settings,
  Check,
  Headphones,
  Sliders,
} from "lucide-react";
import {
  getAvailableVoices,
  VoiceOption,
  TTS_STORAGE_KEYS,
  speakHumanized,
  stopSpeech,
  isSpeaking,
} from "../lib/speechVoice";

interface VoiceAccessibilityModalProps {
  isOpen: boolean;
  onClose: () => void;
  ttsEnabled: boolean;
  onToggleTTS: () => void;
  selectedVoiceUri: string | null;
  onSelectVoiceUri: (uri: string | null) => void;
  playbackRate: number;
  onChangePlaybackRate: (rate: number) => void;
}

export const VoiceAccessibilityModal: React.FC<VoiceAccessibilityModalProps> = ({
  isOpen,
  onClose,
  ttsEnabled,
  onToggleTTS,
  selectedVoiceUri,
  onSelectVoiceUri,
  playbackRate,
  onChangePlaybackRate,
}) => {
  const [voices, setVoices] = useState<VoiceOption[]>([]);
  const [isPlayingSample, setIsPlayingSample] = useState<boolean>(false);

  useEffect(() => {
    const loadVoices = () => {
      const list = getAvailableVoices();
      setVoices(list);
    };

    loadVoices();
    if (typeof window !== "undefined" && "speechSynthesis" in window) {
      window.speechSynthesis.onvoiceschanged = loadVoices;
    }

    return () => {
      if (typeof window !== "undefined" && "speechSynthesis" in window) {
        window.speechSynthesis.onvoiceschanged = null;
      }
    };
  }, []);

  // Stop preview if modal closes
  useEffect(() => {
    if (!isOpen) {
      if (isPlayingSample) {
        stopSpeech();
        setIsPlayingSample(false);
      }
    }
  }, [isOpen, isPlayingSample]);

  if (!isOpen) return null;

  const handleTestVoice = () => {
    if (isPlayingSample) {
      stopSpeech();
      setIsPlayingSample(false);
      return;
    }

    setIsPlayingSample(true);
    const sampleText =
      "Olá! Sou a ComIA, assistente virtual da ComBR Soluções em Nuvem. Esta é uma demonstração da voz humanizada de leitura.";

    speakHumanized(sampleText, {
      voiceURI: selectedVoiceUri || undefined,
      rate: playbackRate,
      onStart: () => setIsPlayingSample(true),
      onEnd: () => setIsPlayingSample(false),
      onError: () => setIsPlayingSample(false),
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className="bg-[#202c33] border border-[#2a3942] rounded-2xl w-full max-w-md overflow-hidden shadow-2xl animate-in zoom-in-95 duration-150 flex flex-col max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 bg-[#111b21] border-b border-[#2a3942] flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-[#00a884]/20 border border-[#00a884]/30 text-[#00a884] flex items-center justify-center">
              <Headphones className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-[#e9edef] flex items-center gap-2">
                <span>Voz Humanizada & Acessibilidade</span>
              </h3>
              <p className="text-[11px] text-[#8696a0]">
                Leitor de tela e narração das respostas da ComIA
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-[#8696a0] hover:text-[#e9edef] rounded-full hover:bg-[#202c33] transition-colors"
            title="Fechar"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-4 space-y-4 overflow-y-auto flex-1">
          {/* Main Switch: Auto Read-Aloud */}
          <div
            onClick={onToggleTTS}
            className={`p-3.5 rounded-xl border transition-all cursor-pointer flex items-center justify-between gap-3 ${
              ttsEnabled
                ? "bg-[#00a884]/10 border-[#00a884]/40"
                : "bg-[#182229] border-[#2a3942] hover:border-[#374248]"
            }`}
          >
            <div className="flex items-start gap-3 min-w-0">
              <div
                className={`p-2 rounded-lg mt-0.5 shrink-0 ${
                  ttsEnabled
                    ? "bg-[#00a884] text-[#111b21]"
                    : "bg-[#202c33] text-[#8696a0]"
                }`}
              >
                {ttsEnabled ? (
                  <Volume2 className="w-5 h-5" />
                ) : (
                  <VolumeX className="w-5 h-5" />
                )}
              </div>
              <div>
                <div className="text-xs font-semibold text-[#e9edef] flex items-center gap-1.5">
                  <span>Leitura automática em voz alta</span>
                  {ttsEnabled ? (
                    <span className="text-[10px] bg-[#00a884]/20 text-[#00a884] border border-[#00a884]/40 px-1.5 py-0.2 rounded font-medium">
                      Ativada
                    </span>
                  ) : (
                    <span className="text-[10px] bg-[#2a3942] text-[#8696a0] px-1.5 py-0.2 rounded font-medium">
                      Desativada
                    </span>
                  )}
                </div>
                <p className="text-[11px] text-[#8696a0] mt-0.5 leading-snug">
                  {ttsEnabled
                    ? "A IA lerá automaticamente todas as respostas enviadas."
                    : "A IA responderá apenas por texto. Você ainda pode clicar em 'Ouvir' na mensagem quando quiser."}
                </p>
              </div>
            </div>

            {/* Custom Toggle Switch Pill */}
            <div
              className={`w-11 h-6 rounded-full transition-colors relative shrink-0 ${
                ttsEnabled ? "bg-[#00a884]" : "bg-[#2a3942]"
              }`}
            >
              <span
                className={`absolute top-0.5 left-0.5 w-5 h-5 rounded-full bg-white transition-transform ${
                  ttsEnabled ? "translate-x-5" : "translate-x-0"
                }`}
              />
            </div>
          </div>

          {/* Voice Selector Section */}
          <div className="space-y-2">
            <label className="text-xs font-semibold text-[#e9edef] flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-[#00a884]" />
                <span>Voz da ComIA</span>
              </span>
              <span className="text-[10px] text-[#8696a0]">
                {voices.length > 0 ? `${voices.length} vozes detectadas` : "Carregando vozes..."}
              </span>
            </label>

            {voices.length > 0 ? (
              <div className="space-y-1.5 max-h-44 overflow-y-auto pr-1">
                {voices.map((opt) => {
                  const isSelected =
                    (selectedVoiceUri && opt.voice.voiceURI === selectedVoiceUri) ||
                    (!selectedVoiceUri && opt === voices[0]);

                  return (
                    <button
                      key={opt.voice.voiceURI}
                      type="button"
                      onClick={() => onSelectVoiceUri(opt.voice.voiceURI)}
                      className={`w-full text-left p-2.5 rounded-xl border text-xs flex items-center justify-between gap-2 transition-all ${
                        isSelected
                          ? "bg-[#00a884]/15 border-[#00a884] text-[#e9edef]"
                          : "bg-[#182229] border-[#2a3942] text-[#d1d7db] hover:bg-[#202c33]"
                      }`}
                    >
                      <div className="truncate">
                        <div className="font-medium truncate flex items-center gap-1.5">
                          <span>{opt.displayName}</span>
                          {opt.isRecommended && (
                            <span className="text-[9px] bg-[#00a884]/20 text-[#00a884] border border-[#00a884]/40 px-1 py-0.2 rounded font-semibold uppercase">
                              Mais Natural
                            </span>
                          )}
                        </div>
                        <div className="text-[10px] text-[#8696a0] truncate">
                          {opt.voice.lang} • {opt.voice.name}
                        </div>
                      </div>
                      {isSelected && (
                        <div className="w-5 h-5 rounded-full bg-[#00a884] text-[#111b21] flex items-center justify-center shrink-0">
                          <Check className="w-3 h-3 stroke-[3]" />
                        </div>
                      )}
                    </button>
                  );
                })}
              </div>
            ) : (
              <div className="p-3 bg-[#182229] border border-[#2a3942] rounded-xl text-xs text-[#8696a0]">
                Detectando vozes do sistema operacional (Google, Microsoft ou Apple)...
              </div>
            )}
          </div>

          {/* Speed / Pace Selector */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs font-semibold text-[#e9edef]">
              <span className="flex items-center gap-1.5">
                <Sliders className="w-3.5 h-3.5 text-[#53bdeb]" />
                <span>Velocidade da Narração</span>
              </span>
              <span className="text-[11px] font-mono text-[#00a884]">
                {playbackRate === 0.9 ? "Suave (0.9x)" : playbackRate === 1.1 ? "Rápida (1.1x)" : "Natural (1.0x)"}
              </span>
            </div>

            <div className="grid grid-cols-3 gap-2">
              {[
                { label: "Calma", rate: 0.9, hint: "0.9x" },
                { label: "Natural", rate: 1.0, hint: "1.0x (Padrão)" },
                { label: "Rápida", rate: 1.15, hint: "1.15x" },
              ].map((item) => {
                const isActive = Math.abs(playbackRate - item.rate) < 0.05;
                return (
                  <button
                    key={item.label}
                    type="button"
                    onClick={() => onChangePlaybackRate(item.rate)}
                    className={`py-2 px-2 rounded-xl text-xs font-medium border text-center transition-all ${
                      isActive
                        ? "bg-[#53bdeb]/15 border-[#53bdeb] text-[#53bdeb]"
                        : "bg-[#182229] border-[#2a3942] text-[#8696a0] hover:text-[#e9edef] hover:bg-[#202c33]"
                    }`}
                  >
                    <div>{item.label}</div>
                    <div className="text-[10px] opacity-75">{item.hint}</div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Test Sample Voice Button */}
          <div className="pt-1">
            <button
              type="button"
              onClick={handleTestVoice}
              className={`w-full py-2.5 px-4 rounded-xl font-medium text-xs flex items-center justify-center gap-2 transition-all ${
                isPlayingSample
                  ? "bg-[#f15c6d] text-white hover:bg-[#d94a5a]"
                  : "bg-[#202c33] text-[#00a884] hover:bg-[#2a3942] border border-[#00a884]/30"
              }`}
            >
              {isPlayingSample ? (
                <>
                  <Square className="w-3.5 h-3.5 fill-current" />
                  <span>Parar Teste de Voz</span>
                </>
              ) : (
                <>
                  <Play className="w-3.5 h-3.5 fill-current ml-0.5" />
                  <span>Ouvir Demonstração da Voz</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Footer */}
        <div className="p-3 bg-[#111b21] border-t border-[#2a3942] flex items-center justify-between">
          <span className="text-[11px] text-[#8696a0]">
            Suporte para leitores de tela e acessibilidade auditiva
          </span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-[#00a884] hover:bg-[#02906f] text-[#111b21] text-xs font-bold transition-colors"
          >
            Concluído
          </button>
        </div>
      </div>
    </div>
  );
};
