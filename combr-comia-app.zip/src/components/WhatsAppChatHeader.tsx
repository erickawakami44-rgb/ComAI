import React, { useState } from "react";
import {
  ArrowLeft,
  Search,
  MoreVertical,
  Volume2,
  VolumeX,
  Info,
  CheckCircle2,
  ExternalLink,
  RotateCcw,
  ShieldCheck,
  Phone,
  Video,
  Headphones,
  Sliders,
  Download,
} from "lucide-react";
import { ComIALogo } from "./ComIALogo";
import { TriageType, WhatsAppClientChat } from "../types";

interface WhatsAppChatHeaderProps {
  activeClient?: WhatsAppClientChat;
  onBack?: () => void;
  showBackButton?: boolean;
  onToggleDrawer: () => void;
  onOpenTriage: (type: TriageType) => void;
  onResetChat: () => void;
  isLoading: boolean;
  ttsEnabled: boolean;
  onToggleTTS: () => void;
  onOpenVoiceModal?: () => void;
  onToggleSearch: () => void;
  isHumanMode?: boolean;
  assignedAgentName?: string;
  onSwitchView?: (view: "client" | "agent" | "split") => void;
}

export const WhatsAppChatHeader: React.FC<WhatsAppChatHeaderProps> = ({
  activeClient,
  onBack,
  showBackButton = false,
  onToggleDrawer,
  onOpenTriage,
  onResetChat,
  isLoading,
  ttsEnabled,
  onToggleTTS,
  onOpenVoiceModal,
  onToggleSearch,
  isHumanMode = false,
  assignedAgentName,
  onSwitchView,
}) => {
  const [menuOpen, setMenuOpen] = useState(false);

  const isOfficial = !activeClient || activeClient.id === "main";
  const clientName = activeClient?.name || "ComIA";
  const clientCompany = activeClient?.company || "ComBR Soluções em Nuvem";
  const clientPhone = activeClient?.phone || "+55 (14) 99895-1113";

  return (
    <div
      id="whatsapp-chat-header"
      className="h-16 px-3 sm:px-4 bg-[#202c33] border-b border-[#222e35] flex items-center justify-between z-20 shrink-0 select-none shadow-sm"
    >
      {/* Left side: Avatar + Contact Info */}
      <div className="flex items-center gap-2 sm:gap-3 min-w-0 cursor-pointer" onClick={onToggleDrawer}>
        {showBackButton && (
          <button
            id="btn-whatsapp-back"
            onClick={(e) => {
              e.stopPropagation();
              if (onBack) onBack();
            }}
            className="p-1.5 -ml-1 text-[#aebac1] hover:text-[#e9edef] rounded-full hover:bg-[#374248] transition-colors cursor-pointer"
            title="Voltar para a lista de conversas"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
        )}

        {/* Avatar with Status Ring */}
        <div className="relative shrink-0">
          {isOfficial ? (
            <ComIALogo size="md" showText={false} />
          ) : (
            <div
              className="w-10 h-10 rounded-full flex items-center justify-center text-white font-bold text-xs shadow-inner"
              style={{ backgroundColor: activeClient?.avatarColor || "#3b82f6" }}
            >
              {activeClient?.avatarInitials || clientName.slice(0, 2).toUpperCase()}
            </div>
          )}
          <span className="absolute bottom-0 right-0 w-3 h-3 bg-[#00a884] border-2 border-[#202c33] rounded-full"></span>
        </div>

        {/* Text Info */}
        <div className="min-w-0 flex flex-col justify-center">
          <div className="flex items-center gap-1.5">
            <h2 className="text-sm font-semibold text-[#e9edef] truncate">{clientName}</h2>
            {/* WhatsApp Verified Badge for official */}
            {isOfficial && (
              <span
                className="inline-flex items-center justify-center w-4 h-4 rounded-full bg-[#00a884] text-[#111b21]"
                title="Conta Comercial Oficial Verificada • ComBR Soluções em Nuvem"
              >
                <svg className="w-2.5 h-2.5 fill-current" viewBox="0 0 24 24">
                  <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z" />
                </svg>
              </span>
            )}
            <span className="hidden md:inline-block text-[11px] text-[#8696a0] font-normal truncate">
              • {clientCompany}
            </span>
          </div>

          <div className="flex items-center gap-1.5 text-xs">
            {isLoading ? (
              <span className="text-[#00a884] font-medium flex items-center gap-1 animate-pulse">
                <span>digitando</span>
                <span className="inline-flex gap-0.5">
                  <span className="w-1 h-1 bg-[#00a884] rounded-full animate-bounce"></span>
                  <span className="w-1 h-1 bg-[#00a884] rounded-full animate-bounce [animation-delay:0.2s]"></span>
                  <span className="w-1 h-1 bg-[#00a884] rounded-full animate-bounce [animation-delay:0.4s]"></span>
                </span>
              </span>
            ) : isHumanMode ? (
              <span className="text-[#00a884] font-medium text-[11px] flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-[#00a884] animate-pulse"></span>
                <span className="truncate">🧑‍💼 Atendimento Humano ({assignedAgentName || "Suporte N2"})</span>
              </span>
            ) : (
              <span className="text-[#8696a0] text-[11px] truncate">
                {isOfficial
                  ? "online • Suporte Oficial ComBR 24h"
                  : activeClient?.status === "online"
                  ? "online • " + clientPhone
                  : (activeClient?.lastSeen || "online recentemente") + " • " + clientPhone}
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Right side actions */}
      <div className="flex items-center gap-1 sm:gap-2 text-[#aebac1] relative">
        {/* TTS voice toggle & accessibility */}
        <div className="flex items-center gap-0.5 bg-[#202c33]/80 p-0.5 rounded-full border border-[#2a3942]">
          <button
            id="btn-toggle-tts"
            onClick={onToggleTTS}
            className={`px-2 py-1 rounded-full transition-all flex items-center gap-1 text-xs font-medium ${
              ttsEnabled
                ? "text-[#00a884] bg-[#00a884]/20 shadow-sm"
                : "text-[#8696a0] hover:text-[#e9edef] hover:bg-[#374248]"
            }`}
            title={
              ttsEnabled
                ? "Leitura por voz ativada (Acessibilidade) - Clique para desligar"
                : "Leitura por voz desativada (Acessibilidade) - Clique para ativar"
            }
          >
            {ttsEnabled ? (
              <>
                <Volume2 className="w-4 h-4 text-[#00a884] animate-pulse" />
                <span className="hidden md:inline text-[11px] text-[#00a884]">Voz ligada</span>
              </>
            ) : (
              <>
                <VolumeX className="w-4 h-4 text-[#8696a0]" />
                <span className="hidden md:inline text-[11px] text-[#8696a0]">Voz desligada</span>
              </>
            )}
          </button>

          {onOpenVoiceModal && (
            <button
              id="btn-voice-settings"
              onClick={onOpenVoiceModal}
              className="p-1 text-[#8696a0] hover:text-[#e9edef] rounded-full hover:bg-[#374248] transition-colors"
              title="Ajustar voz humanizada & velocidade"
            >
              <Sliders className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* Switch to Support Operator Panel */}
        {onSwitchView && (
          <button
            id="btn-switch-to-agent"
            onClick={() => onSwitchView("agent")}
            className="px-2.5 py-1.5 rounded-lg border border-[#2a3942] bg-[#182229] hover:bg-[#202c33] text-[#8696a0] hover:text-[#00a884] hover:border-[#00a884]/40 text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer"
            title="Ir para o Painel do Atendente (Suporte N2)"
          >
            <Headphones className="w-3.5 h-3.5 text-[#00a884]" />
            <span className="hidden sm:inline">Suporte N2</span>
          </button>
        )}

        {/* Search in chat */}
        <button
          id="btn-whatsapp-search-chat"
          onClick={onToggleSearch}
          className="p-2 rounded-full text-[#aebac1] hover:text-[#e9edef] hover:bg-[#374248] transition-colors"
          title="Pesquisar mensagens"
        >
          <Search className="w-5 h-5" />
        </button>

        {/* Drawer / Info button */}
        <button
          id="btn-toggle-info-drawer"
          onClick={onToggleDrawer}
          className="p-2 rounded-full text-[#aebac1] hover:text-[#e9edef] hover:bg-[#374248] transition-colors hidden sm:block"
          title="Parâmetros de E-mail & Informações do Contato"
        >
          <Info className="w-5 h-5" />
        </button>

        {/* More Options dropdown */}
        <div className="relative">
          <button
            id="btn-whatsapp-more-options"
            onClick={() => setMenuOpen(!menuOpen)}
            className="p-2 rounded-full text-[#aebac1] hover:text-[#e9edef] hover:bg-[#374248] transition-colors"
            title="Mais opções"
          >
            <MoreVertical className="w-5 h-5" />
          </button>

          {menuOpen && (
            <>
              <div
                className="fixed inset-0 z-30"
                onClick={() => setMenuOpen(false)}
              ></div>
              <div className="absolute right-0 top-11 w-56 bg-[#233138] border border-[#2a3942] rounded-xl shadow-2xl py-1.5 z-40 text-xs text-[#d1d7db] space-y-0.5">
                {onSwitchView && (
                  <button
                    onClick={() => {
                      setMenuOpen(false);
                      onSwitchView("agent");
                    }}
                    className="w-full px-4 py-2.5 text-left hover:bg-[#182229] flex items-center gap-2.5 transition-colors text-[#00a884] font-medium"
                  >
                    <Headphones className="w-4 h-4 text-[#00a884]" />
                    <span>Painel do Suporte N2</span>
                  </button>
                )}

                <button
                  onClick={() => {
                    setMenuOpen(false);
                    onToggleDrawer();
                  }}
                  className="w-full px-4 py-2.5 text-left hover:bg-[#182229] flex items-center gap-2.5 transition-colors"
                >
                  <Info className="w-4 h-4 text-[#00a884]" />
                  <span>Dados do Servidor & Guias</span>
                </button>

                <button
                  onClick={() => {
                    setMenuOpen(false);
                    onOpenVoiceModal?.();
                  }}
                  className="w-full px-4 py-2.5 text-left hover:bg-[#182229] flex items-center gap-2.5 transition-colors text-[#e9edef]"
                >
                  <Headphones className="w-4 h-4 text-[#00a884]" />
                  <div className="flex-1 flex items-center justify-between text-xs">
                    <span>Voz & Acessibilidade</span>
                    <span className="text-[10px] text-[#8696a0]">
                      {ttsEnabled ? "Ativada" : "Desativada"}
                    </span>
                  </div>
                </button>

                <a
                  href="https://webmail.combr.com.br"
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={() => setMenuOpen(false)}
                  className="w-full px-4 py-2.5 text-left hover:bg-[#182229] flex items-center gap-2.5 transition-colors text-[#e9edef]"
                >
                  <ExternalLink className="w-4 h-4 text-[#8696a0]" />
                  <span>Abrir Webmail ComBR</span>
                </a>

                <a
                  href="/combr-comia-app.zip"
                  download="combr-comia-app.zip"
                  onClick={() => setMenuOpen(false)}
                  className="w-full px-4 py-2.5 text-left hover:bg-[#182229] flex items-center gap-2.5 transition-colors text-amber-400 font-medium"
                >
                  <Download className="w-4 h-4 text-amber-400" />
                  <span>Baixar Projeto (.zip)</span>
                </a>

                <div className="border-t border-[#2a3942] my-1"></div>

                <button
                  onClick={() => {
                    setMenuOpen(false);
                    onResetChat();
                  }}
                  className="w-full px-4 py-2.5 text-left hover:bg-[#182229] flex items-center gap-2.5 text-[#f15c6d] transition-colors"
                >
                  <RotateCcw className="w-4 h-4" />
                  <span>Limpar conversa</span>
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
