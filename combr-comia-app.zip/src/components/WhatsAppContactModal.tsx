import React, { useState } from "react";
import { User, Phone, Building, Mail, X, Check, Search, Plus, UserCheck } from "lucide-react";
import { ContactCardData } from "../types";

interface WhatsAppContactModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectContact: (contact: ContactCardData) => void;
}

const PRESET_CONTACTS: ContactCardData[] = [
  {
    name: "Suporte Técnico (Geral, Projetos e Servidores)",
    phone: "+55 (14) 99895-1113",
    organization: "ComBr Soluções em Nuvem - Ramal 1",
    email: "suporte@combr.com.br",
  },
  {
    name: "Comercial (Novos Projetos e Propostas)",
    phone: "+55 (14) 98170-0888",
    organization: "ComBr Soluções em Nuvem - Ramal 2",
    email: "comercial@combr.com.br",
  },
  {
    name: "Financeiro (Boletos, Faturamento e NF)",
    phone: "+55 (14) 99851-1113",
    organization: "ComBr Soluções em Nuvem - Ramal 3",
    email: "financeiro@combr.com.br",
  },
  {
    name: "Central Telefônica Fixa ComBr",
    phone: "+55 (14) 3333-1150 / (14) 3432-4455",
    organization: "ComBr Soluções em Nuvem (Marília - SP)",
    email: "contato@combr.com.br",
  },
];

export const WhatsAppContactModal: React.FC<WhatsAppContactModalProps> = ({
  isOpen,
  onClose,
  onSelectContact,
}) => {
  const [tab, setTab] = useState<"preset" | "custom">("preset");
  const [search, setSearch] = useState("");
  const [customName, setCustomName] = useState("");
  const [customPhone, setCustomPhone] = useState("");
  const [customOrg, setCustomOrg] = useState("");
  const [customEmail, setCustomEmail] = useState("");

  if (!isOpen) return null;

  const filteredPresets = PRESET_CONTACTS.filter(
    (c) =>
      c.name.toLowerCase().includes(search.toLowerCase()) ||
      c.phone.includes(search) ||
      (c.organization && c.organization.toLowerCase().includes(search.toLowerCase()))
  );

  const handleSendCustom = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customName.trim() || !customPhone.trim()) return;

    onSelectContact({
      name: customName.trim(),
      phone: customPhone.trim(),
      organization: customOrg.trim() || undefined,
      email: customEmail.trim() || undefined,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs">
      <div className="bg-[#202c33] border border-[#2a3942] rounded-2xl w-full max-w-md overflow-hidden shadow-2xl flex flex-col max-h-[90vh] animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="bg-[#111b21] px-5 py-4 border-b border-[#2a3942] flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-full bg-[#007bfc]/20 text-[#007bfc] flex items-center justify-center">
              <UserCheck className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-[#e9edef]">Compartilhar Contato</h3>
              <p className="text-[11px] text-[#8696a0]">Envie um contato para a ComIA</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-[#8696a0] hover:text-[#e9edef] p-1.5 rounded-full hover:bg-[#202c33] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Selector */}
        <div className="flex border-b border-[#2a3942] bg-[#182229]">
          <button
            type="button"
            onClick={() => setTab("preset")}
            className={`flex-1 py-2.5 text-xs font-semibold text-center transition-colors border-b-2 ${
              tab === "preset"
                ? "border-[#00a884] text-[#00a884] bg-[#202c33]/50"
                : "border-transparent text-[#8696a0] hover:text-[#e9edef]"
            }`}
          >
            Contatos ComBR
          </button>
          <button
            type="button"
            onClick={() => setTab("custom")}
            className={`flex-1 py-2.5 text-xs font-semibold text-center transition-colors border-b-2 ${
              tab === "custom"
                ? "border-[#00a884] text-[#00a884] bg-[#202c33]/50"
                : "border-transparent text-[#8696a0] hover:text-[#e9edef]"
            }`}
          >
            Outro Contato
          </button>
        </div>

        {/* Tab Contents */}
        <div className="p-4 overflow-y-auto flex-1 space-y-3">
          {tab === "preset" ? (
            <>
              {/* Search */}
              <div className="relative">
                <Search className="w-4 h-4 text-[#8696a0] absolute left-3 top-2.5" />
                <input
                  type="text"
                  placeholder="Buscar contato da ComBR..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 bg-[#111b21] border border-[#2a3942] rounded-xl text-xs text-[#e9edef] placeholder-[#8696a0] focus:outline-none focus:border-[#00a884]"
                />
              </div>

              {/* List */}
              <div className="space-y-1.5 pt-1">
                {filteredPresets.map((contact, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => {
                      onSelectContact(contact);
                      onClose();
                    }}
                    className="w-full text-left p-3 rounded-xl bg-[#111b21] hover:bg-[#2a3942] border border-[#2a3942] transition-colors flex items-center justify-between group"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-[#00a884]/20 border border-[#00a884]/40 text-[#00a884] flex items-center justify-center font-bold text-sm shrink-0">
                        {contact.name.charAt(0)}
                      </div>
                      <div>
                        <div className="text-xs font-bold text-[#e9edef] group-hover:text-[#00a884] transition-colors">
                          {contact.name}
                        </div>
                        <div className="text-[11px] text-[#8696a0] flex items-center gap-1 mt-0.5">
                          <Phone className="w-3 h-3 text-[#00a884]" />
                          <span>{contact.phone}</span>
                        </div>
                        {contact.organization && (
                          <div className="text-[10px] text-[#8696a0] flex items-center gap-1">
                            <Building className="w-2.5 h-2.5" />
                            <span>{contact.organization}</span>
                          </div>
                        )}
                      </div>
                    </div>
                    <span className="text-[11px] font-medium text-[#00a884] px-2.5 py-1 bg-[#00a884]/15 rounded-lg group-hover:bg-[#00a884] group-hover:text-[#111b21] transition-colors">
                      Enviar
                    </span>
                  </button>
                ))}
              </div>
            </>
          ) : (
            <form onSubmit={handleSendCustom} className="space-y-3 pt-1">
              <div>
                <label className="block text-[11px] font-semibold text-[#8696a0] mb-1">
                  Nome do Contato *
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-[#8696a0] absolute left-3 top-2.5" />
                  <input
                    type="text"
                    required
                    placeholder="Ex: João Silva ou Suporte Local"
                    value={customName}
                    onChange={(e) => setCustomName(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 bg-[#111b21] border border-[#2a3942] rounded-xl text-xs text-[#e9edef] placeholder-[#8696a0] focus:outline-none focus:border-[#00a884]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-[#8696a0] mb-1">
                  Telefone / WhatsApp *
                </label>
                <div className="relative">
                  <Phone className="w-4 h-4 text-[#8696a0] absolute left-3 top-2.5" />
                  <input
                    type="tel"
                    required
                    placeholder="Ex: +55 (11) 99999-8888"
                    value={customPhone}
                    onChange={(e) => setCustomPhone(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 bg-[#111b21] border border-[#2a3942] rounded-xl text-xs text-[#e9edef] placeholder-[#8696a0] focus:outline-none focus:border-[#00a884]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-[#8696a0] mb-1">
                  Empresa / Departamento (Opcional)
                </label>
                <div className="relative">
                  <Building className="w-4 h-4 text-[#8696a0] absolute left-3 top-2.5" />
                  <input
                    type="text"
                    placeholder="Ex: TI da Minha Empresa Ltda"
                    value={customOrg}
                    onChange={(e) => setCustomOrg(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 bg-[#111b21] border border-[#2a3942] rounded-xl text-xs text-[#e9edef] placeholder-[#8696a0] focus:outline-none focus:border-[#00a884]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-[#8696a0] mb-1">
                  E-mail (Opcional)
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-[#8696a0] absolute left-3 top-2.5" />
                  <input
                    type="email"
                    placeholder="Ex: contato@minhaempresa.com.br"
                    value={customEmail}
                    onChange={(e) => setCustomEmail(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 bg-[#111b21] border border-[#2a3942] rounded-xl text-xs text-[#e9edef] placeholder-[#8696a0] focus:outline-none focus:border-[#00a884]"
                  />
                </div>
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 rounded-xl text-xs text-[#8696a0] hover:text-[#e9edef] hover:bg-[#111b21]"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={!customName.trim() || !customPhone.trim()}
                  className="px-5 py-2 bg-[#00a884] hover:bg-[#02906f] disabled:opacity-50 text-[#111b21] font-bold rounded-xl text-xs flex items-center gap-1.5 transition-colors shadow-md"
                >
                  <Check className="w-4 h-4" />
                  <span>Compartilhar Contato</span>
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
