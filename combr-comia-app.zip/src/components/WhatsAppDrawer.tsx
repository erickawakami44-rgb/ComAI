import React, { useState } from "react";
import {
  X,
  Server,
  Copy,
  Check,
  ExternalLink,
  ShieldCheck,
  Mail,
  Smartphone,
  Laptop,
  HelpCircle,
  Building2,
  Lock,
  Globe,
  Headphones,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
} from "lucide-react";
import { ComIALogo } from "./ComIALogo";
import { EmailServerConfig } from "../types";

interface WhatsAppDrawerProps {
  isOpen: boolean;
  onClose: () => void;
}

export const WhatsAppDrawer: React.FC<WhatsAppDrawerProps> = ({ isOpen, onClose }) => {
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [openGuide, setOpenGuide] = useState<string | null>("outlook");

  if (!isOpen) return null;

  const serverConfigs: EmailServerConfig[] = [
    {
      protocol: "IMAP (Recomendado)",
      host: "imap.combr.com.br",
      port: "993",
      security: "SSL / TLS",
      description: "Sincroniza todas as pastas e e-mails entre múltiplos dispositivos e Webmail em tempo real.",
    },
    {
      protocol: "SMTP (Envio)",
      host: "smtp.combr.com.br",
      port: "465 (SSL/TLS) ou 587 (STARTTLS)",
      security: "SSL/TLS com Autenticação",
      description: "Servidor de envio seguro. Obrigatório marcar 'Meu servidor requer autenticação' com seu e-mail e senha.",
    },
    {
      protocol: "POP3 (Local)",
      host: "pop.combr.com.br",
      port: "995",
      security: "SSL / TLS",
      description: "Baixa os e-mails para o computador local. Não recomendado se utiliza múltiplos aparelhos.",
    },
  ];

  const handleCopy = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const toggleGuide = (guide: string) => {
    setOpenGuide(openGuide === guide ? null : guide);
  };

  return (
    <div
      id="whatsapp-contact-drawer"
      className="fixed inset-y-0 right-0 z-50 w-full sm:w-[420px] bg-[#111b21] border-l border-[#222e35] shadow-2xl flex flex-col animate-slide-in select-none text-[#e9edef]"
    >
      {/* Drawer Header */}
      <div className="h-16 px-4 bg-[#202c33] border-b border-[#222e35] flex items-center justify-between shrink-0">
        <div className="flex items-center gap-3">
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-[#374248] text-[#aebac1] hover:text-[#e9edef] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
          <span className="font-semibold text-sm">Dados do Contato & Servidores</span>
        </div>
      </div>

      {/* Drawer Content */}
      <div className="flex-1 overflow-y-auto p-4 space-y-5">
        {/* Business Profile Card */}
        <div className="bg-[#202c33] rounded-2xl p-5 text-center border border-[#2a3942] space-y-3.5 shadow-md">
          <div className="flex flex-col items-center justify-center">
            <div className="relative">
              <ComIALogo size="xl" showText={false} />
            </div>
            <div className="flex items-baseline font-bold tracking-tight mt-3">
              <span className="text-xl text-white font-extrabold">Com</span>
              <span className="text-xl text-[#84cc16] font-extrabold">I</span>
              <span className="text-xl text-[#3b82f6] font-extrabold">A</span>
            </div>
          </div>
          <div>
            <div className="flex items-center justify-center gap-1.5">
              <h2 className="text-base font-bold text-[#e9edef]">ComBR Soluções em Nuvem</h2>
              <span
                className="w-4 h-4 rounded-full bg-[#00a884] text-[#111b21] flex items-center justify-center"
                title="Conta Comercial Oficial"
              >
                <svg className="w-2.5 h-2.5 fill-current" viewBox="0 0 24 24">
                  <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z" />
                </svg>
              </span>
            </div>
            <p className="text-xs text-[#00a884] font-medium">Provedor Oficial de Cloud & E-mail Corporativo</p>
            <p className="text-[11px] text-[#8696a0] mt-1">
              Atendimento automatizado N1 com inteligência artificial ComIA e escalonamento humano especializado.
            </p>
          </div>

          <div className="pt-2 border-t border-[#2a3942] flex items-center justify-center">
            <a
              href="https://combr.com.br"
              target="_blank"
              rel="noopener noreferrer"
              className="w-full py-2.5 px-4 bg-[#00a884] hover:bg-[#02906f] text-[#111b21] rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-colors"
            >
              <Globe className="w-4 h-4" />
              <span>Acessar Site Oficial ComBR</span>
            </a>
          </div>
        </div>

        {/* Official Server Parameters */}
        <div className="space-y-2.5">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold uppercase tracking-wider text-[#8696a0] flex items-center gap-1.5">
              <Server className="w-3.5 h-3.5 text-[#00a884]" />
              <span>Parâmetros Oficiais de Conexão</span>
            </h3>
            <button
              onClick={() =>
                handleCopy(
                  `IMAP: imap.combr.com.br | Porta: 993 (SSL/TLS)\nSMTP: smtp.combr.com.br | Porta: 465 ou 587 (SSL/TLS)\nPOP3: pop.combr.com.br | Porta: 995 (SSL/TLS)\nWebmail: https://webmail.combr.com.br`,
                  "all-params"
                )
              }
              className="text-[11px] text-[#00a884] hover:underline flex items-center gap-1"
            >
              {copiedKey === "all-params" ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
              <span>{copiedKey === "all-params" ? "Copiado!" : "Copiar Tudo"}</span>
            </button>
          </div>

          {serverConfigs.map((cfg, idx) => (
            <div
              key={idx}
              className="bg-[#202c33] border border-[#2a3942] rounded-xl p-3 text-xs space-y-2 hover:border-[#00a884]/40 transition-colors"
            >
              <div className="flex items-center justify-between">
                <span className="font-bold text-[#00a884]">{cfg.protocol}</span>
                <button
                  onClick={() => handleCopy(`${cfg.host}:${cfg.port}`, `param-${idx}`)}
                  className="p-1 rounded hover:bg-[#2a3942] text-[#8696a0] hover:text-[#e9edef] transition-colors"
                  title="Copiar host e porta"
                >
                  {copiedKey === `param-${idx}` ? (
                    <Check className="w-3.5 h-3.5 text-[#00a884]" />
                  ) : (
                    <Copy className="w-3.5 h-3.5" />
                  )}
                </button>
              </div>

              <div className="grid grid-cols-2 gap-2 text-[11px] bg-[#111b21] p-2 rounded-lg font-mono">
                <div>
                  <span className="text-[#8696a0] block text-[10px]">Servidor (Host):</span>
                  <span className="text-[#e9edef] font-semibold">{cfg.host}</span>
                </div>
                <div>
                  <span className="text-[#8696a0] block text-[10px]">Porta & Segurança:</span>
                  <span className="text-[#53bdeb] font-semibold">
                    {cfg.port} ({cfg.security})
                  </span>
                </div>
              </div>

              <p className="text-[11px] text-[#8696a0] leading-tight">{cfg.description}</p>
            </div>
          ))}
        </div>

        {/* Quick Email Client Setup Guides Accordion */}
        <div className="space-y-2">
          <h3 className="text-xs font-bold uppercase tracking-wider text-[#8696a0] flex items-center gap-1.5">
            <Laptop className="w-3.5 h-3.5 text-[#00a884]" />
            <span>Passo a Passo de Configuração</span>
          </h3>

          {/* Outlook Guide */}
          <div className="bg-[#202c33] border border-[#2a3942] rounded-xl overflow-hidden text-xs">
            <button
              onClick={() => toggleGuide("outlook")}
              className="w-full p-3 text-left font-semibold flex items-center justify-between hover:bg-[#2a3942] transition-colors"
            >
              <div className="flex items-center gap-2">
                <span>📧</span>
                <span>Microsoft Outlook (Windows / Mac)</span>
              </div>
              {openGuide === "outlook" ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            </button>

            {openGuide === "outlook" && (
              <div className="p-3 bg-[#111b21] border-t border-[#2a3942] text-[11px] text-[#d1d7db] space-y-1.5">
                <p>1. Abra o Outlook e vá em <strong>Arquivo &gt; Adicionar Conta</strong>.</p>
                <p>2. Digite seu e-mail completo, marque <em>"Configurar minha conta manualmente"</em> e escolha <strong>IMAP</strong>.</p>
                <p>3. Servidor de Entrada: <code className="text-[#53bdeb]">imap.combr.com.br</code> | Porta <code className="text-[#53bdeb]">993</code> | SSL/TLS.</p>
                <p>4. Servidor de Saída: <code className="text-[#53bdeb]">smtp.combr.com.br</code> | Porta <code className="text-[#53bdeb]">465</code> | SSL/TLS.</p>
                <p>5. Marque a opção <em>"Meu servidor de saída (SMTP) requer autenticação"</em> e utilize sua senha.</p>
              </div>
            )}
          </div>

          {/* Smartphone iOS / Android Guide */}
          <div className="bg-[#202c33] border border-[#2a3942] rounded-xl overflow-hidden text-xs">
            <button
              onClick={() => toggleGuide("mobile")}
              className="w-full p-3 text-left font-semibold flex items-center justify-between hover:bg-[#2a3942] transition-colors"
            >
              <div className="flex items-center gap-2">
                <Smartphone className="w-4 h-4 text-[#00a884]" />
                <span>iPhone (iOS) & Android (Gmail / Mail)</span>
              </div>
              {openGuide === "mobile" ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            </button>

            {openGuide === "mobile" && (
              <div className="p-3 bg-[#111b21] border-t border-[#2a3942] text-[11px] text-[#d1d7db] space-y-1.5">
                <p>1. Acesse <strong>Ajustes &gt; Mail &gt; Contas &gt; Adicionar Conta &gt; Outra</strong>.</p>
                <p>2. Nome de Usuário (Entrada e Saída): <strong>seu e-mail corporativo completo</strong>.</p>
                <p>3. Host de Entrada: <code className="text-[#53bdeb]">imap.combr.com.br</code> (Porta 993 com SSL).</p>
                <p>4. Host de Saída: <code className="text-[#53bdeb]">smtp.combr.com.br</code> (Porta 465 ou 587 com SSL).</p>
              </div>
            )}
          </div>

          {/* Thunderbird Guide */}
          <div className="bg-[#202c33] border border-[#2a3942] rounded-xl overflow-hidden text-xs">
            <button
              onClick={() => toggleGuide("thunderbird")}
              className="w-full p-3 text-left font-semibold flex items-center justify-between hover:bg-[#2a3942] transition-colors"
            >
              <div className="flex items-center gap-2">
                <span>🦅</span>
                <span>Mozilla Thunderbird</span>
              </div>
              {openGuide === "thunderbird" ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            </button>

            {openGuide === "thunderbird" && (
              <div className="p-3 bg-[#111b21] border-t border-[#2a3942] text-[11px] text-[#d1d7db] space-y-1.5">
                <p>1. Vá em <strong>Configurações da Conta &gt; Ações de Conta &gt; Nova Conta de E-mail</strong>.</p>
                <p>2. Preencha nome, e-mail e senha. Clique em <em>Configuração Manual</em>.</p>
                <p>3. IMAP: <code className="text-[#53bdeb]">imap.combr.com.br</code> | Porta 993 | SSL/TLS | Senha normal.</p>
                <p>4. SMTP: <code className="text-[#53bdeb]">smtp.combr.com.br</code> | Porta 465 | SSL/TLS | Senha normal.</p>
              </div>
            )}
          </div>
        </div>

        {/* ComBR Infrastructure & Portfolio Overview */}
        <div className="space-y-2">
          <h3 className="text-xs font-bold uppercase tracking-wider text-[#8696a0] flex items-center gap-1.5">
            <Building2 className="w-3.5 h-3.5 text-[#00a884]" />
            <span>Catálogo Oficial de Soluções ComBR</span>
          </h3>

          <div className="grid grid-cols-1 gap-2 text-xs">
            {/* Cloud & Hosting */}
            <div className="bg-[#202c33] border border-[#2a3942] rounded-xl p-3 space-y-1.5 hover:border-[#00a884]/40 transition-colors">
              <div className="flex items-center gap-2 font-semibold text-[#e9edef]">
                <Globe className="w-4 h-4 text-[#53bdeb]" />
                <span>Infraestrutura, Hospedagem & Cloud</span>
              </div>
              <p className="text-[11px] text-[#8696a0] leading-relaxed">
                Hospedagem Corporativa e WordPress otimizada, <strong>VPS Linux Gerenciada</strong>, Cloud AWS Empresarial e <strong>Oracle Cloud (OCI)</strong> com previsibilidade de custos em BRL.
              </p>
            </div>

            {/* Communication & Hybrid Email */}
            <div className="bg-[#202c33] border border-[#2a3942] rounded-xl p-3 space-y-1.5 hover:border-[#00a884]/40 transition-colors">
              <div className="flex items-center gap-2 font-semibold text-[#e9edef]">
                <Server className="w-4 h-4 text-[#00a884]" />
                <span>Comunicação & Presença Digital</span>
              </div>
              <p className="text-[11px] text-[#8696a0] leading-relaxed">
                E-mail Corporativo (AWS e Oracle), <strong>E-mail Híbrido</strong> (ComBr + Microsoft 365 ou Google Workspace), <strong>SMTP Envio Empresarial</strong> (transacional/NF-e), Domínios e Sites <strong>OnepagePro</strong>.
              </p>
            </div>

            {/* Backup & Security */}
            <div className="bg-[#202c33] border border-[#2a3942] rounded-xl p-3 space-y-1.5 hover:border-[#00a884]/40 transition-colors">
              <div className="flex items-center gap-2 font-semibold text-[#e9edef]">
                <ShieldCheck className="w-4 h-4 text-[#00e5ff]" />
                <span>Backup, Segurança & Armazenamento</span>
              </div>
              <p className="text-[11px] text-[#8696a0] leading-relaxed">
                <strong>SaveData</strong> (backup em nuvem contra ransomware), <strong>SaveMail</strong> (backup contínuo de caixas) e <strong>FTP Empresarial</strong> seguro.
              </p>
            </div>

            {/* Management & Databases */}
            <div className="bg-[#202c33] border border-[#2a3942] rounded-xl p-3 space-y-1.5 hover:border-[#00a884]/40 transition-colors">
              <div className="flex items-center gap-2 font-semibold text-[#e9edef]">
                <Server className="w-4 h-4 text-[#ffd279]" />
                <span>Gestão & Consultoria Especializada</span>
              </div>
              <p className="text-[11px] text-[#8696a0] leading-relaxed">
                Monitoramento 24x7 Linux, Consultoria em Nuvem (AWS/OCI) e Gestão de Bancos de Dados <strong>Oracle</strong> e <strong>MySQL</strong>.
              </p>
            </div>
          </div>
        </div>

        {/* Direct Contacts & Security */}
        <div className="bg-[#202c33] border border-[#2a3942] rounded-xl p-3 text-xs space-y-2">
          <div className="flex items-center gap-2 text-[#00a884] font-semibold">
            <ShieldCheck className="w-4 h-4" />
            <span>Garantia de Segurança ComBR</span>
          </div>
          <p className="text-[11px] text-[#8696a0]">
            Todos os servidores da ComBR contam com proteção contra ataques de força bruta (*password spraying*), controle de taxa de envios por hora e criptografia SSL/TLS em todas as portas de serviço.
          </p>
        </div>
      </div>
    </div>
  );
};
