import React, { useState, useMemo } from "react";
import { Smile, Sparkles, Briefcase, ThumbsUp, Cloud, Search, X } from "lucide-react";

interface WhatsAppEmojiPickerProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectEmoji: (emoji: string) => void;
}

interface EmojiCategory {
  id: string;
  name: string;
  icon: React.ReactNode;
  emojis: { char: string; keywords: string }[];
}

const EMOJI_CATEGORIES: EmojiCategory[] = [
  {
    id: "smileys",
    name: "Expressões",
    icon: <Smile className="w-3.5 h-3.5" />,
    emojis: [
      { char: "😀", keywords: "sorriso feliz alegre" },
      { char: "😃", keywords: "sorriso feliz aberto" },
      { char: "😄", keywords: "risada feliz contente" },
      { char: "😁", keywords: "dentes sorriso feliz" },
      { char: "😆", keywords: "gargalhada rindo" },
      { char: "😅", keywords: "suor alívio nervoso" },
      { char: "😂", keywords: "chorando de rir risada" },
      { char: "🤣", keywords: "rolando de rir gargalhada" },
      { char: "😊", keywords: "tímido feliz bochechas" },
      { char: "😇", keywords: "anjo santo inocente" },
      { char: "🙂", keywords: "sorriso leve ok" },
      { char: "😉", keywords: "piscada piscando" },
      { char: "😌", keywords: "aliviado calmo paz" },
      { char: "😍", keywords: "amor apaixonado coracao" },
      { char: "🥰", keywords: "amor carinho afeto" },
      { char: "😘", keywords: "beijo carinho amor" },
      { char: "😋", keywords: "gostoso sabor lingua" },
      { char: "😜", keywords: "brincadeira piscando lingua" },
      { char: "🤪", keywords: "louco doido zoeira" },
      { char: "😎", keywords: "oculos sol estilo legal cool" },
      { char: "🤩", keywords: "estrelas impressionado uau" },
      { char: "🥳", keywords: "festa comemoracao parabens" },
      { char: "😏", keywords: "malicioso confiante" },
      { char: "🧐", keywords: "monoculo analisando investigando" },
      { char: "🤓", keywords: "nerd oculos inteligente" },
      { char: "🤔", keywords: "pensando duvida reflexao" },
      { char: "🫡", keywords: "continencia respeito entendido sim" },
      { char: "🤫", keywords: "segredo silencio psiu" },
      { char: "🤐", keywords: "boca fechada calado segredo" },
      { char: "🤨", keywords: "sobrancelha desconfiado suspeito" },
      { char: "😐", keywords: "neutro sem expressao" },
      { char: "😑", keywords: "inexpressivo cansado" },
      { char: "😶", keywords: "sem boca mudo" },
      { char: "🙄", keywords: "olhos para cima desdem aff" },
      { char: "😬", keywords: "careta constrangido tenso" },
      { char: "😮‍💨", keywords: "suspiro alívio cansaço" },
      { char: "🤥", keywords: "mentiroso pinocchio nariz" },
      { char: "😴", keywords: "dormindo sono zzz" },
      { char: "🥱", keywords: "bocejo sono tedio" },
      { char: "😷", keywords: "mascara doente protegido" },
      { char: "🤒", keywords: "termometro febre doente" },
      { char: "🤕", keywords: "curativo ferido machucado" },
      { char: "🤢", keywords: "enjoado nauseas verde" },
      { char: "🤮", keywords: "vomito passando mal" },
      { char: "🥵", keywords: "quente calor suando vermelho" },
      { char: "🥶", keywords: "frio gelado congelando azul" },
      { char: "🤯", keywords: "cabeca explodindo surpreso choque" },
      { char: "😱", keywords: "grito susto medo pavor" },
      { char: "😨", keywords: "assustado medo receio" },
      { char: "😰", keywords: "ansioso preocupado suor" },
      { char: "😥", keywords: "triste suor aliviado" },
      { char: "😢", keywords: "chorando lagrima triste" },
      { char: "😭", keywords: "choro desespero triste" },
      { char: "🥺", keywords: "pidão por favor implorando" },
      { char: "😤", keywords: "triunfo fumaca determinado" },
      { char: "😠", keywords: "bravo irritado raiva" },
      { char: "😡", keywords: "furioso raiva vermelho" },
      { char: "🤬", keywords: "palavrao xingamento raiva" },
    ],
  },
  {
    id: "gestures",
    name: "Gestos",
    icon: <ThumbsUp className="w-3.5 h-3.5" />,
    emojis: [
      { char: "👍", keywords: "joia positivo ok curtir aprovado" },
      { char: "👎", keywords: "negativo ruim descurtir desaprovado" },
      { char: "👌", keywords: "ok perfeito certinho" },
      { char: "✌️", keywords: "paz e amor vitoria dois" },
      { char: "🤞", keywords: "dedos cruzados sorte torcida" },
      { char: "🤟", keywords: "te amo rock gesto" },
      { char: "🤘", keywords: "rock metal chifre" },
      { char: "🤙", keywords: "shaka liga nois tranquilo" },
      { char: "👈", keywords: "apontando esquerda veja aqui" },
      { char: "👉", keywords: "apontando direita veja aqui" },
      { char: "👆", keywords: "apontando cima acima veja" },
      { char: "👇", keywords: "apontando baixo abaixo veja" },
      { char: "☝️", keywords: "atencao primeiro um momento" },
      { char: "✋", keywords: "pare alto mao aberta" },
      { char: "🖐️", keywords: "cinco mao espalmada" },
      { char: "👋", keywords: "tchau oie aceno saudacao" },
      { char: "👏", keywords: "palmas parabens aplausos" },
      { char: "🙌", keywords: "maos para o alto comemoracao viva" },
      { char: "👐", keywords: "aberto maos abertas" },
      { char: "🤲", keywords: "oracao suplica receber" },
      { char: "🤝", keywords: "aperto de mao acordo parceria fechado" },
      { char: "🙏", keywords: "por favor obrigado oracao amem gratidao" },
      { char: "✍️", keywords: "escrevendo assinatura caneta" },
      { char: "💪", keywords: "forca musculo firme foco" },
      { char: "👀", keywords: "olhos olhando atento espiando" },
      { char: "❤️", keywords: "coracao amor vermelho love" },
      { char: "💙", keywords: "coracao azul confianca" },
      { char: "💚", keywords: "coracao verde whatsapp combr" },
      { char: "🔥", keywords: "fogo quente chama sucesso urgente" },
      { char: "💯", keywords: "cem perfeito nota cem aprovado" },
    ],
  },
  {
    id: "business",
    name: "TI & Trabalho",
    icon: <Briefcase className="w-3.5 h-3.5" />,
    emojis: [
      { char: "💼", keywords: "maleta trabalho empresa negocio comercial" },
      { char: "💻", keywords: "computador notebook pc laptop suporte" },
      { char: "🖥️", keywords: "desktop tela monitor servidor" },
      { char: "🖨️", keywords: "impressora impressao relatorio papel" },
      { char: "⌨️", keywords: "teclado digitacao comando" },
      { char: "🖱️", keywords: "mouse clique ponteiro" },
      { char: "💾", keywords: "disquete salvar disquete backup" },
      { char: "💿", keywords: "disco cd dvd instalacao" },
      { char: "📱", keywords: "celular smartphone whatsapp mobile" },
      { char: "☎️", keywords: "telefone fixo ligacao ramal" },
      { char: "📞", keywords: "fone chamada contato atendimento" },
      { char: "📧", keywords: "email e-mail correio mensagem outlook" },
      { char: "📩", keywords: "envelope recebido mensagem carta" },
      { char: "📤", keywords: "enviando caixa de saida upload" },
      { char: "📥", keywords: "recebido caixa de entrada download" },
      { char: "📦", keywords: "pacote entrega caixa encomenda" },
      { char: "🏷️", keywords: "etiqueta tag preco valor" },
      { char: "📑", keywords: "documento abas relatorio contrato" },
      { char: "📄", keywords: "folha pagina arquivo texto" },
      { char: "📊", keywords: "grafico barras relatorio estatistica" },
      { char: "📈", keywords: "grafico subindo crescimento alta" },
      { char: "📉", keywords: "grafico descendo queda baixa" },
      { char: "📋", keywords: "prancheta lista checklist tarefas" },
      { char: "📁", keywords: "pasta diretorio arquivos" },
      { char: "📂", keywords: "pasta aberta arquivos" },
      { char: "📎", keywords: "clipe anexo anexar documento" },
      { char: "🖇️", keywords: "clipes anexos documentos" },
      { char: "📏", keywords: "regua medicao tamanho" },
      { char: "📌", keywords: "alfinete fixar marcado destaque" },
      { char: "📍", keywords: "localizacao pin mapa endereco" },
      { char: "🛠️", keywords: "ferramentas suporte manutencao ajuste conserto" },
      { char: "🔧", keywords: "chave inglesa ajuste suporte conserto n2" },
      { char: "🔨", keywords: "martelo construcao manutencao" },
      { char: "⚙️", keywords: "engrenagem configuracao ajustes parametros" },
      { char: "💳", keywords: "cartao credito debito fatura boleto financeiro" },
      { char: "💰", keywords: "saco de dinheiro grana financeiro pagamento" },
      { char: "💵", keywords: "nota dinheiro dolar real pagamento" },
      { char: "🧾", keywords: "recibo nota fiscal comprovante nf-e" },
    ],
  },
  {
    id: "tech_symbols",
    name: "Nuvem & Símbolos",
    icon: <Cloud className="w-3.5 h-3.5" />,
    emojis: [
      { char: "☁️", keywords: "nuvem cloud combr vps aws oci" },
      { char: "🌐", keywords: "globo internet web webmail rede dns" },
      { char: "🔒", keywords: "cadeado seguro seguranca ssl tls senha" },
      { char: "🔓", keywords: "cadeado aberto desbloqueado livre" },
      { char: "🔏", keywords: "cadeado caneta criptografia privacidade" },
      { char: "🔐", keywords: "chave cadeado senha acesso credenciais" },
      { char: "🔑", keywords: "chave token senha acesso login" },
      { char: "🗝️", keywords: "chave antiga acesso master" },
      { char: "🛡️", keywords: "escudo protecao firewall antivirus savedata" },
      { char: "🚀", keywords: "foguete velocidade rapido lancamento vps" },
      { char: "⭐", keywords: "estrela favorito qualidade destaque" },
      { char: "✨", keywords: "brilho novidade ia comia inteligencia" },
      { char: "⚡", keywords: "raio energia rapido instantaneo" },
      { char: "💡", keywords: "lampada ideia solucao dica" },
      { char: "🔔", keywords: "sino notificacao alerta aviso" },
      { char: "🔕", keywords: "sem som silencioso mudo" },
      { char: "✅", keywords: "check concluido confirmado ok certo sim" },
      { char: "❌", keywords: "x erro cancelado nao errado reprovado" },
      { char: "⚠️", keywords: "alerta atencao aviso cuidado perigo" },
      { char: "❓", keywords: "duvida interrogacao pergunta como" },
      { char: "❗", keywords: "exclamacao importante urgente atencao" },
      { char: "💬", keywords: "balao conversa chat mensagem comia" },
      { char: "🔄", keywords: "atualizar sincronizar reiniciar loop" },
      { char: "🛑", keywords: "pare stop bloqueio interromper" },
      { char: "🟢", keywords: "circulo verde online ativo funcionando" },
      { char: "🔴", keywords: "circulo vermelho offline inativo erro" },
      { char: "🟡", keywords: "circulo amarelo pendente atencao aguardando" },
      { char: "🟦", keywords: "quadrado azul estavel combr" },
    ],
  },
];

export const WhatsAppEmojiPicker: React.FC<WhatsAppEmojiPickerProps> = ({
  isOpen,
  onClose,
  onSelectEmoji,
}) => {
  const [activeTab, setActiveTab] = useState<string>("smileys");
  const [search, setSearch] = useState<string>("");

  const searchResults = useMemo(() => {
    if (!search.trim()) return null;
    const term = search.toLowerCase().trim();
    const matches: { char: string; keywords: string }[] = [];
    EMOJI_CATEGORIES.forEach((cat) => {
      cat.emojis.forEach((item) => {
        if (item.keywords.includes(term) || item.char === term) {
          matches.push(item);
        }
      });
    });
    return matches;
  }, [search]);

  if (!isOpen) return null;

  const currentCategory = EMOJI_CATEGORIES.find((c) => c.id === activeTab) || EMOJI_CATEGORIES[0];

  return (
    <>
      {/* Click outside backdrop */}
      <div className="fixed inset-0 z-40" onClick={onClose} />

      {/* Emoji Picker Popover */}
      <div
        id="whatsapp-emoji-picker-container"
        className="absolute bottom-16 left-2 sm:left-4 bg-[#202c33] border border-[#2a3942] rounded-2xl shadow-2xl z-50 w-[300px] sm:w-[350px] overflow-hidden flex flex-col h-[320px] animate-in fade-in slide-in-from-bottom-2 duration-150 select-none"
      >
        {/* Search Bar & Header */}
        <div className="p-2.5 bg-[#111b21] border-b border-[#2a3942] flex items-center gap-2 shrink-0">
          <div className="relative flex-1">
            <Search className="w-3.5 h-3.5 text-[#8696a0] absolute left-2.5 top-2.5" />
            <input
              type="text"
              placeholder="Pesquisar emoji (ex: joinha, nuvem, ok)..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-8 pr-7 py-1.5 bg-[#202c33] border border-[#2a3942] rounded-xl text-xs text-[#e9edef] placeholder-[#8696a0] focus:outline-none focus:border-[#00a884]"
              autoFocus
            />
            {search && (
              <button
                onClick={() => setSearch("")}
                className="absolute right-2.5 top-2.5 text-[#8696a0] hover:text-[#e9edef]"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
          <button
            onClick={onClose}
            className="text-[#8696a0] hover:text-[#e9edef] p-1 rounded-lg hover:bg-[#202c33] transition-colors"
            title="Fechar"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Categories Bar (hidden when searching) */}
        {!search && (
          <div className="flex border-b border-[#2a3942] bg-[#182229] px-2 shrink-0">
            {EMOJI_CATEGORIES.map((cat) => (
              <button
                key={cat.id}
                type="button"
                onClick={() => setActiveTab(cat.id)}
                className={`flex-1 py-2 flex items-center justify-center gap-1 text-[11px] font-medium border-b-2 transition-colors ${
                  activeTab === cat.id
                    ? "border-[#00a884] text-[#00a884] bg-[#202c33]/40"
                    : "border-transparent text-[#8696a0] hover:text-[#e9edef]"
                }`}
                title={cat.name}
              >
                {cat.icon}
                <span className="hidden sm:inline text-[10px]">{cat.name}</span>
              </button>
            ))}
          </div>
        )}

        {/* Emojis Grid Container */}
        <div className="flex-1 overflow-y-auto p-2.5 scrollbar-thin">
          {search ? (
            <div>
              <div className="text-[10px] text-[#8696a0] font-semibold mb-2 px-1">
                Resultados para "{search}" ({searchResults?.length || 0})
              </div>
              {searchResults && searchResults.length > 0 ? (
                <div className="grid grid-cols-7 sm:grid-cols-8 gap-1">
                  {searchResults.map((item, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => onSelectEmoji(item.char)}
                      className="w-9 h-9 rounded-lg hover:bg-[#2a3942] flex items-center justify-center text-xl transition-all hover:scale-125 active:scale-95"
                    >
                      {item.char}
                    </button>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-xs text-[#8696a0]">
                  Nenhum emoji encontrado para "{search}"
                </div>
              )}
            </div>
          ) : (
            <div>
              <div className="text-[10px] text-[#8696a0] font-bold uppercase tracking-wider mb-2 px-1">
                {currentCategory.name}
              </div>
              <div className="grid grid-cols-7 sm:grid-cols-8 gap-1">
                {currentCategory.emojis.map((item, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => onSelectEmoji(item.char)}
                    className="w-9 h-9 rounded-lg hover:bg-[#2a3942] flex items-center justify-center text-xl transition-all hover:scale-125 active:scale-95"
                  >
                    {item.char}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Bottom Hint */}
        <div className="px-3 py-1.5 bg-[#111b21] border-t border-[#2a3942] text-[10px] text-[#8696a0] flex items-center justify-between shrink-0">
          <span>Clique para inserir no texto</span>
          <span className="text-[#00a884] font-medium">WhatsApp Emojis</span>
        </div>
      </div>
    </>
  );
};
