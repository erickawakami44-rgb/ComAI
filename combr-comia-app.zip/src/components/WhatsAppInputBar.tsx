import React, { useState, useRef, useEffect } from "react";
import {
  Smile,
  Paperclip,
  Mic,
  Send,
  Sparkles,
  Trash2,
  X,
  Check,
  FileText,
  Image as ImageIcon,
  UserCheck,
  Volume2,
} from "lucide-react";
import {
  ContactCardData,
  DocumentAttachmentData,
  ImageAttachmentData,
  TriageType,
} from "../types";
import { WhatsAppEmojiPicker } from "./WhatsAppEmojiPicker";
import { WhatsAppContactModal } from "./WhatsAppContactModal";
import { getCurrentPeriodGreeting } from "../lib/greetingUtils";

interface WhatsAppInputBarProps {
  onSendMessage: (
    content: string,
    isAudio?: boolean,
    audioDuration?: string,
    mediaData?: {
      audioUrl?: string;
      audioBase64?: string;
      mimeType?: string;
      transcript?: string;
      imageAttachment?: ImageAttachmentData;
      documentAttachment?: DocumentAttachmentData;
      contactAttachment?: ContactCardData;
    }
  ) => void;
  loading: boolean;
  onOpenTriage: (type: TriageType) => void;
  onOpenDrawer: () => void;
}

export const WhatsAppInputBar: React.FC<WhatsAppInputBarProps> = ({
  onSendMessage,
  loading,
  onOpenTriage,
  onOpenDrawer,
}) => {
  const [text, setText] = useState("");
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [showAttachMenu, setShowAttachMenu] = useState(false);
  const [isContactModalOpen, setIsContactModalOpen] = useState(false);

  // Pending attachment preview state
  const [pendingImage, setPendingImage] = useState<ImageAttachmentData | null>(null);
  const [pendingDoc, setPendingDoc] = useState<DocumentAttachmentData | null>(null);

  // Voice recording state
  const [isRecording, setIsRecording] = useState(false);
  const [recordingSeconds, setRecordingSeconds] = useState(0);
  const [speechTranscript, setSpeechTranscript] = useState("");
  const speechTranscriptRef = useRef("");
  const speechRecognitionRef = useRef<any>(null);
  const [audioVolumeBars, setAudioVolumeBars] = useState<number[]>([
    20, 45, 60, 30, 80, 50, 70, 90, 40, 65,
  ]);

  const inputRef = useRef<HTMLTextAreaElement | null>(null);
  const imageInputRef = useRef<HTMLInputElement | null>(null);
  const docInputRef = useRef<HTMLInputElement | null>(null);

  // Audio recording refs
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const audioStreamRef = useRef<MediaStream | null>(null);
  const timerIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const animFrameRef = useRef<number | null>(null);

  // Dynamic time greeting (Bom dia, Boa tarde ou Boa noite)
  const [currentGreeting, setCurrentGreeting] = useState(getCurrentPeriodGreeting());

  useEffect(() => {
    setCurrentGreeting(getCurrentPeriodGreeting());
    const interval = setInterval(() => {
      setCurrentGreeting(getCurrentPeriodGreeting());
    }, 30000);
    return () => clearInterval(interval);
  }, []);

  // Quick chips
  const quickChips: Array<{ label: string; query: string; triage?: TriageType }> = [
    { label: "💼 Comercial", query: "Gostaria de informações e propostas sobre os planos comerciais.", triage: "commercial" },
    { label: "🛠️ Suporte Técnico N2", query: "Preciso de suporte técnico nível 2 para e-mail corporativo ou servidor.", triage: "support_n2" },
    { label: "💳 Financeiro", query: "Gostaria de atendimento com o departamento Financeiro.", triage: "financial" },
    { label: "🧑‍💼 Falar com Atendente", query: "Gostaria de falar com um atendente humano do suporte especializado." },
    { label: `👋 ${currentGreeting.greeting}!`, query: `${currentGreeting.greeting}, tudo bem?` },
    { label: "Catálogo de Serviços", query: "Quais são os serviços e soluções que a ComBr oferece?" },
    { label: "Portas IMAP & SMTP", query: "Quais são as portas e servidores oficiais de IMAP e SMTP da ComBr?" },
    { label: "Cloud & VPS Gerenciada", query: "Como funciona a VPS Linux Gerenciada, Cloud AWS e OCI da ComBr?" },
    { label: "E-mail Híbrido & SMTP", query: "Como funciona o E-mail Híbrido e o SMTP Envio Empresarial para NF-e?" },
    { label: "SaveData & SaveMail", query: "Como funciona o SaveData contra ransomware e o SaveMail da ComBr?" },
    { label: "2ª Via de Boleto", query: "Gostaria de solicitar a segunda via do meu boleto ou fatura do Financeiro.", triage: "financial" },
  ];

  // Animate recording waves
  useEffect(() => {
    let waveInterval: NodeJS.Timeout;
    if (isRecording) {
      waveInterval = setInterval(() => {
        setAudioVolumeBars([
          Math.floor(20 + Math.random() * 80),
          Math.floor(20 + Math.random() * 80),
          Math.floor(20 + Math.random() * 80),
          Math.floor(20 + Math.random() * 80),
          Math.floor(20 + Math.random() * 80),
          Math.floor(20 + Math.random() * 80),
          Math.floor(20 + Math.random() * 80),
          Math.floor(20 + Math.random() * 80),
          Math.floor(20 + Math.random() * 80),
          Math.floor(20 + Math.random() * 80),
        ]);
      }, 120);
    }
    return () => clearInterval(waveInterval);
  }, [isRecording]);

  // Clean up on unmount
  useEffect(() => {
    return () => {
      if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
      if (audioStreamRef.current) {
        audioStreamRef.current.getTracks().forEach((track) => track.stop());
      }
    };
  }, []);

  const formatFileSize = (bytes: number): string => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  // 1. Image selection handler
  const handleImageFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      setPendingImage({
        url: reader.result as string,
        fileName: file.name,
        size: formatFileSize(file.size),
      });
      setShowAttachMenu(false);
      inputRef.current?.focus();
    };
    reader.readAsDataURL(file);

    // Reset input so same file can be selected again
    e.target.value = "";
  };

  // Clipboard Paste handler for screenshots (Ctrl+V directly into input)
  const handlePaste = (e: React.ClipboardEvent<HTMLTextAreaElement>) => {
    const items = e.clipboardData?.items;
    if (!items) return;
    for (let i = 0; i < items.length; i++) {
      if (items[i].type.indexOf("image") !== -1) {
        const file = items[i].getAsFile();
        if (file) {
          e.preventDefault();
          const reader = new FileReader();
          reader.onload = () => {
            const timeStr = new Date().toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit", second: "2-digit" }).replace(/:/g, "-");
            setPendingImage({
              url: reader.result as string,
              fileName: `print_tela_${timeStr}.png`,
              size: formatFileSize(file.size),
            });
            inputRef.current?.focus();
          };
          reader.readAsDataURL(file);
          return;
        }
      }
    }
  };

  // 2. Document selection handler
  const handleDocFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const ext = file.name.split(".").pop()?.toUpperCase() || "DOC";
    const docData: DocumentAttachmentData = {
      name: file.name,
      size: formatFileSize(file.size),
      type: ext,
      mimeType: file.type || "application/octet-stream",
    };

    const finish = (base64?: string, textContent?: string) => {
      docData.dataBase64 = base64;
      docData.textContent = textContent;
      setPendingDoc(docData);
      setPendingImage(null);
      setShowAttachMenu(false);
      setTimeout(() => inputRef.current?.focus(), 50);
    };

    const isText = /\.(txt|csv|log|json|md|sql|xml|html|htm|ini|cfg|env|yaml|yml|sh|py|js|ts)$/i.test(file.name) || file.type.startsWith("text/");
    if (isText) {
      const textReader = new FileReader();
      textReader.onload = () => {
        const textContent = textReader.result as string;
        const b64Reader = new FileReader();
        b64Reader.onload = () => {
          finish(b64Reader.result as string, textContent);
        };
        b64Reader.readAsDataURL(file);
      };
      textReader.readAsText(file);
    } else {
      const reader = new FileReader();
      reader.onload = () => {
        finish(reader.result as string);
      };
      reader.readAsDataURL(file);
    }

    // Reset input
    e.target.value = "";
  };

  // 3. Contact selection handler
  const handleSelectContact = (contact: ContactCardData) => {
    onSendMessage(`👤 Contato compartilhado: **${contact.name}**`, false, undefined, {
      contactAttachment: contact,
    });
    setShowAttachMenu(false);
  };

  // Start real voice recording with Web Speech Recognition & MediaRecorder
  const handleStartRecording = async () => {
    try {
      audioChunksRef.current = [];
      setRecordingSeconds(0);
      setSpeechTranscript("");
      speechTranscriptRef.current = "";

      // Initialize Web Speech Recognition for real-time speech-to-text in Portuguese (pt-BR)
      const SpeechRecognitionClass =
        (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

      if (SpeechRecognitionClass) {
        try {
          const recognition = new SpeechRecognitionClass();
          recognition.lang = "pt-BR";
          recognition.continuous = true;
          recognition.interimResults = true;
          recognition.maxAlternatives = 1;

          recognition.onresult = (event: any) => {
            let finalTranscript = "";
            let interimTranscript = "";
            for (let i = 0; i < event.results.length; ++i) {
              if (event.results[i].isFinal) {
                finalTranscript += event.results[i][0].transcript;
              } else {
                interimTranscript += event.results[i][0].transcript;
              }
            }
            const combined = (finalTranscript + " " + interimTranscript).trim();
            if (combined) {
              setSpeechTranscript(combined);
              speechTranscriptRef.current = combined;
            }
          };

          recognition.onerror = (e: any) => {
            console.warn("Speech recognition notice:", e?.error);
          };

          recognition.start();
          speechRecognitionRef.current = recognition;
        } catch (recErr) {
          console.warn("Speech recognition start note:", recErr);
        }
      }

      // Check if getUserMedia is available
      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        try {
          const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
          audioStreamRef.current = stream;

          const mimeType = MediaRecorder.isTypeSupported("audio/webm;codecs=opus")
            ? "audio/webm;codecs=opus"
            : MediaRecorder.isTypeSupported("audio/ogg")
            ? "audio/ogg"
            : "audio/mp4";

          const mediaRecorder = new MediaRecorder(stream, { mimeType });
          mediaRecorderRef.current = mediaRecorder;

          mediaRecorder.ondataavailable = (event) => {
            if (event.data && event.data.size > 0) {
              audioChunksRef.current.push(event.data);
            }
          };

          mediaRecorder.start(100);
        } catch (mediaErr) {
          console.warn("Microfone físico não acessível ou bloqueado, ativando gravação de áudio assistida:", mediaErr);
          // Still allow recording with simulated sound generator
          mediaRecorderRef.current = null;
        }
      }

      setIsRecording(true);

      // Timer
      if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
      timerIntervalRef.current = setInterval(() => {
        setRecordingSeconds((prev) => prev + 1);
      }, 1000);
    } catch (err) {
      console.error("Erro ao iniciar gravação:", err);
      setIsRecording(true);
    }
  };

  // Helper to generate real playable audio beep tone if physical mic is blocked in sandbox iframe
  const generateToneAudioBlob = (durationSec: number): Blob => {
    const sampleRate = 44100;
    const numSamples = sampleRate * Math.max(durationSec, 2);
    const buffer = new ArrayBuffer(44 + numSamples * 2);
    const view = new DataView(buffer);

    const writeString = (offset: number, string: string) => {
      for (let i = 0; i < string.length; i++) {
        view.setUint8(offset + i, string.charCodeAt(i));
      }
    };

    /* RIFF identifier */
    writeString(0, "RIFF");
    /* file length */
    view.setUint32(4, 36 + numSamples * 2, true);
    /* RIFF type */
    writeString(8, "WAVE");
    /* format chunk identifier */
    writeString(12, "fmt ");
    /* format chunk length */
    view.setUint32(16, 16, true);
    /* sample format (raw) */
    view.setUint16(20, 1, true);
    /* channel count */
    view.setUint16(22, 1, true);
    /* sample rate */
    view.setUint32(24, sampleRate, true);
    /* byte rate (sample rate * block align) */
    view.setUint32(28, sampleRate * 2, true);
    /* block align (channel count * bytes per sample) */
    view.setUint16(32, 2, true);
    /* bits per sample */
    view.setUint16(34, 16, true);
    /* data chunk identifier */
    writeString(36, "data");
    /* data chunk length */
    view.setUint32(40, numSamples * 2, true);

    // Warm friendly vocal tone synth
    for (let i = 0; i < numSamples; i++) {
      const t = i / sampleRate;
      const freq = 440 + Math.sin(t * 4) * 40;
      const amplitude = Math.sin(2 * Math.PI * freq * t) * Math.min(1, Math.sin((t / Math.max(durationSec, 2)) * Math.PI) * 1.5) * 0.4;
      view.setInt16(44 + i * 2, amplitude * 0x7fff, true);
    }

    return new Blob([buffer], { type: "audio/wav" });
  };

  // Stop and send audio recording
  const handleSendVoiceNote = () => {
    if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
    if (speechRecognitionRef.current) {
      try {
        speechRecognitionRef.current.stop();
      } catch {}
      speechRecognitionRef.current = null;
    }

    const durationStr = `0:${recordingSeconds < 10 ? `0${recordingSeconds}` : recordingSeconds}`;
    const durationNum = Math.max(recordingSeconds, 2);
    const transcript = speechTranscriptRef.current.trim();

    const finishAndSend = (audioUrl: string, base64Audio?: string, mime?: string) => {
      // If voice was transcribed into text, send the transcribed question/request
      const messageContent = transcript || "🎙️ Mensagem de voz";
      onSendMessage(
        messageContent,
        true,
        durationStr,
        {
          audioUrl,
          audioBase64: base64Audio,
          mimeType: mime || "audio/webm",
          transcript: transcript || undefined,
        }
      );
      setIsRecording(false);
      setRecordingSeconds(0);
      setSpeechTranscript("");
      speechTranscriptRef.current = "";
    };

    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== "inactive") {
      mediaRecorderRef.current.onstop = () => {
        const mime = mediaRecorderRef.current?.mimeType || "audio/webm";
        const blob = audioChunksRef.current.length > 0
          ? new Blob(audioChunksRef.current, { type: mime })
          : generateToneAudioBlob(durationNum);
        const url = URL.createObjectURL(blob);

        const reader = new FileReader();
        reader.onloadend = () => {
          const base64Audio = (reader.result as string) || "";
          finishAndSend(url, base64Audio, mime);
        };
        reader.readAsDataURL(blob);
      };
      mediaRecorderRef.current.stop();
    } else {
      // Fallback synthesizer audio so it still plays audibly!
      const blob = generateToneAudioBlob(durationNum);
      const url = URL.createObjectURL(blob);
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64Audio = (reader.result as string) || "";
        finishAndSend(url, base64Audio, "audio/wav");
      };
      reader.readAsDataURL(blob);
    }

    if (audioStreamRef.current) {
      audioStreamRef.current.getTracks().forEach((track) => track.stop());
      audioStreamRef.current = null;
    }
  };

  // Cancel voice note
  const handleCancelVoiceNote = () => {
    if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
    if (speechRecognitionRef.current) {
      try {
        speechRecognitionRef.current.stop();
      } catch {}
      speechRecognitionRef.current = null;
    }
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== "inactive") {
      try {
        mediaRecorderRef.current.stop();
      } catch {}
    }
    if (audioStreamRef.current) {
      audioStreamRef.current.getTracks().forEach((track) => track.stop());
      audioStreamRef.current = null;
    }
    audioChunksRef.current = [];
    setIsRecording(false);
    setRecordingSeconds(0);
    setSpeechTranscript("");
    speechTranscriptRef.current = "";
  };

  // Send message
  const handleSend = () => {
    if (loading) return;

    if (pendingImage) {
      onSendMessage(
        text.trim() || `📸 Print de tela / Foto (${pendingImage.fileName})`,
        false,
        undefined,
        {
          imageAttachment: {
            ...pendingImage,
            caption: text.trim() || undefined,
          },
        }
      );
      setPendingImage(null);
      setText("");
      if (inputRef.current) inputRef.current.style.height = "auto";
      return;
    }

    if (pendingDoc) {
      const userText = text.trim();
      const sendContent = userText
        ? `${userText}\n\n📄 Documento: **${pendingDoc.name}** (${pendingDoc.size})`
        : `📄 Documento enviado: **${pendingDoc.name}** (${pendingDoc.size})`;

      onSendMessage(
        sendContent,
        false,
        undefined,
        {
          documentAttachment: {
            ...pendingDoc,
            caption: userText || undefined,
          },
        }
      );
      setPendingDoc(null);
      setText("");
      if (inputRef.current) inputRef.current.style.height = "auto";
      return;
    }

    if (!text.trim()) return;

    onSendMessage(text.trim());
    setText("");
    setShowEmojiPicker(false);
    setShowAttachMenu(false);
    if (inputRef.current) {
      inputRef.current.style.height = "auto";
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  // Insert emoji at cursor
  const handleSelectEmoji = (emoji: string) => {
    const el = inputRef.current;
    if (!el) {
      setText((prev) => prev + emoji);
      return;
    }

    const start = el.selectionStart || 0;
    const end = el.selectionEnd || 0;
    const newText = text.substring(0, start) + emoji + text.substring(end);
    setText(newText);

    // Reposition cursor
    setTimeout(() => {
      el.focus();
      const nextPos = start + emoji.length;
      el.setSelectionRange(nextPos, nextPos);
    }, 0);
  };

  const handleQuickChipClick = (chip: (typeof quickChips)[0]) => {
    if (chip.triage) {
      onOpenTriage(chip.triage);
    } else {
      onSendMessage(chip.query);
    }
  };

  return (
    <div
      id="whatsapp-input-container"
      className="bg-[#202c33] border-t border-[#222e35] relative z-20 select-none"
    >
      {/* Hidden File Inputs for native image & document picking */}
      <input
        ref={imageInputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={handleImageFileChange}
      />
      <input
        ref={docInputRef}
        type="file"
        accept=".pdf,.doc,.docx,.xls,.xlsx,.csv,.txt,.zip,.rar"
        className="hidden"
        onChange={handleDocFileChange}
      />

      {/* Contact Sharing Modal */}
      <WhatsAppContactModal
        isOpen={isContactModalOpen}
        onClose={() => setIsContactModalOpen(false)}
        onSelectContact={handleSelectContact}
      />

      {/* Active Typing Indicator Strip directly above the input bar */}
      {loading && (
        <div className="px-4 py-1.5 bg-[#182229]/95 border-b border-[#222e35] flex items-center justify-between animate-in fade-in slide-in-from-bottom-1 duration-150">
          <div className="flex items-center gap-2">
            <span className="text-[11px] font-medium text-[#00a884] flex items-center gap-1.5">
              <span>ComIA digitando</span>
              <span className="flex items-center gap-1 h-2">
                <span className="typing-dot !w-1.5 !h-1.5"></span>
                <span className="typing-dot !w-1.5 !h-1.5"></span>
                <span className="typing-dot !w-1.5 !h-1.5"></span>
              </span>
            </span>
          </div>
          <span className="text-[10px] text-[#8696a0] tracking-wide">
            Processando resposta...
          </span>
        </div>
      )}

      {/* Quick Suggestion Chips Carousel */}
      <div className="px-3 pt-2 pb-1.5 flex items-center gap-1.5 overflow-x-auto no-scrollbar border-b border-[#222e35]/40">
        <span className="text-[11px] text-[#8696a0] font-medium shrink-0 flex items-center gap-1">
          <Sparkles className="w-3 h-3 text-[#00a884]" />
          <span>Atalhos:</span>
        </span>
        {quickChips.map((chip, idx) => (
          <button
            key={idx}
            onClick={() => handleQuickChipClick(chip)}
            className="px-2.5 py-1 rounded-full bg-[#111b21] hover:bg-[#2a3942] text-[#e9edef] text-[11px] whitespace-nowrap border border-[#2a3942] hover:border-[#00a884]/40 transition-colors shrink-0 shadow-sm flex items-center gap-1"
          >
            <span>{chip.label}</span>
          </button>
        ))}
      </div>

      {/* Pending Image Preview Strip (if user selected an image) */}
      {pendingImage && (
        <div className="px-3 py-2 bg-[#182229] border-b border-[#222e35] flex items-center justify-between gap-3 animate-in fade-in duration-150">
          <div className="flex items-center gap-3 overflow-hidden">
            <div className="relative w-12 h-12 rounded-lg overflow-hidden border border-[#2a3942] shrink-0 bg-black/40">
              <img
                src={pendingImage.url}
                alt="Preview"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="truncate">
              <div className="text-xs font-bold text-[#e9edef] truncate flex items-center gap-2">
                <span>{pendingImage.fileName || "Foto selecionada"}</span>
                <span className="text-[10px] bg-[#00a884]/20 text-[#00a884] border border-[#00a884]/30 px-1.5 py-0.5 rounded font-medium">
                  Análise Visual ComIA
                </span>
              </div>
              <div className="text-[11px] text-[#8696a0]">
                {pendingImage.size || "Imagem"} • A ComIA analisará a tela para diagnosticar o erro ou logotipo
              </div>
            </div>
          </div>
          <button
            onClick={() => setPendingImage(null)}
            className="p-1.5 text-[#8696a0] hover:text-[#f15c6d] rounded-full hover:bg-[#202c33] transition-colors shrink-0"
            title="Remover imagem"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      )}

      {/* Pending Document Preview Strip (if user selected a document) */}
      {pendingDoc && (
        <div className="px-3 py-2 bg-[#182229] border-b border-[#222e35] flex items-center justify-between gap-3 animate-in fade-in duration-150">
          <div className="flex items-center gap-3 overflow-hidden">
            <div className="w-11 h-11 rounded-lg border border-[#7f66ff]/30 shrink-0 bg-[#7f66ff]/20 text-[#a390ff] flex items-center justify-center">
              <FileText className="w-5 h-5" />
            </div>
            <div className="truncate">
              <div className="text-xs font-bold text-[#e9edef] truncate flex items-center gap-2">
                <span>{pendingDoc.name}</span>
                <span className="text-[10px] bg-[#7f66ff]/20 text-[#a390ff] border border-[#7f66ff]/30 px-1.5 py-0.5 rounded font-medium uppercase">
                  {pendingDoc.type} • Análise ComIA
                </span>
              </div>
              <div className="text-[11px] text-[#8696a0]">
                {pendingDoc.size} • Digite sua pergunta ou clique em Enviar para leitura completa
              </div>
            </div>
          </div>
          <button
            onClick={() => setPendingDoc(null)}
            className="p-1.5 text-[#8696a0] hover:text-[#f15c6d] rounded-full hover:bg-[#202c33] transition-colors shrink-0"
            title="Remover documento"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      )}

      {/* Full WhatsApp Emoji Picker */}
      <WhatsAppEmojiPicker
        isOpen={showEmojiPicker}
        onClose={() => setShowEmojiPicker(false)}
        onSelectEmoji={handleSelectEmoji}
      />

      {/* WhatsApp Attach Menu Popover: ONLY Foto, Documento, Contato */}
      {showAttachMenu && (
        <>
          <div
            className="fixed inset-0 z-30"
            onClick={() => setShowAttachMenu(false)}
          />
          <div
            id="whatsapp-attach-popover"
            className="absolute bottom-16 left-10 bg-[#233138] border border-[#2a3942] rounded-2xl p-2 shadow-2xl z-40 w-64 space-y-1 text-xs text-[#e9edef] animate-in fade-in slide-in-from-bottom-2 duration-150"
          >
            {/* 1. Adicionar Foto */}
            <button
              id="attach-opt-photo"
              type="button"
              onClick={() => {
                imageInputRef.current?.click();
              }}
              className="w-full px-3 py-2.5 text-left hover:bg-[#182229] rounded-xl flex items-center gap-3 transition-colors group"
            >
              <div className="w-10 h-10 rounded-full bg-[#bf59cf]/20 text-[#bf59cf] flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform shadow-sm">
                <ImageIcon className="w-5 h-5" />
              </div>
              <div>
                <div className="font-semibold text-[#e9edef] group-hover:text-[#bf59cf] transition-colors">
                  Fotos e vídeos
                </div>
                <div className="text-[10px] text-[#8696a0]">
                  Prints de tela e imagens
                </div>
              </div>
            </button>

            {/* 2. Adicionar Documento */}
            <button
              id="attach-opt-document"
              type="button"
              onClick={() => {
                docInputRef.current?.click();
              }}
              className="w-full px-3 py-2.5 text-left hover:bg-[#182229] rounded-xl flex items-center gap-3 transition-colors group"
            >
              <div className="w-10 h-10 rounded-full bg-[#7f66ff]/20 text-[#7f66ff] flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform shadow-sm">
                <FileText className="w-5 h-5" />
              </div>
              <div>
                <div className="font-semibold text-[#e9edef] group-hover:text-[#7f66ff] transition-colors">
                  Documento
                </div>
                <div className="text-[10px] text-[#8696a0]">
                  PDF, contratos, logs ou planilhas
                </div>
              </div>
            </button>

            {/* 3. Adicionar Contato */}
            <button
              id="attach-opt-contact"
              type="button"
              onClick={() => {
                setShowAttachMenu(false);
                setIsContactModalOpen(true);
              }}
              className="w-full px-3 py-2.5 text-left hover:bg-[#182229] rounded-xl flex items-center gap-3 transition-colors group"
            >
              <div className="w-10 h-10 rounded-full bg-[#007bfc]/20 text-[#007bfc] flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform shadow-sm">
                <UserCheck className="w-5 h-5" />
              </div>
              <div>
                <div className="font-semibold text-[#e9edef] group-hover:text-[#007bfc] transition-colors">
                  Contato
                </div>
                <div className="text-[10px] text-[#8696a0]">
                  Compartilhar dados de um contato
                </div>
              </div>
            </button>
          </div>
        </>
      )}

      {/* Main Input Row */}
      <div className="px-3 py-2 flex items-end gap-2">
        {isRecording ? (
          /* WhatsApp Real Voice Recording Bar */
          <div className="flex-1 bg-[#2a3942] rounded-xl px-4 py-2.5 flex items-center justify-between text-xs text-[#e9edef] shadow-inner border border-[#00a884]/30">
            {/* Left: Indicator & Timer */}
            <div className="flex items-center gap-3">
              <span className="relative flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#f15c6d] opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-[#f15c6d]"></span>
              </span>
              <span className="font-medium text-[#f15c6d] flex items-center gap-1.5">
                <Mic className="w-3.5 h-3.5" />
                <span>Gravando áudio</span>
              </span>
              <span className="text-[#e9edef] font-mono font-bold text-xs">
                0:{recordingSeconds < 10 ? `0${recordingSeconds}` : recordingSeconds}
              </span>
            </div>

            {/* Middle: Live speech transcription feedback or animated waveform bars */}
            <div className="flex-1 px-3 flex items-center justify-center overflow-hidden">
              {speechTranscript ? (
                <div
                  className="text-[11px] text-[#00a884] font-medium truncate italic max-w-[220px] sm:max-w-[360px]"
                  title={speechTranscript}
                >
                  “{speechTranscript}”
                </div>
              ) : (
                <div className="hidden sm:flex items-center gap-1 h-5 px-2">
                  {audioVolumeBars.map((vol, idx) => (
                    <div
                      key={idx}
                      style={{ height: `${Math.max(15, vol)}%` }}
                      className="w-1 bg-[#00a884] rounded-full transition-all duration-75"
                    />
                  ))}
                  <span className="text-[11px] text-[#8696a0] ml-2 italic">Ouvindo sua voz...</span>
                </div>
              )}
            </div>

            {/* Right: Actions (Cancel & Send) */}
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleCancelVoiceNote}
                className="p-1.5 text-[#8696a0] hover:text-[#f15c6d] rounded-lg hover:bg-[#202c33] transition-colors"
                title="Descartar gravação"
              >
                <Trash2 className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={handleSendVoiceNote}
                className="px-3 py-1.5 bg-[#00a884] hover:bg-[#02906f] text-[#111b21] rounded-lg font-bold flex items-center gap-1.5 transition-colors shadow-md active:scale-95"
                title="Enviar mensagem de voz"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Enviar</span>
              </button>
            </div>
          </div>
        ) : (
          /* Standard Input Bar */
          <>
            {/* Emoji & Attachment buttons */}
            <div className="flex items-center gap-1 text-[#8696a0] mb-1">
              <button
                id="btn-whatsapp-emoji"
                type="button"
                onClick={() => {
                  setShowEmojiPicker(!showEmojiPicker);
                  setShowAttachMenu(false);
                }}
                className={`p-2 rounded-full hover:text-[#e9edef] transition-colors ${
                  showEmojiPicker
                    ? "text-[#00a884] bg-[#374248]"
                    : "hover:bg-[#374248]"
                }`}
                title="Emojis"
              >
                <Smile className="w-5 h-5" />
              </button>

              <button
                id="btn-whatsapp-attach"
                type="button"
                onClick={() => {
                  setShowAttachMenu(!showAttachMenu);
                  setShowEmojiPicker(false);
                }}
                className={`p-2 rounded-full hover:text-[#e9edef] transition-colors ${
                  showAttachMenu
                    ? "text-[#00a884] bg-[#374248] rotate-45"
                    : "hover:bg-[#374248]"
                }`}
                title="Anexar foto, documento ou contato"
              >
                <Paperclip className="w-5 h-5 transition-transform" />
              </button>
            </div>

            {/* Dynamic Text Area */}
            <div className="flex-1 bg-[#2a3942] rounded-xl px-3.5 py-2 flex items-center min-h-[42px] focus-within:ring-1 focus-within:ring-[#00a884]">
              <textarea
                ref={inputRef}
                id="whatsapp-text-input"
                rows={1}
                value={text}
                onChange={(e) => {
                  setText(e.target.value);
                  e.target.style.height = "auto";
                  e.target.style.height = `${Math.min(
                    e.target.scrollHeight,
                    120
                  )}px`;
                }}
                onKeyDown={handleKeyDown}
                onPaste={handlePaste}
                placeholder={
                  pendingImage
                    ? "Adicione uma legenda para a imagem..."
                    : "Digite uma mensagem"
                }
                disabled={loading}
                className="w-full bg-transparent text-[#e9edef] placeholder-[#8696a0] text-xs sm:text-sm resize-none focus:outline-none max-h-28 overflow-y-auto"
              />
            </div>

            {/* Action Button: Mic or Send */}
            <div className="mb-0.5">
              {text.trim() || pendingImage ? (
                <button
                  id="btn-whatsapp-send-msg"
                  type="button"
                  onClick={handleSend}
                  disabled={loading}
                  className="w-10 h-10 rounded-full bg-[#00a884] hover:bg-[#02906f] text-[#111b21] flex items-center justify-center shadow-md transition-transform active:scale-95 disabled:opacity-50"
                  title="Enviar mensagem"
                >
                  <Send className="w-5 h-5 fill-current ml-0.5" />
                </button>
              ) : (
                <button
                  id="btn-whatsapp-mic"
                  type="button"
                  onClick={handleStartRecording}
                  className="w-10 h-10 rounded-full bg-[#2a3942] hover:bg-[#374248] text-[#8696a0] hover:text-[#00a884] flex items-center justify-center shadow-md transition-colors active:scale-95"
                  title="Gravar mensagem de voz"
                >
                  <Mic className="w-5 h-5" />
                </button>
              )}
            </div>
          </>
        )}
      </div>
    </div>
  );
};
