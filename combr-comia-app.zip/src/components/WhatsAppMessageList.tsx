import React, { useState, useRef, useEffect } from "react";
import ReactMarkdown from "react-markdown";
import { ComIALogo } from "./ComIALogo";
import {
  CheckCheck,
  Lock,
  Copy,
  Check,
  Play,
  Pause,
  ArrowRight,
  CreditCard,
  Building2,
  Wrench,
  FileText,
  Download,
  UserCheck,
  Phone,
  Mail,
  ExternalLink,
  X,
  Mic,
  FileSpreadsheet,
  FileCode,
  FileArchive,
  Image as ImageIcon,
  User,
  ChevronRight,
  Volume2,
  Square,
  Star,
} from "lucide-react";
import { Message, Ticket, TriageType } from "../types";
import { speakHumanized, stopSpeech } from "../lib/speechVoice";
import { getCurrentPeriodGreeting } from "../lib/greetingUtils";
import { liveSync } from "../lib/liveSync";

interface WhatsAppMessageListProps {
  messages: Message[];
  loading: boolean;
  onOpenTriage: (type: TriageType) => void;
  selectedTriageType?: TriageType | null;
  onSendQuickMessage: (text: string) => void;
  searchQuery?: string;
  onSelectChannel?: (channelId: string) => void;
  tickets?: Ticket[];
  selectedVoiceUri?: string | null;
  playbackRate?: number;
}

export const WhatsAppMessageList: React.FC<WhatsAppMessageListProps> = ({
  messages,
  loading,
  onOpenTriage,
  selectedTriageType = null,
  onSendQuickMessage,
  searchQuery = "",
  onSelectChannel,
  tickets = [],
  selectedVoiceUri = null,
  playbackRate = 1.0,
}) => {
  const [selectedOption, setSelectedOption] = useState<TriageType | null>(selectedTriageType || null);
  const [periodGreeting, setPeriodGreeting] = useState(getCurrentPeriodGreeting());

  // Periodically check and update the greeting according to exact current time (SP/Brasília)
  useEffect(() => {
    setPeriodGreeting(getCurrentPeriodGreeting());
    const interval = setInterval(() => {
      setPeriodGreeting(getCurrentPeriodGreeting());
    }, 30000); // Check every 30 seconds
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (selectedTriageType) {
      setSelectedOption(selectedTriageType);
    }
  }, [selectedTriageType]);

  const handleSelectOption = (type: TriageType) => {
    setSelectedOption(type);
    onOpenTriage(type);
  };
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [playingAudioId, setPlayingAudioId] = useState<string | null>(null);
  const [audioPlaybackRate, setAudioPlaybackRate] = useState<number>(1);
  const [audioProgress, setAudioProgress] = useState<Record<string, number>>({});
  const [audioCurrentTime, setAudioCurrentTime] = useState<Record<string, string>>({});
  const [messageReactions, setMessageReactions] = useState<Record<string, string>>({});
  const [lightboxImage, setLightboxImage] = useState<{ url: string; name?: string } | null>(null);

  const messagesEndRef = useRef<HTMLDivElement | null>(null);
  const audioElementRef = useRef<HTMLAudioElement | null>(null);

  const [speakingMessageId, setSpeakingMessageId] = useState<string | null>(null);

  // Client Attendance Rating State
  const [selectedStars, setSelectedStars] = useState<number>(5);
  const [selectedTags, setSelectedTags] = useState<string[]>([
    "⚡ Rápido e Eficiente",
    "✅ Problema Resolvido",
  ]);
  const [ratingComment, setRatingComment] = useState<string>("");
  const [submittedRating, setSubmittedRating] = useState<boolean>(false);

  const handleSubmitEvaluation = () => {
    liveSync.submitRating({
      stars: selectedStars,
      tags: selectedTags,
      comment: ratingComment.trim(),
      clientName: "Cliente ComBR",
    });
    setSubmittedRating(true);
  };

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, loading]);

  // Clean up speech on unmount
  useEffect(() => {
    return () => {
      stopSpeech();
    };
  }, []);

  const handleToggleSpeakMessage = (msg: Message) => {
    if (speakingMessageId === msg.id) {
      stopSpeech();
      setSpeakingMessageId(null);
      return;
    }

    if (audioElementRef.current) {
      audioElementRef.current.pause();
      setPlayingAudioId(null);
    }
    stopSpeech();

    setSpeakingMessageId(msg.id);
    speakHumanized(msg.content, {
      voiceURI: selectedVoiceUri || undefined,
      rate: playbackRate,
      onStart: () => setSpeakingMessageId(msg.id),
      onEnd: () => setSpeakingMessageId(null),
      onError: () => setSpeakingMessageId(null),
    });
  };

  // Handle real audio playback with HTMLAudioElement
  const handleTogglePlayAudio = (msg: Message) => {
    const id = msg.id;

    // If currently reading text aloud, stop it
    if (speakingMessageId) {
      stopSpeech();
      setSpeakingMessageId(null);
    }

    // If clicking currently playing audio, toggle pause
    if (playingAudioId === id) {
      if (audioElementRef.current) {
        audioElementRef.current.pause();
      }
      setPlayingAudioId(null);
      return;
    }

    // Stop existing audio
    if (audioElementRef.current) {
      audioElementRef.current.pause();
      audioElementRef.current = null;
    }

    if (msg.audioUrl) {
      const audio = new Audio(msg.audioUrl);
      audio.playbackRate = audioPlaybackRate;
      audioElementRef.current = audio;

      audio.ontimeupdate = () => {
        if (!audio.duration) return;
        const progress = (audio.currentTime / audio.duration) * 100;
        setAudioProgress((prev) => ({ ...prev, [id]: progress }));

        const mins = Math.floor(audio.currentTime / 60);
        const secs = Math.floor(audio.currentTime % 60);
        setAudioCurrentTime((prev) => ({
          ...prev,
          [id]: `${mins}:${secs < 10 ? `0${secs}` : secs}`,
        }));
      };

      audio.onended = () => {
        setPlayingAudioId(null);
        setAudioProgress((prev) => ({ ...prev, [id]: 0 }));
      };

      audio.onerror = () => {
        console.warn("Falha ao reproduzir áudio local, executando simulação suave.");
        runSimulatedAudio(id);
      };

      audio.play().catch((err) => {
        console.warn("Audio play prevented:", err);
        runSimulatedAudio(id);
      });

      setPlayingAudioId(id);
    } else {
      runSimulatedAudio(id);
    }
  };

  // Simulated audio runner fallback
  const runSimulatedAudio = (id: string) => {
    setPlayingAudioId(id);
    let current = 0;
    const interval = setInterval(() => {
      current += 10;
      if (current > 100) {
        clearInterval(interval);
        setPlayingAudioId(null);
        setAudioProgress((prev) => ({ ...prev, [id]: 0 }));
      } else {
        setAudioProgress((prev) => ({ ...prev, [id]: current }));
      }
    }, 250);
  };

  const handleCycleSpeed = () => {
    const nextSpeed = audioPlaybackRate === 1 ? 1.5 : audioPlaybackRate === 1.5 ? 2 : 1;
    setAudioPlaybackRate(nextSpeed);
    if (audioElementRef.current) {
      audioElementRef.current.playbackRate = nextSpeed;
    }
  };

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleAddReaction = (msgId: string, emoji: string) => {
    setMessageReactions((prev) => ({
      ...prev,
      [msgId]: prev[msgId] === emoji ? "" : emoji,
    }));
  };

  // Download VCF vCard for contact
  const handleDownloadVCard = (contact: import("../types").ContactCardData) => {
    const vcard = `BEGIN:VCARD
VERSION:3.0
FN:${contact.name}
TEL;TYPE=CELL,VOICE:${contact.phone}
${contact.organization ? `ORG:${contact.organization}` : ""}
${contact.email ? `EMAIL:${contact.email}` : ""}
NOTE:Contato compartilhado via ComIA - ComBR Soluções em Nuvem
END:VCARD`;

    const blob = new Blob([vcard], { type: "text/vcard;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `${contact.name.replace(/\s+/g, "_")}.vcf`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  // Download document or base64 file
  const handleDownloadFile = (doc: import("../types").DocumentAttachmentData) => {
    const link = document.createElement("a");
    link.href = doc.dataBase64 || "#";
    link.download = doc.name;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const formatTime = (isoString: string) => {
    try {
      const date = new Date(isoString);
      return date.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });
    } catch {
      return "12:00";
    }
  };

  const getDocIcon = (type: string) => {
    const t = type.toUpperCase();
    if (t.includes("PDF")) return <FileText className="w-6 h-6 text-[#f15c6d]" />;
    if (t.includes("XLS") || t.includes("CSV")) return <FileSpreadsheet className="w-6 h-6 text-[#00a884]" />;
    if (t.includes("ZIP") || t.includes("RAR")) return <FileArchive className="w-6 h-6 text-[#ffd279]" />;
    if (t.includes("DOC")) return <FileText className="w-6 h-6 text-[#53bdeb]" />;
    return <FileCode className="w-6 h-6 text-[#8696a0]" />;
  };

  const filteredMessages = searchQuery
    ? messages.filter((m) => m.content.toLowerCase().includes(searchQuery.toLowerCase()))
    : messages;

  return (
    <div
      id="whatsapp-message-viewport"
      className="flex-1 overflow-y-auto p-3 sm:p-5 space-y-3 whatsapp-bg relative select-text"
    >
      {/* Lightbox Image Preview Modal */}
      {lightboxImage && (
        <div
          className="fixed inset-0 z-50 bg-black/90 flex flex-col items-center justify-center p-4 backdrop-blur-md animate-in fade-in duration-150"
          onClick={() => setLightboxImage(null)}
        >
          <div className="absolute top-4 right-4 flex items-center gap-3">
            <a
              href={lightboxImage.url}
              download={lightboxImage.name || "imagem.jpg"}
              onClick={(e) => e.stopPropagation()}
              className="p-2 rounded-full bg-[#202c33] text-[#e9edef] hover:bg-[#2a3942] transition-colors"
              title="Baixar imagem"
            >
              <Download className="w-5 h-5" />
            </a>
            <button
              onClick={() => setLightboxImage(null)}
              className="p-2 rounded-full bg-[#202c33] text-[#e9edef] hover:bg-[#2a3942] transition-colors"
              title="Fechar"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
          <img
            src={lightboxImage.url}
            alt="Ampliada"
            className="max-h-[85vh] max-w-[95vw] rounded-xl object-contain shadow-2xl border border-[#2a3942]"
            onClick={(e) => e.stopPropagation()}
          />
          {lightboxImage.name && (
            <div className="mt-3 text-xs text-[#8696a0] font-mono bg-[#111b21]/80 px-3 py-1 rounded-full">
              {lightboxImage.name}
            </div>
          )}
        </div>
      )}

      {/* WhatsApp Security Notice Banner */}
      <div className="flex justify-center my-2">
        <div className="bg-[#182229] border border-[#222e35] text-[#ffd279] px-3.5 py-2 rounded-lg text-center max-w-md shadow-sm flex items-center gap-2">
          <Lock className="w-3.5 h-3.5 text-[#ffd279] shrink-0" />
          <p className="text-[11px] leading-tight">
            As mensagens desta conversa com a <strong>ComIA</strong> são protegidas e atendem aos padrões oficiais de segurança e privacidade da <strong>ComBR Soluções em Nuvem</strong>.
          </p>
        </div>
      </div>

      {/* Date Pill Separator */}
      <div className="flex justify-center my-3">
        <span className="bg-[#182229] border border-[#222e35] text-[#8696a0] text-[10px] font-bold uppercase tracking-wider px-3 py-1 rounded-md shadow-sm">
          Hoje
        </span>
      </div>

      {/* Initial Empty Chat Welcome & Invitation State */}
      {filteredMessages.length === 0 && !loading && (
        <div className="flex flex-col items-center justify-center my-4 sm:my-8 max-w-md mx-auto text-center px-4 animate-fadeIn">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#00a884]/15 border border-[#00a884]/30 text-[#00a884] text-xs font-semibold mb-2 shadow-sm">
            <span>ComBr Soluções em Nuvem</span>
            <span>•</span>
            <span>Conta Oficial</span>
          </div>

          <h2 className="text-[#e9edef] font-bold text-base mb-1">
            ComIA Atendimento
          </h2>
          <p className="text-[#8696a0] text-xs leading-relaxed max-w-xs mb-5">
            Digite sua mensagem abaixo para iniciar a conversa com a assistente ou selecione uma saudação rápida:
          </p>

          {/* Quick Greeting Chips */}
          <div className="flex flex-col sm:flex-row flex-wrap justify-center gap-2 w-full">
            <button
              id="btn-quick-greeting-primary"
              type="button"
              onClick={() => onSendQuickMessage(`${periodGreeting.greeting}, tudo bem?`)}
              className="px-3.5 py-2.5 bg-[#182229] hover:bg-[#202c33] active:bg-[#2a3942] border border-[#2a3942] hover:border-[#00a884]/60 text-[#e9edef] rounded-xl text-xs flex items-center justify-center gap-2 transition-all active:scale-95 shadow-sm group"
              title={`Saudação automática (${periodGreeting.greeting}) conforme o horário de Brasília`}
            >
              <span className="text-sm">👋</span>
              <span className="font-medium group-hover:text-[#00a884] transition-colors">
                {periodGreeting.greeting}, tudo bem?
              </span>
            </button>
            <button
              id="btn-quick-greeting-ola-suporte"
              type="button"
              onClick={() => onSendQuickMessage("Olá! Preciso de ajuda com meu e-mail")}
              className="px-3.5 py-2.5 bg-[#182229] hover:bg-[#202c33] active:bg-[#2a3942] border border-[#2a3942] hover:border-[#00a884]/60 text-[#e9edef] rounded-xl text-xs flex items-center justify-center gap-2 transition-all active:scale-95 shadow-sm group"
            >
              <span className="text-sm">✉️</span>
              <span className="font-medium group-hover:text-[#00a884] transition-colors">
                Olá! Preciso de ajuda com e-mail
              </span>
            </button>
            <button
              id="btn-quick-greeting-comercial"
              type="button"
              onClick={() => onSendQuickMessage(`${periodGreeting.greeting}! Gostaria de falar com o Comercial`)}
              className="px-3.5 py-2.5 bg-[#182229] hover:bg-[#202c33] active:bg-[#2a3942] border border-[#2a3942] hover:border-[#00a884]/60 text-[#e9edef] rounded-xl text-xs flex items-center justify-center gap-2 transition-all active:scale-95 shadow-sm group"
              title={`Solicitar contato com o Comercial (${periodGreeting.greeting})`}
            >
              <span className="text-sm">💼</span>
              <span className="font-medium group-hover:text-[#00a884] transition-colors">
                {periodGreeting.greeting}! Gostaria de falar com Comercial
              </span>
            </button>
          </div>
        </div>
      )}

      {/* Messages Stream */}
      {filteredMessages.map((msg) => {
        const isAssistant = msg.sender === "assistant";
        const isSystem = msg.sender === "system";
        const isCopied = copiedId === msg.id;
        const currentReaction = messageReactions[msg.id];
        const contentLower = msg.content.toLowerCase();

        const hasEmailParams =
          contentLower.includes("imap.combr.com.br") ||
          contentLower.includes("smtp.combr.com.br") ||
          contentLower.includes("webmail.combr.com.br");

        if (isSystem) {
          return (
            <div
              key={msg.id}
              id={`message-${msg.id}`}
              className="my-3 flex justify-center"
            >
              <div className="max-w-md px-3.5 py-1.5 rounded-lg bg-[#182229]/95 border border-[#2a3942] text-[11px] text-[#8696a0] text-center shadow-sm">
                <ReactMarkdown
                  components={{
                    p: ({ children }) => <span>{children}</span>,
                    strong: ({ children }) => <strong className="text-[#00a884] font-semibold">{children}</strong>,
                  }}
                >
                  {msg.content}
                </ReactMarkdown>
              </div>
            </div>
          );
        }

        return (
          <div
            key={msg.id}
            id={`message-${msg.id}`}
            className={`flex ${
              isAssistant ? "justify-start" : "justify-end"
            } group relative my-1`}
          >
            {/* Assistant / Human Agent Profile Picture */}
            {isAssistant && (
              <div className="mr-2 self-end mb-1 shrink-0">
                {msg.isHumanAgent ? (
                  <div className="w-7 h-7 rounded-full bg-[#00a884]/20 border border-[#00a884]/50 flex items-center justify-center text-xs shadow-sm" title={msg.agentName || "Atendente Humano"}>
                    🧑‍💼
                  </div>
                ) : (
                  <ComIALogo size="sm" showText={false} />
                )}
              </div>
            )}

            {/* WhatsApp Bubble Container */}
            <div
              className={`relative max-w-[92%] sm:max-w-[80%] rounded-2xl p-2.5 sm:p-3 text-xs sm:text-[13px] shadow-sm transition-all ${
                isAssistant
                  ? msg.isHumanAgent
                    ? "bg-[#182229] border border-[#00a884]/40 text-[#e9edef] bubble-incoming"
                    : "bg-[#202c33] text-[#e9edef] bubble-incoming"
                  : "bg-[#005c4b] text-[#e9edef] bubble-outgoing"
              }`}
            >
              {/* Human Agent Header Badge */}
              {msg.isHumanAgent && (
                <div className="flex items-center gap-1.5 pb-1 mb-1.5 border-b border-[#2a3942] text-[11px] font-semibold text-[#00a884]">
                  <span className="w-2 h-2 rounded-full bg-[#00a884] animate-pulse"></span>
                  <span>🧑‍💼 {msg.agentName || "Suporte Técnico Humano"}</span>
                </div>
              )}
              {/* 1. ATTACHMENT: Image / Photo */}
              {msg.imageAttachment && (
                <div className="mb-2 space-y-1.5">
                  <div
                    onClick={() =>
                      setLightboxImage({
                        url: msg.imageAttachment!.url,
                        name: msg.imageAttachment!.fileName,
                      })
                    }
                    className="relative rounded-xl overflow-hidden cursor-pointer max-h-72 bg-black/30 border border-white/10 group/img flex items-center justify-center"
                  >
                    <img
                      src={msg.imageAttachment.url}
                      alt={msg.imageAttachment.fileName || "Foto enviada"}
                      className="w-full h-auto object-cover max-h-72 rounded-xl hover:scale-[1.02] transition-transform"
                    />
                    <div className="absolute inset-0 bg-black/30 opacity-0 group-hover/img:opacity-100 transition-opacity flex items-center justify-center">
                      <span className="bg-black/60 text-white text-[11px] px-2.5 py-1 rounded-full font-medium">
                        Clique para ampliar
                      </span>
                    </div>
                  </div>
                  {msg.imageAttachment.caption && (
                    <p className="text-xs text-[#e9edef] px-1 font-medium leading-normal">
                      {msg.imageAttachment.caption}
                    </p>
                  )}
                  <div className="text-[10px] text-[#8696a0] px-1 flex items-center justify-between">
                    <span>{msg.imageAttachment.fileName || "Foto"}</span>
                    {msg.imageAttachment.size && <span>{msg.imageAttachment.size}</span>}
                  </div>
                </div>
              )}

              {/* 2. ATTACHMENT: Document */}
              {msg.documentAttachment && (
                <div className="mb-2 bg-[#111b21] border border-[#2a3942] rounded-xl p-3 flex items-center justify-between gap-3 shadow-sm hover:border-[#00a884]/50 transition-colors">
                  <div className="flex items-center gap-3 overflow-hidden">
                    <div className="w-11 h-11 rounded-lg bg-[#202c33] border border-[#2a3942] flex items-center justify-center shrink-0">
                      {getDocIcon(msg.documentAttachment.type)}
                    </div>
                    <div className="truncate">
                      <div className="text-xs font-bold text-[#e9edef] truncate">
                        {msg.documentAttachment.name}
                      </div>
                      <div className="text-[10px] text-[#8696a0] flex items-center gap-1.5 mt-0.5">
                        <span className="uppercase font-semibold text-[#00a884]">
                          {msg.documentAttachment.type}
                        </span>
                        <span>•</span>
                        <span>{msg.documentAttachment.size}</span>
                      </div>
                    </div>
                  </div>
                  <button
                    onClick={() => handleDownloadFile(msg.documentAttachment!)}
                    className="p-2 rounded-lg bg-[#202c33] hover:bg-[#00a884] text-[#8696a0] hover:text-[#111b21] transition-colors shrink-0"
                    title="Baixar arquivo"
                  >
                    <Download className="w-4 h-4" />
                  </button>
                </div>
              )}

              {/* 3. ATTACHMENT: Contact Card */}
              {msg.contactAttachment && (
                <div className="mb-2 bg-[#111b21] border border-[#2a3942] rounded-xl p-3 space-y-2.5 shadow-sm">
                  <div className="flex items-center gap-3">
                    <div className="w-11 h-11 rounded-full bg-[#007bfc]/20 border border-[#007bfc]/40 text-[#007bfc] flex items-center justify-center font-bold text-base shrink-0">
                      {msg.contactAttachment.name.charAt(0)}
                    </div>
                    <div>
                      <div className="text-xs font-bold text-[#e9edef]">
                        {msg.contactAttachment.name}
                      </div>
                      <div className="text-[11px] text-[#00a884] flex items-center gap-1 font-mono">
                        <Phone className="w-3 h-3 text-[#00a884]" />
                        <span>{msg.contactAttachment.phone}</span>
                      </div>
                      {msg.contactAttachment.organization && (
                        <div className="text-[10px] text-[#8696a0]">
                          {msg.contactAttachment.organization}
                        </div>
                      )}
                    </div>
                  </div>
                  <div className="border-t border-[#2a3942] pt-2 flex items-center gap-2">
                    <a
                      href={`https://wa.me/${msg.contactAttachment.phone.replace(/\D/g, "")}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex-1 py-1.5 rounded-lg bg-[#202c33] hover:bg-[#2a3942] text-center text-[11px] font-semibold text-[#00a884] flex items-center justify-center gap-1 transition-colors"
                    >
                      <Phone className="w-3 h-3" />
                      <span>Conversar</span>
                    </a>
                    <button
                      type="button"
                      onClick={() => handleDownloadVCard(msg.contactAttachment!)}
                      className="flex-1 py-1.5 rounded-lg bg-[#00a884] hover:bg-[#02906f] text-center text-[11px] font-bold text-[#111b21] flex items-center justify-center gap-1 transition-colors shadow-sm"
                    >
                      <Download className="w-3 h-3" />
                      <span>Salvar Contato</span>
                    </button>
                  </div>
                </div>
              )}

              {/* 4. ATTACHMENT: Voice Note Player if isAudio */}
              {msg.isAudio ? (
                <div className="space-y-2 py-1 min-w-[240px] sm:min-w-[280px]">
                  <div className="flex items-center gap-3">
                    {/* Play / Pause button */}
                    <button
                      onClick={() => handleTogglePlayAudio(msg)}
                      className="w-11 h-11 rounded-full bg-[#00a884] text-[#111b21] flex items-center justify-center shadow-md hover:scale-105 active:scale-95 transition-all shrink-0"
                      title={playingAudioId === msg.id ? "Pausar" : "Reproduzir"}
                    >
                      {playingAudioId === msg.id ? (
                        <Pause className="w-5 h-5 fill-current" />
                      ) : (
                        <Play className="w-5 h-5 fill-current ml-0.5" />
                      )}
                    </button>

                    <div className="flex-1 space-y-1.5">
                      {/* Animated Waveform Bars */}
                      <div className="flex items-center gap-0.5 h-6">
                        {[30, 70, 45, 90, 60, 40, 85, 95, 50, 75, 60, 40, 90, 65, 30, 80, 50, 60, 40, 70].map(
                          (h, i) => {
                            const isFilled = ((i + 1) / 20) * 100 <= (audioProgress[msg.id] || 0);
                            return (
                              <div
                                key={i}
                                style={{ height: `${h}%` }}
                                className={`w-1 rounded-full transition-all duration-100 ${
                                  isFilled ? "bg-[#53bdeb]" : "bg-[#8696a0]/40"
                                }`}
                              />
                            );
                          }
                        )}
                      </div>

                      {/* Progress Time & Speed toggle */}
                      <div className="flex justify-between items-center text-[10px] text-[#8696a0]">
                        <span>
                          {audioCurrentTime[msg.id] || "0:00"} / {msg.audioDuration || "0:08"}
                        </span>
                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={handleCycleSpeed}
                            className="px-1.5 py-0.5 rounded bg-[#111b21] text-[#00a884] font-mono text-[9px] hover:bg-[#2a3942] transition-colors"
                            title="Alterar velocidade de reprodução"
                          >
                            {audioPlaybackRate}x
                          </button>
                          <span className="flex items-center gap-0.5 text-[#53bdeb]">
                            <Mic className="w-2.5 h-2.5" />
                            <span>Voz</span>
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* WhatsApp-style audio transcript if text was spoken & recognized */}
                  {(msg.audioTranscript || (msg.content && msg.content !== "🎙️ Mensagem de voz")) && (
                    <div className="text-xs text-[#d1d7db] bg-[#111b21]/60 px-2.5 py-1.5 rounded-md border border-[#2a3942]/60 flex items-start gap-1.5">
                      <span className="text-[10px] font-semibold text-[#00a884] uppercase tracking-wider shrink-0 mt-0.5">
                        Transcrição:
                      </span>
                      <span className="break-words italic text-[#e9edef]">
                        "{msg.audioTranscript || msg.content.replace(/^🎙️\s*(Mensagem de voz|Áudio):\s*/i, "").trim()}"
                      </span>
                    </div>
                  )}
                </div>
              ) : (
                /* Standard Markdown Message Content */
                !msg.imageAttachment && (
                  <div className="leading-relaxed break-words whitespace-pre-line space-y-2.5 prose prose-invert max-w-none text-xs sm:text-[13px] prose-p:my-1.5 prose-strong:text-[#e9edef] prose-strong:font-bold prose-hr:border-[#2a3942] prose-ul:my-1.5 prose-ol:my-1.5 prose-li:my-0.5 prose-code:text-[#53bdeb] prose-code:bg-[#111b21]/70 prose-code:px-1.5 prose-code:py-0.5 prose-code:rounded prose-code:text-[11px] prose-code:before:content-none prose-code:after:content-none">
                    <ReactMarkdown>{msg.content}</ReactMarkdown>
                  </div>
                )
              )}

              {/* Interactive WhatsApp Department Action Buttons */}
              {isAssistant && !msg.isHumanAgent && (
                msg.showDepartmentOptions !== false ||
                /botão|botões|clic.*botão|selecion.*botão|abaixo|proposta detalhada|soluções que a combr oferece|canais de atendimento|escolha um dos departamentos|opções rápidas/i.test(msg.content) ||
                msg.id === "welcome-comia-1"
              ) && (
                <div className="mt-3 pt-2.5 border-t border-[#2a3942]/70 space-y-2">
                  <div className="text-[11px] font-semibold text-[#8696a0] flex items-center justify-between">
                    <span>Opções Rápidas de Atendimento:</span>
                    <span className="text-[10px] text-[#00a884] font-medium">Toque para selecionar</span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                    {/* Botão Comercial */}
                    <button
                      type="button"
                      onClick={() => handleSelectOption("commercial")}
                      className={`p-2.5 rounded-xl border text-left flex items-center justify-between gap-2 transition-all cursor-pointer shadow-sm group ${
                        selectedOption === "commercial"
                          ? "bg-[#00a884]/20 border-[#00a884] text-white ring-1 ring-[#00a884]"
                          : "bg-[#111b21] hover:bg-[#202c33] active:bg-[#2a3942] border-[#2a3942] hover:border-[#00a884]/60 text-[#e9edef]"
                      }`}
                    >
                      <div className="flex items-center gap-2 min-w-0">
                        <div className="p-1.5 rounded-lg bg-[#00a884]/20 text-[#00a884] shrink-0 group-hover:scale-105 transition-transform">
                          <Building2 className="w-4 h-4" />
                        </div>
                        <div className="min-w-0">
                          <div className="text-xs font-bold truncate group-hover:text-[#00a884] transition-colors">
                            Comercial & Vendas
                          </div>
                          <div className="text-[10px] text-[#8696a0] truncate">
                            Propostas e orçamentos
                          </div>
                        </div>
                      </div>
                      <ChevronRight className="w-3.5 h-3.5 text-[#8696a0] group-hover:text-[#00a884] group-hover:translate-x-0.5 transition-all shrink-0" />
                    </button>

                    {/* Botão Suporte Técnico N2 */}
                    <button
                      type="button"
                      onClick={() => handleSelectOption("support_n2")}
                      className={`p-2.5 rounded-xl border text-left flex items-center justify-between gap-2 transition-all cursor-pointer shadow-sm group ${
                        selectedOption === "support_n2"
                          ? "bg-[#53bdeb]/20 border-[#53bdeb] text-white ring-1 ring-[#53bdeb]"
                          : "bg-[#111b21] hover:bg-[#202c33] active:bg-[#2a3942] border-[#2a3942] hover:border-[#53bdeb]/60 text-[#e9edef]"
                      }`}
                    >
                      <div className="flex items-center gap-2 min-w-0">
                        <div className="p-1.5 rounded-lg bg-[#53bdeb]/20 text-[#53bdeb] shrink-0 group-hover:scale-105 transition-transform">
                          <Wrench className="w-4 h-4" />
                        </div>
                        <div className="min-w-0">
                          <div className="text-xs font-bold truncate group-hover:text-[#53bdeb] transition-colors">
                            Suporte Técnico N2
                          </div>
                          <div className="text-[10px] text-[#8696a0] truncate">
                            Chamados e configurações
                          </div>
                        </div>
                      </div>
                      <ChevronRight className="w-3.5 h-3.5 text-[#8696a0] group-hover:text-[#53bdeb] group-hover:translate-x-0.5 transition-all shrink-0" />
                    </button>

                    {/* Botão Financeiro */}
                    <button
                      type="button"
                      onClick={() => handleSelectOption("financial")}
                      className={`p-2.5 rounded-xl border text-left flex items-center justify-between gap-2 transition-all cursor-pointer shadow-sm group ${
                        selectedOption === "financial"
                          ? "bg-[#ffd279]/20 border-[#ffd279] text-white ring-1 ring-[#ffd279]"
                          : "bg-[#111b21] hover:bg-[#202c33] active:bg-[#2a3942] border-[#2a3942] hover:border-[#ffd279]/60 text-[#e9edef]"
                      }`}
                    >
                      <div className="flex items-center gap-2 min-w-0">
                        <div className="p-1.5 rounded-lg bg-[#ffd279]/20 text-[#ffd279] shrink-0 group-hover:scale-105 transition-transform">
                          <CreditCard className="w-4 h-4" />
                        </div>
                        <div className="min-w-0">
                          <div className="text-xs font-bold truncate group-hover:text-[#ffd279] transition-colors">
                            Financeiro & Cobrança
                          </div>
                          <div className="text-[10px] text-[#8696a0] truncate">
                            Boletos, faturas e 2ª via
                          </div>
                        </div>
                      </div>
                      <ChevronRight className="w-3.5 h-3.5 text-[#8696a0] group-hover:text-[#ffd279] group-hover:translate-x-0.5 transition-all shrink-0" />
                    </button>

                    {/* Botão Falar com Atendente Humano */}
                    <button
                      type="button"
                      onClick={() => onSendQuickMessage("Gostaria de falar com um atendente humano.")}
                      className="p-2.5 rounded-xl border text-left flex items-center justify-between gap-2 transition-all cursor-pointer shadow-sm group bg-[#111b21] hover:bg-[#202c33] active:bg-[#2a3942] border-[#2a3942] hover:border-[#00a884]/60 text-[#e9edef] sm:col-span-3"
                    >
                      <div className="flex items-center gap-2 min-w-0">
                        <div className="p-1.5 rounded-lg bg-[#00a884]/20 text-[#00a884] shrink-0 group-hover:scale-105 transition-transform">
                          <User className="w-4 h-4" />
                        </div>
                        <div className="min-w-0">
                          <div className="text-xs font-bold truncate group-hover:text-[#00a884] transition-colors">
                            🧑‍💼 Falar com Atendente Humano
                          </div>
                          <div className="text-[10px] text-[#8696a0] truncate">
                            Transferir para fila de atendimento direto com nosso time especializado
                          </div>
                        </div>
                      </div>
                      <ChevronRight className="w-3.5 h-3.5 text-[#8696a0] group-hover:text-[#00a884] group-hover:translate-x-0.5 transition-all shrink-0" />
                    </button>
                  </div>
                </div>
              )}

              {/* Interactive Attendance Rating Card */}
              {isAssistant && (msg.showRatingCard || msg.ratingData) && (
                <div className="mt-3 pt-3 border-t border-[#2a3942]/80 space-y-3">
                  <div className="p-3.5 rounded-2xl bg-[#111b21] border border-[#2a3942] shadow-md space-y-3">
                    <div className="flex items-center gap-2">
                      <div className="p-1.5 rounded-xl bg-amber-500/20 text-amber-400">
                        <Star className="w-4 h-4 fill-amber-400" />
                      </div>
                      <div>
                        <h4 className="text-xs font-bold text-white">
                          {msg.ratingData ? "Avaliação Registrada" : "Avaliação de Atendimento"}
                        </h4>
                        <p className="text-[10px] text-[#8696a0]">
                          {msg.ratingData
                            ? "Muito obrigado pelo seu feedback!"
                            : "Sua opinião é fundamental para mantermos a excelência do suporte"}
                        </p>
                      </div>
                    </div>

                    {/* Star selection */}
                    <div className="flex items-center justify-center gap-1.5 py-1">
                      {[1, 2, 3, 4, 5].map((starVal) => {
                        const isSelected = (msg.ratingData ? msg.ratingData.stars : selectedStars) >= starVal;
                        return (
                          <button
                            key={starVal}
                            type="button"
                            disabled={Boolean(msg.ratingData || submittedRating)}
                            onClick={() => setSelectedStars(starVal)}
                            className={`p-1.5 rounded-xl transition-all ${
                              msg.ratingData || submittedRating
                                ? "cursor-default"
                                : "hover:scale-125 cursor-pointer"
                            }`}
                            title={`${starVal} Estrela${starVal > 1 ? "s" : ""}`}
                          >
                            <Star
                              className={`w-6 h-6 transition-colors ${
                                isSelected
                                  ? "text-amber-400 fill-amber-400 drop-shadow-[0_0_8px_rgba(251,191,36,0.5)]"
                                  : "text-[#3b4a54] hover:text-[#8696a0]"
                              }`}
                            />
                          </button>
                        );
                      })}
                    </div>

                    {/* Star Label */}
                    <div className="text-center text-[11px] font-semibold text-amber-300">
                      {(msg.ratingData?.stars || selectedStars) === 5 && "⭐⭐⭐⭐⭐ Excelente! Atendimento impecável."}
                      {(msg.ratingData?.stars || selectedStars) === 4 && "⭐⭐⭐⭐ Muito Bom! Fiquei satisfeito."}
                      {(msg.ratingData?.stars || selectedStars) === 3 && "⭐⭐⭐ Regular. Atendimento normal."}
                      {(msg.ratingData?.stars || selectedStars) === 2 && "⭐⭐ Ruim. Precisa melhorar."}
                      {(msg.ratingData?.stars || selectedStars) === 1 && "⭐ Muito Insatisfeito."}
                    </div>

                    {!msg.ratingData && !submittedRating && (
                      <>
                        {/* Quick compliment tags */}
                        <div className="space-y-1">
                          <span className="text-[10px] text-[#8696a0] font-medium">O que você achou? (opcional)</span>
                          <div className="flex flex-wrap gap-1.5">
                            {[
                              "⚡ Rápido e Eficiente",
                              "👏 Muito Atencioso",
                              "✅ Problema Resolvido",
                              "💡 Explicação Clara",
                            ].map((tag) => {
                              const active = selectedTags.includes(tag);
                              return (
                                <button
                                  key={tag}
                                  type="button"
                                  onClick={() => {
                                    setSelectedTags((prev) =>
                                      active ? prev.filter((t) => t !== tag) : [...prev, tag]
                                    );
                                  }}
                                  className={`px-2 py-1 rounded-lg text-[10px] font-medium border transition-all ${
                                    active
                                      ? "bg-[#00a884]/20 border-[#00a884] text-[#00a884]"
                                      : "bg-[#182229] border-[#2a3942] text-[#8696a0] hover:text-[#e9edef]"
                                  }`}
                                >
                                  {tag}
                                </button>
                              );
                            })}
                          </div>
                        </div>

                        {/* Optional text feedback */}
                        <textarea
                          rows={2}
                          value={ratingComment}
                          onChange={(e) => setRatingComment(e.target.value)}
                          placeholder="Deixe um comentário sobre o atendimento (opcional)..."
                          className="w-full bg-[#182229] text-[#e9edef] placeholder-[#8696a0] text-xs p-2 rounded-xl border border-[#2a3942] focus:border-[#00a884] focus:outline-none resize-none"
                        />

                        {/* Submit Button */}
                        <button
                          type="button"
                          onClick={handleSubmitEvaluation}
                          className="w-full py-2 bg-[#00a884] hover:bg-[#029070] active:scale-[0.99] text-[#111b21] font-bold text-xs rounded-xl shadow-md transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                        >
                          <Check className="w-3.5 h-3.5 stroke-[3]" />
                          <span>Enviar Avaliação</span>
                        </button>
                      </>
                    )}

                    {(msg.ratingData || submittedRating) && (
                      <div className="text-center py-1 text-xs text-[#00a884] font-semibold flex items-center justify-center gap-1">
                        <Check className="w-4 h-4" />
                        <span>Avaliação enviada com sucesso! Obrigado!</span>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Copy Email Server Parameters button if applicable */}
              {isAssistant && hasEmailParams && (
                <div className="mt-2.5 pt-2 border-t border-[#2a3942]/60 flex flex-wrap items-center gap-1.5">
                  <button
                    onClick={() =>
                      handleCopy(
                        `Servidor IMAP: imap.combr.com.br (Porta 993 SSL/TLS)\nServidor SMTP: smtp.combr.com.br (Porta 465 SSL/TLS ou 587 STARTTLS)\nServidor POP3: pop.combr.com.br (Porta 995 SSL/TLS)\nWebmail: https://webmail.combr.com.br`,
                        `params-${msg.id}`
                      )
                    }
                    className="px-2.5 py-1 rounded bg-[#111b21] hover:bg-[#2a3942] text-[#00a884] text-[11px] font-medium border border-[#2a3942] flex items-center gap-1 transition-colors"
                  >
                    <Copy className="w-3 h-3" />
                    <span>{copiedId === `params-${msg.id}` ? "Copiado!" : "Copiar Portas & Servidores"}</span>
                  </button>
                </div>
              )}

              {/* Bottom Footer: Timestamp & Read Status & Accessibility Listen Button */}
              <div className="flex items-center justify-between gap-2 mt-1 text-[10px] text-[#8696a0] select-none">
                {isAssistant && !msg.isAudio ? (
                  <button
                    type="button"
                    onClick={() => handleToggleSpeakMessage(msg)}
                    className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full transition-all text-[10px] font-medium ${
                      speakingMessageId === msg.id
                        ? "text-[#111b21] bg-[#00a884] shadow-sm animate-pulse"
                        : "text-[#8696a0] hover:text-[#00a884] hover:bg-[#111b21]/70"
                    }`}
                    title={
                      speakingMessageId === msg.id
                        ? "Parar narração em voz alta"
                        : "Ouvir esta mensagem em voz alta (Acessibilidade)"
                    }
                  >
                    {speakingMessageId === msg.id ? (
                      <>
                        <Square className="w-2.5 h-2.5 fill-current" />
                        <span>Parar áudio</span>
                      </>
                    ) : (
                      <>
                        <Volume2 className="w-3 h-3 text-[#00a884]" />
                        <span>Ouvir</span>
                      </>
                    )}
                  </button>
                ) : (
                  <div />
                )}

                <div className="flex items-center gap-1">
                  <span>{formatTime(msg.timestamp)}</span>
                  {!isAssistant && !isSystem && (
                    <span title="Lida" className="text-[#53bdeb]">
                      <CheckCheck className="w-3.5 h-3.5 inline" />
                    </span>
                  )}
                </div>
              </div>

              {/* Display Reaction Badge if any */}
              {currentReaction && (
                <div className="absolute -bottom-2 right-3 bg-[#233138] border border-[#2a3942] rounded-full px-1.5 py-0.5 text-xs shadow-md animate-scale-in">
                  {currentReaction}
                </div>
              )}
            </div>

            {/* Quick Emoji Reaction Popover on Hover (Desktop) */}
            <div
              className={`absolute top-0 opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-1 bg-[#233138] border border-[#2a3942] rounded-full px-2 py-1 shadow-lg z-10 ${
                isAssistant ? "left-full ml-2" : "right-full mr-2"
              }`}
            >
              {["👍", "❤️", "👏", "💡", "🔥"].map((emoji) => (
                <button
                  key={emoji}
                  onClick={() => handleAddReaction(msg.id, emoji)}
                  className="hover:scale-125 transition-transform text-xs p-0.5"
                  title={`Reagir com ${emoji}`}
                >
                  {emoji}
                </button>
              ))}
              <button
                onClick={() => handleCopy(msg.content, msg.id)}
                className="text-[#8696a0] hover:text-[#e9edef] p-0.5 text-xs ml-1 border-l border-[#2a3942] pl-1"
                title="Copiar mensagem"
              >
                {isCopied ? <Check className="w-3 h-3 text-[#00a884]" /> : <Copy className="w-3 h-3" />}
              </button>
            </div>
          </div>
        );
      })}

      {/* Dynamic WhatsApp Typing Bubble */}
      {loading && (
        <div className="flex justify-start pt-1 pb-1 animate-in fade-in slide-in-from-bottom-2 duration-200">
          <div className="bg-[#202c33] text-[#e9edef] rounded-lg px-4 py-2.5 bubble-incoming shadow-md flex items-center gap-2.5 border border-[#2a3942]/60">
            <span className="text-[12px] font-medium text-[#8696a0]">ComIA digitando</span>
            <div className="flex items-center gap-1.5 h-3 px-1">
              <span className="typing-dot"></span>
              <span className="typing-dot"></span>
              <span className="typing-dot"></span>
            </div>
          </div>
        </div>
      )}

      <div ref={messagesEndRef} />
    </div>
  );
};
