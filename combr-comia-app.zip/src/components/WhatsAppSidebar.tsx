import React, { useState } from "react";
import {
  Search,
  MoreVertical,
  Pin,
  Wrench,
  Building2,
  CreditCard,
  FileText,
  Globe,
  UserPlus,
  Trash2,
  Sparkles,
  RotateCcw,
  CheckCheck,
  Check,
  Plus,
  Users,
} from "lucide-react";
import { ComIALogo } from "./ComIALogo";
import { TriageType, Ticket, WhatsAppClientChat } from "../types";

interface WhatsAppSidebarProps {
  isCustomerView?: boolean;
  activeClientId?: string;
  clients?: WhatsAppClientChat[];
  onSelectClient?: (clientId: string) => void;
  onOpenCreateClientModal?: () => void;
  onResetToDemoClients?: () => void;
  onDeleteClient?: (clientId: string) => void;
  // Legacy / fallback props
  activeChannel?: string;
  onSelectChannel?: (channelId: string) => void;
  onOpenTriage: (type: TriageType) => void;
  onToggleDrawer: () => void;
  onResetChat: () => void;
  tickets: Ticket[];
  isAiTyping: boolean;
  lastAssistantMessage?: string;
  showTickets?: boolean;
}

export const WhatsAppSidebar: React.FC<WhatsAppSidebarProps> = ({
  isCustomerView = false,
  activeClientId = "main",
  clients = [],
  onSelectClient,
  onOpenCreateClientModal,
  onResetToDemoClients,
  onDeleteClient,
  activeChannel = "main",
  onSelectChannel,
  onOpenTriage,
  onToggleDrawer,
  onResetChat,
  tickets = [],
  isAiTyping,
}) => {
  const [searchQuery, setSearchQuery] = useState("");
  const [filterCategory, setFilterCategory] = useState<
    "all" | "unread" | "support_n2" | "commercial" | "financial" | "tickets"
  >("all");
  const [sidebarMenuOpen, setSidebarMenuOpen] = useState(false);

  const effectiveActiveId = activeClientId || activeChannel;

  // Handle client selection
  const handleItemClick = (id: string) => {
    if (id === "tickets") {
      if (onSelectChannel) onSelectChannel("tickets");
    } else {
      if (onSelectClient) {
        onSelectClient(id);
      } else if (onSelectChannel) {
        onSelectChannel(id);
      }
    }
  };

  // If in customer view, strictly only show the official ComBR account and tickets
  const sourceClients = isCustomerView
    ? clients.filter((c) => c.id === "main")
    : clients;

  // Filter clients
  const filteredClients = sourceClients.filter((c) => {
    const q = searchQuery.toLowerCase().trim();
    const matchSearch =
      !q ||
      c.name.toLowerCase().includes(q) ||
      (c.company && c.company.toLowerCase().includes(q)) ||
      (c.phone && c.phone.includes(q)) ||
      (c.lastMessage && c.lastMessage.toLowerCase().includes(q)) ||
      (c.domain && c.domain.toLowerCase().includes(q));

    if (!matchSearch) return false;

    if (filterCategory === "unread") return c.unreadCount > 0;
    if (filterCategory === "support_n2") return c.category === "support_n2";
    if (filterCategory === "commercial") return c.category === "commercial";
    if (filterCategory === "financial") return c.category === "financial";
    if (filterCategory === "tickets") return false;

    return true;
  });

  const totalUnreadCount = sourceClients.reduce((acc, c) => acc + (c.unreadCount || 0), 0);

  return (
    <aside
      id="whatsapp-sidebar"
      className="w-full md:w-[380px] lg:w-[420px] h-full bg-[#111b21] border-r border-[#222e35] flex flex-col shrink-0 select-none z-10"
    >
      {/* Top Profile & Actions Header */}
      <div className="h-16 px-4 bg-[#202c33] flex items-center justify-between border-b border-[#222e35] shrink-0">
        <div className="flex items-center gap-3 cursor-pointer" onClick={onToggleDrawer}>
          <div className="relative shrink-0">
            <ComIALogo size="md" showText={false} />
            <span className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-[#00a884] border-2 border-[#202c33] rounded-full"></span>
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <h1 className="text-sm font-bold text-[#e9edef] leading-tight">ComBR Nuvem</h1>
              <span className="text-[10px] bg-[#00a884]/20 text-[#00a884] font-semibold px-1.5 py-0.2 rounded">
                Business
              </span>
            </div>
            <p className="text-[11px] text-[#8696a0] font-medium flex items-center gap-1">
              <span>{isCustomerView ? "Conta Comercial Verificada" : "WhatsApp Web Multi-Cliente"}</span>
              {totalUnreadCount > 0 && !isCustomerView && (
                <span className="w-2 h-2 rounded-full bg-[#00a884] animate-pulse"></span>
              )}
            </p>
          </div>
        </div>

        {/* Action Buttons in Header */}
        <div className="flex items-center gap-1 text-[#aebac1] relative">
          {/* Quick Add Client Button (Only for Operator / Support Desk) */}
          {!isCustomerView && onOpenCreateClientModal && (
            <button
              id="btn-sidebar-add-client"
              onClick={onOpenCreateClientModal}
              className="p-2 rounded-full bg-[#00a884]/15 text-[#00a884] hover:bg-[#00a884] hover:text-[#111b21] transition-all cursor-pointer flex items-center gap-1"
              title="Adicionar Novo Cliente & Conversa Fictícia"
            >
              <UserPlus className="w-4 h-4" />
              <span className="text-xs font-bold hidden sm:inline">Novo</span>
            </button>
          )}

          {/* Quick Demo Clients Generator (Only for Operator / Support Desk) */}
          {!isCustomerView && onResetToDemoClients && (
            <button
              onClick={onResetToDemoClients}
              className="p-2 rounded-full hover:bg-[#374248] hover:text-amber-400 transition-colors cursor-pointer"
              title="Restaurar / Gerar 5 Clientes Demonstrativos"
            >
              <Sparkles className="w-4 h-4 text-amber-400" />
            </button>
          )}

          {/* Website Link */}
          <a
            id="btn-sidebar-site"
            href="https://combr.com.br"
            target="_blank"
            rel="noopener noreferrer"
            className="p-2 rounded-full hover:bg-[#374248] hover:text-[#00a884] transition-colors"
            title="Acessar Site ComBR"
          >
            <Globe className="w-4 h-4" />
          </a>

          {/* 3-Dots Menu */}
          <div className="relative">
            <button
              id="btn-sidebar-menu"
              onClick={() => setSidebarMenuOpen(!sidebarMenuOpen)}
              className="p-2 rounded-full hover:bg-[#374248] hover:text-[#e9edef] transition-colors cursor-pointer"
              title="Menu"
            >
              <MoreVertical className="w-5 h-5" />
            </button>

            {sidebarMenuOpen && (
              <>
                <div
                  className="fixed inset-0 z-30"
                  onClick={() => setSidebarMenuOpen(false)}
                ></div>
                <div className="absolute right-0 top-11 w-60 bg-[#233138] border border-[#2a3942] rounded-xl shadow-2xl py-1.5 z-40 text-xs text-[#d1d7db] space-y-0.5 animate-in fade-in">
                  {!isCustomerView && onOpenCreateClientModal && (
                    <button
                      onClick={() => {
                        setSidebarMenuOpen(false);
                        onOpenCreateClientModal();
                      }}
                      className="w-full px-4 py-2.5 text-left hover:bg-[#182229] flex items-center gap-2.5 text-[#00a884] font-medium cursor-pointer"
                    >
                      <UserPlus className="w-4 h-4" />
                      <span>Criar Cliente Fictício</span>
                    </button>
                  )}
                  {!isCustomerView && onResetToDemoClients && (
                    <button
                      onClick={() => {
                        setSidebarMenuOpen(false);
                        onResetToDemoClients();
                      }}
                      className="w-full px-4 py-2.5 text-left hover:bg-[#182229] flex items-center gap-2.5 cursor-pointer text-amber-400"
                    >
                      <Sparkles className="w-4 h-4" />
                      <span>Gerar 5 Clientes de Exemplo</span>
                    </button>
                  )}
                  <button
                    onClick={() => {
                      setSidebarMenuOpen(false);
                      onOpenTriage("support_n2");
                    }}
                    className="w-full px-4 py-2.5 text-left hover:bg-[#182229] flex items-center gap-2.5 cursor-pointer"
                  >
                    <Wrench className="w-4 h-4 text-[#00a884]" />
                    <span>Abrir Chamado Técnico N2</span>
                  </button>
                  <button
                    onClick={() => {
                      setSidebarMenuOpen(false);
                      onToggleDrawer();
                    }}
                    className="w-full px-4 py-2.5 text-left hover:bg-[#182229] flex items-center gap-2.5 cursor-pointer"
                  >
                    <span>⚙️</span>
                    <span>Parâmetros de E-mail (IMAP/SMTP)</span>
                  </button>
                  <div className="h-px bg-[#2a3942] my-1"></div>
                  <button
                    onClick={() => {
                      setSidebarMenuOpen(false);
                      onResetChat();
                    }}
                    className="w-full px-4 py-2.5 text-left hover:bg-[#182229] flex items-center gap-2.5 text-[#f15c6d] cursor-pointer"
                  >
                    <RotateCcw className="w-4 h-4" />
                    <span>Reiniciar Chat Oficial</span>
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      </div>

      {/* WhatsApp Search Bar & Fast Actions */}
      <div className="px-3 pt-2.5 pb-2 bg-[#111b21] space-y-2 border-b border-[#222e35]">
        <div className="relative flex items-center bg-[#202c33] rounded-lg px-3 py-1.5 text-xs">
          <Search className="w-4 h-4 text-[#8696a0] mr-2.5 shrink-0" />
          <input
            id="whatsapp-search-input"
            type="text"
            placeholder={isCustomerView ? "Pesquisar nesta conversa..." : "Pesquisar clientes ou mensagens..."}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-transparent text-[#e9edef] placeholder-[#8696a0] focus:outline-none text-xs"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery("")}
              className="text-[#8696a0] hover:text-[#e9edef] text-xs px-1 cursor-pointer"
            >
              ✕
            </button>
          )}
        </div>

        {/* Filter Pills (Only shown when there are multiple contacts or open tickets) */}
        {(!isCustomerView || tickets.length > 0) && (
          <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-0.5 text-[11px]">
            {!isCustomerView && (
              <button
                onClick={() => setFilterCategory("all")}
                className={`px-2.5 py-1 rounded-full whitespace-nowrap transition-colors cursor-pointer ${
                  filterCategory === "all"
                    ? "bg-[#00a884]/20 text-[#00a884] font-medium border border-[#00a884]/40"
                    : "bg-[#202c33] text-[#8696a0] hover:text-[#e9edef]"
                }`}
              >
                Todas ({sourceClients.length})
              </button>
            )}

            {!isCustomerView && (
              <>
                <button
                  onClick={() => setFilterCategory("unread")}
                  className={`px-2.5 py-1 rounded-full whitespace-nowrap transition-colors flex items-center gap-1 cursor-pointer ${
                    filterCategory === "unread"
                      ? "bg-[#00a884]/20 text-[#00a884] font-medium border border-[#00a884]/40"
                      : "bg-[#202c33] text-[#8696a0] hover:text-[#e9edef]"
                  }`}
                >
                  <span>Não Lidas</span>
                  {totalUnreadCount > 0 && (
                    <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-[#00a884] text-[#111b21] font-bold">
                      {totalUnreadCount}
                    </span>
                  )}
                </button>

                <button
                  onClick={() => setFilterCategory("support_n2")}
                  className={`px-2.5 py-1 rounded-full whitespace-nowrap transition-colors cursor-pointer ${
                    filterCategory === "support_n2"
                      ? "bg-[#00a884]/20 text-[#00a884] font-medium border border-[#00a884]/40"
                      : "bg-[#202c33] text-[#8696a0] hover:text-[#e9edef]"
                  }`}
                >
                  🛠️ Suporte N2
                </button>

                <button
                  onClick={() => setFilterCategory("commercial")}
                  className={`px-2.5 py-1 rounded-full whitespace-nowrap transition-colors cursor-pointer ${
                    filterCategory === "commercial"
                      ? "bg-[#00a884]/20 text-[#00a884] font-medium border border-[#00a884]/40"
                      : "bg-[#202c33] text-[#8696a0] hover:text-[#e9edef]"
                  }`}
                >
                  💼 Comercial
                </button>

                <button
                  onClick={() => setFilterCategory("financial")}
                  className={`px-2.5 py-1 rounded-full whitespace-nowrap transition-colors cursor-pointer ${
                    filterCategory === "financial"
                      ? "bg-[#00a884]/20 text-[#00a884] font-medium border border-[#00a884]/40"
                      : "bg-[#202c33] text-[#8696a0] hover:text-[#e9edef]"
                  }`}
                >
                  💳 Financeiro
                </button>
              </>
            )}

            {tickets.length > 0 && (
              <button
                onClick={() => handleItemClick("tickets")}
                className={`px-2.5 py-1 rounded-full whitespace-nowrap transition-colors flex items-center gap-1 cursor-pointer ${
                  effectiveActiveId === "tickets"
                    ? "bg-[#a855f7]/20 text-[#c084fc] font-medium border border-[#a855f7]/40"
                    : "bg-[#202c33] text-[#8696a0] hover:text-[#e9edef]"
                }`}
              >
                <span>Chamados ({tickets.length})</span>
              </button>
            )}
          </div>
        )}
      </div>

      {/* Client List (Like WhatsApp Web) */}
      <div id="whatsapp-channels-list" className="flex-1 overflow-y-auto divide-y divide-[#222e35]/60">
        {/* Ticket Protocol Central Item (if tickets exist) */}
        {tickets.length > 0 && filterCategory === "all" && (
          <div
            onClick={() => handleItemClick("tickets")}
            className={`px-3 py-3 flex items-center gap-3 cursor-pointer transition-colors duration-150 relative ${
              effectiveActiveId === "tickets" ? "bg-[#2a3942]" : "hover:bg-[#202c33]/70"
            }`}
          >
            <div className="relative shrink-0">
              <div className="w-12 h-12 rounded-full bg-[#241e38] text-[#a855f7] border border-[#a855f7]/30 flex items-center justify-center">
                <FileText className="w-5 h-5" />
              </div>
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between mb-0.5">
                <span className="text-sm font-semibold text-[#e9edef] truncate">
                  Central de Chamados ({tickets.length})
                </span>
                <span className="text-[11px] text-[#8696a0]">Ativo</span>
              </div>
              <p className="text-xs text-[#8696a0] truncate">
                {tickets[0].id} • {tickets[0].subject || "Protocolos em aberto"}
              </p>
            </div>
          </div>
        )}

        {/* Filtered Clients */}
        {filteredClients.map((client) => {
          const isActive = effectiveActiveId === client.id;
          const isOfficial = client.id === "main";
          const hasUnread = (client.unreadCount || 0) > 0;

          return (
            <div
              key={client.id}
              id={`client-item-${client.id}`}
              onClick={() => handleItemClick(client.id)}
              className={`group px-3 py-3 flex items-center gap-3 cursor-pointer transition-colors duration-150 relative ${
                isActive ? "bg-[#2a3942]" : "hover:bg-[#202c33]/70"
              }`}
            >
              {/* Client Avatar */}
              <div className="relative shrink-0">
                {isOfficial ? (
                  <div className="w-12 h-12 rounded-full bg-[#111b21] border border-[#2a3942] flex items-center justify-center overflow-hidden">
                    <ComIALogo size="md" showText={false} className="w-full h-full" />
                  </div>
                ) : (
                  <div
                    className="w-12 h-12 rounded-full flex items-center justify-center text-white font-bold text-sm shadow-inner"
                    style={{ backgroundColor: client.avatarColor || "#3b82f6" }}
                  >
                    {client.avatarInitials || client.name.slice(0, 2).toUpperCase()}
                  </div>
                )}

                {/* Online Status Dot */}
                {client.status === "online" && (
                  <span className="absolute bottom-0 right-0 w-3.5 h-3.5 bg-[#00a884] border-2 border-[#111b21] rounded-full"></span>
                )}
              </div>

              {/* Client Info & Last Message */}
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between mb-0.5">
                  <div className="flex items-center gap-1.5 min-w-0">
                    <span
                      className={`text-sm font-semibold truncate ${
                        hasUnread ? "text-white font-bold" : "text-[#e9edef]"
                      }`}
                    >
                      {client.name}
                    </span>

                    {/* Verified badge for official */}
                    {client.isVerified && (
                      <span
                        className="inline-flex items-center justify-center w-3.5 h-3.5 rounded-full bg-[#00a884] text-[#111b21] shrink-0"
                        title="Verificado"
                      >
                        <svg className="w-2 h-2 fill-current" viewBox="0 0 24 24">
                          <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z" />
                        </svg>
                      </span>
                    )}

                    {/* Department pill */}
                    {client.category && client.category !== "general" && (
                      <span
                        className={`text-[9px] font-semibold px-1.5 py-0.2 rounded-full shrink-0 ${
                          client.category === "support_n2"
                            ? "bg-blue-500/15 text-blue-400 border border-blue-500/30"
                            : client.category === "commercial"
                            ? "bg-emerald-500/15 text-emerald-400 border border-emerald-500/30"
                            : "bg-amber-500/15 text-amber-400 border border-amber-500/30"
                        }`}
                      >
                        {client.category === "support_n2"
                          ? "N2"
                          : client.category === "commercial"
                          ? "Vendas"
                          : "Financ."}
                      </span>
                    )}
                  </div>

                  {/* Timestamp */}
                  <span
                    className={`text-[11px] shrink-0 ml-2 ${
                      hasUnread ? "text-[#00a884] font-bold" : "text-[#8696a0]"
                    }`}
                  >
                    {client.lastMessageTime || "--"}
                  </span>
                </div>

                {/* Subtitle / Company tag */}
                {client.company && (
                  <p className="text-[10px] text-[#8696a0] truncate mb-0.5">
                    {client.company}
                  </p>
                )}

                {/* Message preview row */}
                <div className="flex items-center justify-between text-xs text-[#8696a0]">
                  <p
                    className={`truncate pr-2 ${
                      isOfficial && isAiTyping
                        ? "text-[#00a884] font-medium"
                        : hasUnread
                        ? "text-[#e9edef] font-medium"
                        : "text-[#8696a0]"
                    }`}
                  >
                    {isOfficial && isAiTyping ? "Digitando..." : client.lastMessage}
                  </p>

                  <div className="flex items-center gap-1.5 shrink-0">
                    {/* Delete Custom Client (on hover, except main) */}
                    {!isOfficial && onDeleteClient && (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          if (confirm(`Remover cliente "${client.name}"?`)) {
                            onDeleteClient(client.id);
                          }
                        }}
                        className="opacity-0 group-hover:opacity-100 p-1 rounded hover:bg-[#374248] text-[#8696a0] hover:text-[#f15c6d] transition-all cursor-pointer"
                        title="Excluir cliente simulado"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}

                    {client.isPinned && (
                      <Pin className="w-3.5 h-3.5 text-[#8696a0] rotate-45" />
                    )}

                    {/* Unread badge count */}
                    {hasUnread && (
                      <span className="min-w-5 h-5 px-1.5 rounded-full bg-[#00a884] text-[#111b21] font-bold text-[10px] flex items-center justify-center shadow-sm">
                        {client.unreadCount}
                      </span>
                    )}
                  </div>
                </div>
              </div>
            </div>
          );
        })}

        {filteredClients.length === 0 && (
          <div className="p-8 text-center text-[#8696a0] space-y-2">
            <Users className="w-8 h-8 mx-auto text-[#8696a0]/50" />
            <p className="text-xs">Nenhum cliente encontrado no filtro.</p>
            {onResetToDemoClients && (
              <button
                onClick={onResetToDemoClients}
                className="text-xs text-[#00a884] hover:underline font-semibold cursor-pointer"
              >
                Gerar Clientes Demonstrativos
              </button>
            )}
          </div>
        )}
      </div>

      {/* Bottom Footer Info & Quick Generator */}
      <div className="p-2.5 bg-[#111b21] border-t border-[#222e35] flex items-center justify-between text-[11px] text-[#8696a0]">
        <div className="flex items-center gap-1.5 truncate">
          <span className="w-2 h-2 rounded-full bg-[#00a884] animate-pulse shrink-0"></span>
          <span className="truncate">
            {isCustomerView
              ? "ComIA Online • Atendimento Oficial"
              : `${sourceClients.length} clientes carregados`}
          </span>
        </div>

        {!isCustomerView && onOpenCreateClientModal ? (
          <button
            onClick={onOpenCreateClientModal}
            className="text-[#00a884] hover:underline font-semibold flex items-center gap-1 cursor-pointer shrink-0"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Criar Cliente</span>
          </button>
        ) : (
          <button
            onClick={onToggleDrawer}
            className="text-[#00a884] hover:underline font-semibold cursor-pointer shrink-0"
          >
            Ver Parâmetros
          </button>
        )}
      </div>
    </aside>
  );
};
