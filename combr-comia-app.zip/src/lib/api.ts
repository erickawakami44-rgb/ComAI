import { Ticket } from "../types";
import { generateClientComIaResponse } from "./comiaEngine";

const API_BASE = (import.meta.env.VITE_API_URL || "").replace(/\/$/, "");
const LOCAL_STORAGE_TICKETS_KEY = "combr_tickets_db";

function getLocalStoredTickets(): Ticket[] {
  try {
    const raw = localStorage.getItem(LOCAL_STORAGE_TICKETS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        return parsed;
      }
    }
  } catch (err) {
    console.warn("[LocalTickets] Error reading tickets:", err);
  }
  return [];
}

function saveLocalStoredTickets(tickets: Ticket[]) {
  try {
    localStorage.setItem(LOCAL_STORAGE_TICKETS_KEY, JSON.stringify(tickets));
  } catch (err) {
    console.warn("[LocalTickets] Error saving tickets:", err);
  }
}

export async function requestComIaChat(payload: {
  message: string;
  history: Array<{ role: string; content: string }>;
  image?: {
    dataUrl?: string;
    fileName?: string;
    caption?: string;
  };
  audio?: {
    dataUrl?: string;
    dataBase64?: string;
    mimeType?: string;
    transcript?: string;
  };
  document?: {
    name: string;
    size?: string;
    type?: string;
    dataBase64?: string;
    dataUrl?: string;
    textContent?: string;
    caption?: string;
    mimeType?: string;
  };
}): Promise<{ reply: string; source: string }> {
  // Try up to 2 attempts to ensure Gemini generates the response cleanly
  for (let attempt = 1; attempt <= 2; attempt++) {
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 35000);

      const res = await fetch(`${API_BASE}/api/chat`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
        signal: controller.signal,
      });

      clearTimeout(timeoutId);

      if (res.ok) {
        const data = await res.json();
        if (data && typeof data.reply === "string" && data.reply.trim().length > 0) {
          return { reply: data.reply, source: data.source || "gemini" };
        }
      } else {
        const errText = await res.text().catch(() => "");
        console.warn(`[ComIA API] Tentativa ${attempt} retornou status ${res.status}:`, errText);
      }
    } catch (err) {
      console.warn(`[ComIA API] Tentativa ${attempt} falhou na requisição:`, err);
    }
  }

  // Fallback to client-side autonomous ComIA engine if backend server is completely unreachable
  const localReply = generateClientComIaResponse(payload.message, payload.history, {
    imageAttachment: payload.image
      ? {
          url: payload.image.dataUrl,
          fileName: payload.image.fileName,
          caption: payload.image.caption,
        }
      : undefined,
  });

  return { reply: localReply, source: "comia-client-engine" };
}

export async function fetchRemoteTickets(): Promise<Ticket[]> {
  try {
    const res = await fetch(`${API_BASE}/api/tickets`);
    if (res.ok) {
      const data = await res.json();
      if (Array.isArray(data.tickets)) {
        // Cache in localStorage
        saveLocalStoredTickets(data.tickets);
        return data.tickets;
      }
    }
  } catch (err) {
    console.warn("[Tickets] Não foi possível carregar chamados da API, usando cache local:", err);
  }

  return getLocalStoredTickets();
}

export async function createRemoteOrLocalTicket(ticketData: any): Promise<Ticket> {
  try {
    const res = await fetch(`${API_BASE}/api/ticket`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(ticketData),
    });

    if (res.ok) {
      const data = await res.json();
      if (data.ticket) {
        const local = getLocalStoredTickets();
        saveLocalStoredTickets([...local.filter((t) => t.id !== data.ticket.id), data.ticket]);
        return data.ticket;
      }
    }
  } catch (err) {
    console.warn("[Tickets] API /api/ticket offline, gerando protocolo local resiliente:", err);
  }

  // Generate autonomous resilient ticket locally
  const prefix =
    ticketData.type === "support_n2"
      ? "CBR-N2"
      : ticketData.type === "financial"
      ? "CBR-FIN"
      : "CBR-COM";
  const uniqueCode = Math.random().toString(36).substring(2, 8).toUpperCase();
  const ticketId = `${prefix}-${uniqueCode}-${Math.floor(100 + Math.random() * 900)}`;

  const localTicket: Ticket = {
    id: ticketId,
    type: ticketData.type,
    domain: ticketData.domain,
    cnpjOrCorporateName: ticketData.cnpjOrCorporateName,
    companyName: ticketData.companyName,
    contactName: ticketData.contactName,
    phone: ticketData.phone,
    email: ticketData.email,
    subject: ticketData.subject,
    affectedEmail: ticketData.affectedEmail,
    errorMessage: ticketData.errorMessage,
    approxAccountsOrResources: ticketData.approxAccountsOrResources,
    attachmentImage: ticketData.attachmentImage,
    attachmentDocument: ticketData.attachmentDocument,
    status: "not_started",
    createdAt: new Date().toISOString(),
  };

  const currentTickets = getLocalStoredTickets();
  saveLocalStoredTickets([...currentTickets, localTicket]);
  return localTicket;
}

export async function updateRemoteOrLocalTicketStatus(
  ticketId: string,
  status: Ticket["status"]
): Promise<void> {
  // Update local storage
  const current = getLocalStoredTickets();
  const updated = current.map((t) => (t.id === ticketId ? { ...t, status, updatedAt: new Date().toISOString() } : t));
  saveLocalStoredTickets(updated);

  try {
    await fetch(`${API_BASE}/api/tickets/${ticketId}/status`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status }),
    });
  } catch (err) {
    console.warn("[Tickets] Falha ao sincronizar status com servidor:", err);
  }
}

export async function deleteRemoteOrLocalTicket(ticketId: string): Promise<void> {
  const current = getLocalStoredTickets();
  saveLocalStoredTickets(current.filter((t) => t.id !== ticketId));

  try {
    await fetch(`${API_BASE}/api/tickets/${ticketId}`, {
      method: "DELETE",
    });
  } catch (err) {
    console.warn("[Tickets] Falha ao sincronizar exclusão com servidor:", err);
  }
}

export async function syncDeletedIdsToServer(deletedIds: string[]): Promise<void> {
  if (deletedIds.length === 0) return;
  try {
    await fetch(`${API_BASE}/api/tickets/sync-deleted`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ deletedIds }),
    });
  } catch (err) {
    // Silent fail
  }
}
