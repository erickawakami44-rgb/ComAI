// Autonomous ComIA Client-Side Knowledge Base & Fallback Engine
// Ensures 100% availability even if backend /api/chat is unreachable, offline, or hosted statically

export function detectGreetingAndReply(prompt: string): string | null {
  const lower = prompt.toLowerCase().trim();
  const clean = lower
    .replace(/[^\w\s\u00C0-\u00FF]/g, " ")
    .replace(/\s+/g, " ")
    .trim();

  // Words that indicate technical or specific business intent - if present, proceed to specific technical handling
  const technicalWords = [
    "servidor", "email", "e-mail", "senha", "boleto", "fatura", "preco", "preço", "valor",
    "plano", "contratar", "nuvem", "cloud", "vps", "suporte", "erro", "problema",
    "configurar", "outlook", "chamado", "abrir", "site", "webmail", "ramal", "telefone",
    "dns", "porta", "login", "cnpj", "backup", "savedata", "comprar", "orcamento", "orçamento",
    "cpanel", "antispam", "migracao", "migração", "nota fiscal"
  ];

  const hasTechnical = technicalWords.some((w) => clean.includes(w));
  if (hasTechnical) {
    return null;
  }

  // Greeting patterns: handles "olá boa noite, tudo bem?", "oi boa tarde", "bom dia!", "tudo bem?", etc.
  const isGreeting =
    /^(oi|ol[aá]|opa|ei|salve|hello|hi|e a[ií])(\s+(comia|combr|amigo|amiga|equipe|time|pessoal))?(\s+(bom dia|boa tarde|boa noite))?(\s+(tudo bem|tudo bom|como vai|como voc[eê] est[aá]|beleza|tranquilo))?$/i.test(clean) ||
    /^(bom dia|boa tarde|boa noite)(\s+(comia|combr|amigo|amiga|equipe|time|pessoal))?(\s+(tudo bem|tudo bom|como vai|como voc[eê] est[aá]|beleza|tranquilo))?$/i.test(clean) ||
    /^(tudo bem|tudo bom|como vai|como voc[eê] est[aá]|beleza)(\s+com\s+voc[eê])?$/i.test(clean) ||
    /^(oi|ol[aá]|opa|ei|bom dia|boa tarde|boa noite)\s*,\s*(tudo bem|tudo bom|como vai|como voc[eê] est[aá]|beleza)/i.test(clean) ||
    /^(oi|ol[aá]|opa|ei)\s+(bom dia|boa tarde|boa noite)/i.test(clean);

  if (!isGreeting) {
    return null;
  }

  const hasBoaNoite = /boa noite/i.test(clean);
  const hasBoaTarde = /boa tarde/i.test(clean);
  const hasBomDia = /bom dia/i.test(clean);
  const askedTudoBem = /tudo bem|tudo bom|como vai|como voc[eê] est[aá]|beleza|tranquilo/i.test(clean);

  let greetingWord = "Olá";
  if (hasBoaNoite) {
    greetingWord = "Boa noite";
  } else if (hasBoaTarde) {
    greetingWord = "Boa tarde";
  } else if (hasBomDia) {
    greetingWord = "Bom dia";
  } else {
    const now = new Date();
    const currentHourStr = now.toLocaleTimeString("pt-BR", {
      timeZone: "America/Sao_Paulo",
      hour: "2-digit",
      hour12: false,
    });
    const currentHour = parseInt(currentHourStr, 10);
    if (currentHour >= 5 && currentHour < 12) {
      greetingWord = "Bom dia";
    } else if (currentHour >= 12 && currentHour < 18) {
      greetingWord = "Boa tarde";
    } else {
      greetingWord = "Boa noite";
    }
  }

  if (askedTudoBem) {
    return `${greetingWord}. Tudo bem por aqui, obrigado por perguntar. Sou a ComIA, assistente virtual da ComBr Soluções em Nuvem. Em que posso auxiliá-lo hoje?`;
  }

  return `${greetingWord}. Sou a ComIA, assistente virtual da ComBr Soluções em Nuvem. Como posso auxiliá-lo hoje?`;
}

export function generateClientComIaResponse(
  userPrompt: string,
  history: Array<{ role: string; content: string }> = [],
  mediaData?: {
    imageAttachment?: {
      url?: string;
      fileName?: string;
      caption?: string;
    };
  }
): string {
  // If user attached an image / print screenshot
  if (mediaData?.imageAttachment) {
    return generateImageClientResponse(
      mediaData.imageAttachment.fileName || "print.png",
      mediaData.imageAttachment.caption || "",
      userPrompt
    );
  }

  // 0. Handle natural greetings (e.g. "olá boa noite, tudo bem?", "oi", "bom dia") warmly and politely
  const greetingReply = detectGreetingAndReply(userPrompt);
  if (greetingReply) {
    return greetingReply;
  }

  const lower = userPrompt.toLowerCase().trim();

  // 0.05 E-commerce / Lojas Virtuais (A ComBr NÃO desenvolve lojas virtuais, mas hospeda servidores e SMTP)
  if (/e-?commerce|loja virtual|loja online|lojas virtuais|carrinho de compras|woocommerce|shopify|magento|nuvemshop|vtex|plataforma de vendas/i.test(lower)) {
    return `A ComBr **não atua no desenvolvimento, criação ou gestão de lojas virtuais (e-commerce)** nem no cadastro de produtos ou vitrines online.\n\nO nosso foco é 100% voltado para a **infraestrutura corporativa de TI de alta disponibilidade**:\n• **Servidores em Nuvem de Alta Performance (Cloud AWS, Oracle OCI e VPS Linux):** Caso a sua empresa já tenha desenvolvedores ou utilize uma plataforma de e-commerce e precise de um ambiente dedicado, com escalabilidade de tráfego, discos NVMe rápidos e banco de dados de alto desempenho para hospedar a loja com segurança;\n• **SMTP Envios Empresarial:** Infraestrutura de relay dedicada para disparo em massa de e-mails transacionais (confirmação de pedidos, status de entrega e envio de XML/DANFE de notas fiscais NF-e), garantindo entrega na caixa de entrada sem cair na caixa de spam;\n• **SaveData (Backup Imutável):** Proteção contínua e cópias automáticas em nuvem contra ransomware para o banco de dados e arquivos do seu comércio eletrônico.\n\n💡 **Como você prefere prosseguir?**\n• Se você se interessou sobre nossa infraestrutura de servidores em nuvem ou SMTP para o seu e-commerce e quer solicitar uma proposta sob medida, envie para o **Comercial / Financeiro**!\n• Se preferir tirar dúvidas técnicas sobre requisitos, portas ou sustentação com nossa equipe, entre em contato com nosso time de **Suporte Técnico Especializado**.\n\nVocê gostaria de enviar para o Comercial/Financeiro ou falar com o Suporte?`;
  }

  // 0.06 Aplicativos móveis / Fábrica de software / Sistemas customizados
  if (/aplicativos?|app para celular|apps? m[oó]ve[li]s?|desenvolvimento de app|desenvolver app|f[aá]brica de software|desenvolvimento de software|criar sistema|programar sistema|criar aplicativo|softwares? personalizados?/i.test(lower)) {
    return `A ComBr **não atua como fábrica de software nem no desenvolvimento de aplicativos móveis (Android/iOS) ou softwares personalizados**.\n\nNossa especialidade é fornecer a **infraestrutura de sustentação e nuvem corporativa (Cloud AWS, Oracle OCI e VPS Linux)** para hospedar as APIs, bancos de dados (Oracle e MySQL) e servidores que o seu aplicativo ou sistema necessita para rodar 24x7 com SLA de 99,9%. Também desenvolvemos páginas corporativas de alta conversão através do serviço **OnePage Pro**.\n\n💡 **Como você prefere prosseguir?**\n• Se você precisa de infraestrutura em nuvem, VPS ou banco de dados para sustentar seu aplicativo ou sistema, envie para o **Comercial / Financeiro** para uma cotação sob medida!\n• Se preferir tirar dúvidas técnicas sobre arquitetura com nossa equipe, fale com o **Suporte Técnico Especializado**.\n\nVocê gostaria de enviar para o Comercial/Financeiro ou falar com o Suporte?`;
  }

  // 0.07 Venda de hardware / Computadores / Peças
  if (/venda de computador|vende computador|computador|computadores|notebook|notebooks|pe[çc]as? de computad|venda de pe[çc]a|vende pe[çc]a|vende notebook|venda de notebook|venda de servidor f[íi]sico|hardware f[íi]sico/i.test(lower)) {
    return `A ComBr **não realiza venda de peças de hardware, computadores físicos, notebooks ou servidores locais**.\n\nNosso modelo de atuação é 100% focado em **computação em nuvem (Cloud Computing)**, servidores virtuais dedicados gerenciados (VPS Linux, Cloud AWS e Oracle Cloud), backup corporativo SaveData e e-mail corporativo. A grande vantagem é que sua empresa não precisa investir em hardware físico caro nem se preocupar com manutenção de peças locais: toda a infraestrutura roda em nuvem com alta disponibilidade e suporte gerenciado.\n\n💡 **Como você prefere prosseguir?**\n• Se você deseja dimensionar um servidor em nuvem sob medida para substituir servidores físicos na sua empresa, envie para o **Comercial / Financeiro**!\n• Se preferir tirar dúvidas técnicas de migração, fale com nosso time de **Suporte Técnico Especializado**.\n\nVocê gostaria de enviar para o Comercial/Financeiro ou falar com o Suporte?`;
  }

  // 0.08 Marketing Digital / Gestão de Tráfego / Redes Sociais
  if (/marketing digital|redes sociais|gest[ãa]o de tr[aá]fego|tr[aá]fego pago|google ads|an[uú]ncios no instagram|ag[eê]ncia de marketing/i.test(lower)) {
    return `A ComBr **não é uma agência de marketing digital, gestão de redes sociais ou tráfego pago**.\n\nNossa atuação é estritamente em **tecnologia corporativa de missão crítica**: servidores em nuvem (AWS e Oracle OCI), VPS Linux Gerenciada com NOC 24x7, e-mail profissional, e-mail híbrido com Microsoft 365, backup seguro contra ransomware (SaveData) e SMTP dedicado para notas fiscais.\n\nPara consultar propostas ou suporte, selecione a opção desejada logo abaixo.`;
  }

  // 0.09 Internet Residencial / Fibra Óptica Doméstica / Celular
  if (/internet residencial|fibra residencial|internet para casa|plano de celular|chip de celular|telefonia celular/i.test(lower)) {
    return `A ComBr **não comercializa planos de internet residencial (fibra óptica doméstica) nem chips ou planos de telefonia móvel celular**.\n\nSomos especializados exclusivamente em **infraestrutura corporativa B2B**: ambientes de nuvem pública e privada, servidores VPS gerenciados, e-mail corporativo institucional e segurança de dados para empresas em todo o Brasil.`;
  }

  // 0.10 Pessoa Física / CPF / Particular
  if (/pessoa f[íi]sica|atendem cpf|atende cpf|posso contratar no cpf|atendem particular|atende pessoa f[íi]sica/i.test(lower)) {
    return `A ComBr é focada prioritariamente no mercado **B2B (empresas e pessoas jurídicas com CNPJ)** que necessitam de soluções de missão crítica, e-mail institucional com domínio próprio (@suaempresa.com.br), servidores em nuvem e políticas de backup contra ransomware.\n\nPara avaliar a viabilidade da contratação do seu projeto, selecione **Enviar para o Comercial** logo abaixo.`;
  }

  // 0.11 ERPs (Totvs, Protheus, SAP, Senior, etc.)
  if (/totvs|protheus|sap|senior sistemas|datasul|linx|sankhya|suportam erp|hospedam erp|servidor para erp/i.test(lower)) {
    return `Sim! Somos especialistas na **sustentação de infraestrutura em nuvem para ERPs corporativos** (Totvs Protheus, RM, Datasul, SAP Business One, Senior Sistemas, Linx, Sankhya) com ambientes em Cloud AWS e Oracle Cloud (OCI) com SLA de 99,9% e faturamento nacional em Real (BRL).\n\nPara dimensionar seu ambiente ou falar com a equipe técnica, basta selecionar **Enviar para o Comercial** ou **Falar com Suporte Técnico** logo abaixo.`;
  }

  // 0.12 Criação de Sites / OnePage Pro / Hospedagem WordPress
  if (/fazem site|faz site|criam site|cria site|desenvolve site|desenvolvem site|onepage|wordpress|hospedagem de site|hospedar site/i.test(lower)) {
    return `Sim! Desenvolvemos páginas corporativas de alta conversão através do serviço **OnePage Pro**, além de fornecermos hospedagem corporativa para WordPress e registro de domínios.\n\nPara solicitar um orçamento ou tirar dúvidas, selecione **Enviar para o Comercial** logo abaixo.`;
  }

  // 0.13 Inquiries about whether ComBr does / offers X ("vocês trabalham com X?", "vocês fazem X?")
  const workWithMatch = lower.match(/(?:voc[eê]s|a\s+combr|a\s+empresa)?\s*(?:trabalham|fazem|oferecem|prestam|atuam|vendem|tem|possuem|desenvolvem|criam|constroem)\s+(?:com\s+)?([a-z0-9\s\-_]+)/i);
  if (workWithMatch && workWithMatch[1]) {
    const queriedTopic = workWithMatch[1].trim();
    const matchesCatalog = /nuvem|cloud|vps|servidor|e-?mail|smtp|backup|savedata|savemail|oracle|mysql|banco de dados|dba|onepage|site|dom[íi]nio|hospedagem/i.test(queriedTopic);
    if (matchesCatalog) {
      return `Sim! Trabalhamos com ${queriedTopic}.\n\nPara propostas comerciais ou atendimento com nossa equipe, selecione **Enviar para o Comercial** ou **Falar com Suporte Técnico** logo abaixo.`;
    } else {
      return `A ComBr **não atua diretamente na área de ${queriedTopic}**.\n\nNosso ecossistema é voltado para infraestrutura corporativa: Cloud AWS & Oracle, VPS Linux Gerenciada, E-mail Corporativo e Híbrido, SMTP Envios e Backup Imutável SaveData.\n\nCaso precise de servidores ou e-mail, selecione uma das opções logo abaixo.`;
    }
  }

  // 0.1 Specific email inquiries: "vocês trabalham com e-mail?", "vocês fazem e-mail?"
  if (/trabalham com e-?mail|fazem e-?mail|tem e-?mail|oferecem e-?mail|servi[çc]o de e-?mail/i.test(lower)) {
    return `Sim! Trabalhamos com soluções completas de e-mail corporativo (@suaempresa.com.br), e-mail híbrido (integrado com Microsoft 365 ou Google Workspace) e SMTP dedicado para envio de notas fiscais e sistemas.\n\nPara contratar ou tirar dúvidas técnicas, selecione **Enviar para o Comercial** ou **Falar com Suporte Técnico** logo abaixo.`;
  }

  // 0.2 Cloud server prices / quotes
  if (/(?:valor|pre[çc]o|quanto custa).*cloud|cloud.*(?:valor|pre[çc]o|quanto custa)|(?:valor|pre[çc]o|quanto custa).*servidor/i.test(lower)) {
    return `Os planos de nuvem da ComBr são dimensionados sob medida de acordo com a memória RAM, vCPU e armazenamento NVMe que o seu sistema corporativo exige, com faturamento em Real (BRL) sem variações cambiais.\n\nPara solicitar uma proposta ou tirar dúvidas técnicas, selecione uma das opções logo abaixo: **Enviar para o Comercial**, **Enviar para o Financeiro** ou **Falar com Suporte Técnico**.`;
  }

  // 0.2.1 Portas IMAP, POP3 e SMTP da ComBr
  if (/porta.*imap|imap.*smtp|portas.*servidores|servidores.*oficiais|porta.*pop|quais s[ãa]o as portas/i.test(lower)) {
    return `Os parâmetros oficiais e portas de conexão segura da ComBr são:\n\n• **IMAP (Recomendado):** \`imap.combr.com.br\` — Porta **993** (Segurança SSL/TLS).\n• **POP3:** \`pop.combr.com.br\` — Porta **995** (Segurança SSL/TLS).\n• **SMTP (Envio Seguro):** \`smtp.combr.com.br\` — Porta **465** (SSL/TLS) ou **587** (STARTTLS) com autenticação ativada.\n• **Webmail Oficial:** https://webmail.combr.com.br\n\nCaso necessite de auxílio para configuração ou queira contratar novas contas, basta selecionar a opção desejada logo abaixo (**Falar com Suporte Técnico** ou **Enviar para o Comercial**).`;
  }

  // 0.2.2 Cloud AWS & OCI e VPS Linux Gerenciada (Falando detalhadamente sobre cada uma)
  if (/vps.*linux|cloud.*aws|oci.*combr|cloud.*vps|vps.*gerenciada/i.test(lower)) {
    return `A ComBr oferece infraestrutura corporativa de alto desempenho:\n\n1. **Cloud AWS e Oracle Cloud (OCI):** Ambientes corporativos em nuvem elástica de missão crítica com SLA garantido de 99,9% para ERPs (Totvs Protheus, RM, SAP, Senior) e bancos de alta concorrência, com faturamento fixo em Real (BRL) sem IOF.\n\n2. **VPS Linux Gerenciada:** Servidores dedicados com discos NVMe, isolamento de recursos e sustentação completa com monitoramento contínuo 24x7 NOC.\n\nPara simular valores ou detalhar a arquitetura técnica, selecione a opção **Enviar para o Comercial** ou **Falar com Suporte Técnico** logo abaixo.`;
  }

  // 0.2.3 E-mail Híbrido & SMTP Envios Empresarial (Falando detalhadamente sobre cada um)
  if (/e-?mail h[íi]brido|smtp envio|smtp empresarial.*nf|h[íi]brido.*smtp/i.test(lower)) {
    return `Soluções em mensageria corporativa ComBr:\n\n1. **E-mail Híbrido:** Permite utilizar o mesmo domínio (@suaempresa.com.br) combinando contas corporativas ComBr com licenças Microsoft 365 ou Google Workspace, reduzindo custos de licenciamento em até 70%.\n\n2. **SMTP Envio Empresarial:** Relay dedicado para disparo em massa de XMLs de NF-e, NFS-e, CT-e e boletos com IPs aquecidos e autenticação SPF/DKIM/DMARC.\n\nPara solicitar uma cotação sob medida ou esclarecer requisitos técnicos, selecione **Enviar para o Comercial** ou **Falar com Suporte Técnico** logo abaixo.`;
  }

  // 0.2.4 SaveData & SaveMail (Falando detalhadamente sobre cada um)
  if (/savedata|savemail|backup.*ransomware|auditoria.*e-?mail/i.test(lower)) {
    return `Proteção corporativa e continuidade de negócios:\n\n1. **SaveData:** Backup corporativo em nuvem em datacenters Tier III, 100% imutável contra ataques de ransomware com criptografia militar AES-256.\n\n2. **SaveMail:** Auditoria contínua e arquivamento forense de tráfego de e-mails para conformidade com a LGPD e respaldo jurídico.\n\nPara contratar ou agendar demonstração técnica, basta selecionar **Enviar para o Comercial** ou **Falar com Suporte Técnico** logo abaixo.`;
  }

  // 0.2.5 Bancos Oracle & MySQL (Falando detalhadamente sobre cada um)
  if (/banco.*oracle|bancos.*mysql|gest[ãa]o de bancos|dba.*oracle|consultoria.*dba/i.test(lower)) {
    return `Nossa equipe sênior de DBA atua na sustentação e alta performance de bancos de dados relacionais Oracle Database e MySQL para sistemas de missão crítica:\n\n• **Administração Proativa 24x7:** Monitoramento contínuo de disponibilidade, tablespaces e locks.\n• **Performance & Tuning Especializado:** Otimização de queries, reindexação e parametrização de memória (SGA/PGA).\n• **Alta Disponibilidade e Contingência:** Rotinas automatizadas de backup e testes periódicos de restore.\n\nPara solicitar consultoria ou suporte emergencial, selecione a opção desejada logo abaixo.`;
  }

  // 0.2.6 Caixa Cheia / Cota Excedida
  if (/caixa.*cheia|cota.*excedida|caixa.*lotada|limite.*espa[çc]o|caixa postal.*cheia/i.test(lower)) {
    return `Para resolver a caixa de e-mail lotada ou com cota excedida, siga estes passos:\n\n1. **Limpeza pelo Webmail:** Acesse https://webmail.combr.com.br e esvazie a pasta **Lixeira** e a pasta **Spam**, que continuam consumindo o espaço da sua cota.\n2. **Arquivamento Local (.pst):** Se você usa o Outlook ou Thunderbird, crie pastas de arquivo local no seu computador para desocupar o servidor sem perder o histórico das mensagens antigas.\n3. **Upgrade de Armazenamento:** O administrador da sua empresa pode aumentar o limite da sua conta pelo painel de controle da ComBr, ou você pode solicitar ao nosso Suporte Técnico pelo WhatsApp (14) 99895-1113.`;
  }

  // 0.2.7 Suporte N2 Especializado
  if (/suporte.*n2|suporte t[ée]cnico n[íi]vel 2|migra[çc][ãa]o.*logs|an[aá]lise de logs/i.test(lower)) {
    return `Para atendimento de Suporte N2, diagnósticos aprofundados de logs, falhas de conectividade ou projetos de migração, fale direto com nossos analistas:\n\n• **WhatsApp:** (14) 99895-1113\n• **Telefone:** (14) 3333-1150 (Ramal 1)\n• **E-mail:** suporte@combr.com.br\n\nNossa equipe conta com especialistas em infraestrutura e atende com suporte assistido remoto via TeamViewer e AnyDesk.`;
  }

  // 0.1 Math calculations / Piadas / Receitas / Assuntos fora da empresa
  if (/piada|conte uma piada|me faz rir|engra[çc]ad[ao]|receita|como fazer bolo|como cozinhar|futebol|jogo de futebol|campeonato|quem ganhou|signo|hor[oó]scopo|pol[íi]tica|presidente/i.test(lower)) {
    return `Como assistente virtual da **ComBr Soluções em Nuvem**, meu atendimento é dedicado exclusivamente a informações, produtos e serviços da empresa (servidores em nuvem, VPS Linux, e-mail corporativo, backup SaveData e suporte técnico).\n\nCaso você tenha alguma dúvida sobre as soluções corporativas da ComBr ou precise de apoio técnico, estou à disposição para auxiliá-lo!`;
  }

  // 0.2 Common General Technology & Knowledge Questions (Relacionados à tecnologia em nuvem e e-mail)
  if (/o que [eé] nuvem|o que [eé] cloud|como funciona a nuvem/i.test(lower)) {
    return `Computação em nuvem (*cloud computing*) é a entrega sob demanda de recursos de tecnologia — como servidores, armazenamento de dados, bancos de dados, redes e softwares — pela internet, sem a necessidade de manter equipamentos físicos no local.\n\nNa ComBr, projetamos ambientes em nuvem corporativa (AWS e Oracle Cloud) com alta disponibilidade (99,9%) e faturamento nacional em Real (BRL).\n\nPara solicitar uma proposta para a sua empresa ou falar com nossos especialistas, basta selecionar uma das opções logo abaixo.`;
  }

  if (/o que [eé] dns|para que serve o dns/i.test(lower)) {
    return `DNS (*Domain Name System*) é o sistema que traduz nomes de domínio legíveis (como \`combr.com.br\`) para os endereços IP numéricos que os servidores utilizam para se comunicar na rede.\n\nNa ComBr, realizamos toda a configuração e gestão de apontamentos de DNS para seu domínio corporativo e e-mails profissionais.`;
  }

  if (/o que [eé] ia|o que [eé] intelig[eê]ncia artificial/i.test(lower)) {
    return `Inteligência Artificial (IA) é o ramo da tecnologia que desenvolve sistemas capazes de processar dados e raciocinar para auxiliar pessoas e empresas.\n\nEu sou a ComIA, a assistente virtual oficial da **ComBr Soluções em Nuvem**, treinada para esclarecer dúvidas sobre nossos serviços de infraestrutura, servidores, e-mails e suporte técnico. Como posso te auxiliar com as soluções da ComBr?`;
  }

  if (/o que [eé] ransomware|como funciona o ransomware/i.test(lower)) {
    return `Ransomware é um software malicioso que sequestra dados através de criptografia e exige resgate financeiro.\n\nA defesa mais segura contra ransomware é a solução **SaveData** da ComBr: backup corporativo em nuvem 100% imutável com criptografia militar AES-256 em datacenters Tier III.\n\nPara proteger os dados da sua empresa, selecione **Enviar para o Comercial** logo abaixo.`;
  }

  if (/o que [eé] docker|o que [eé] container/i.test(lower)) {
    return `Containers (como Docker) empacotam softwares com todas as suas dependências para execução homogênea em qualquer servidor.\n\nNossos servidores **VPS Linux Gerenciados** e instâncias em **Cloud AWS e Oracle Cloud** são preparados para orquestração de containers com alta performance e discos NVMe.\n\nPara dimensionar um ambiente, selecione **Enviar para o Comercial** ou **Falar com Suporte Técnico** logo abaixo.`;
  }

  if (/o que [eé] vpn/i.test(lower)) {
    return `VPN (*Virtual Private Network*) cria um túnel criptografado e seguro entre seus dispositivos e a infraestrutura da sua empresa.\n\nConfiguramos e sustentamos túneis VPN dedicados para conexão segura aos seus servidores em nuvem corporativos na ComBr.`;
  }

  if (/o que [eé] firewall/i.test(lower)) {
    return `Firewall é uma barreira de segurança que monitora e filtra o tráfego de rede para impedir acessos não autorizados.\n\nTodos os ambientes em nuvem e servidores gerenciados da ComBr contam com proteção perimetral de firewall corporativo e monitoramento contínuo.`;
  }

  // 1. Forgotten password / Password reset assistance (guide first, offer support only as last resort)
  if (
    /esqueci.*senha|perdi.*senha|n[ãa]o lembro.*senha|redefinir.*senha|resetar.*senha|recuperar.*senha|trocar.*senha|alterar.*senha/i.test(
      lower
    )
  ) {
    return `Vamos tentar resolver! Primeiro, faça um teste acessando direto pelo nosso Webmail: https://webmail.combr.com.br para confirmar se o acesso entra por lá.\n\nSe a sua empresa tiver um responsável de TI ou administrador da conta, ele também consegue redefinir a sua senha na hora pelo painel de controle da ComBr.\n\nCaso você não consiga acessar de jeito nenhum ou sua empresa não tenha um administrador por aí, me avise que te passo o contato do nosso suporte técnico para te ajudar na redefinição!`;
  }

  // 1.1 Negative feedback or prompt correction regarding the assistant's response
  if (/n[ãa]o funcionou.*respondendo|do jeito que eu n[ãa]o|n[ãa]o era isso|resposta errada|continua respondendo|ainda continua/i.test(lower)) {
    return `Peço desculpas pela divergência. Como assistente corporativa da ComBr Soluções em Nuvem, posso auxiliá-lo com qualquer dúvida técnica ou institucional.\n\nPara atendimento direto com nossa equipe, basta selecionar a opção desejada logo abaixo: **Enviar para o Comercial**, **Enviar para o Financeiro** ou **Falar com Suporte Técnico**.`;
  }

  // 1.2 User expresses interest in services or wants to know how to proceed
  if (/(?:tenho|com|mais|muito|algum)\s*interesse|me\s*interessei|estou\s*interessad[oa]|gostei\s*do\s*servi[çc]o|quero\s*saber\s*mais\s*sobre\s*o\s*servi[çc]o|como\s*fa[çc]o\s*pra\s*contratar/i.test(lower)) {
    return `Para dar andamento à sua solicitação, solicitar proposta comercial ou falar com especialistas, selecione uma das opções logo abaixo: **Enviar para o Comercial**, **Enviar para o Financeiro** ou **Falar com Suporte Técnico**.`;
  }

  // 1.3 Negative answers when unable to resolve / reset password ("não consegui resetar", "não funcionou a senha", etc.)
  if (
    /(?:senha|login|webmail|acesso|entrar).*(?:não consegui|nao consegui|não deu certo|nao deu certo|não funcionou|nao funcionou)|(?:não consegui|nao consegui|não deu certo|nao deu certo|não funcionou|nao funcionou).*(?:senha|login|webmail|acesso|entrar)|continua sem entrar|não lembro mesmo|nao lembro mesmo|não tenho admin|nao tenho admin/i.test(
      lower
    )
  ) {
    return `A redefinição de senha corporativa exige validação de segurança do domínio. Por gentileza, clique no botão **Falar com Suporte Técnico** logo abaixo para atendimento com nossos analistas.`;
  }

  // 1.4 Technical issues / Errors / Problems / Troubleshooting -> Suporte Técnico
  if (
    /suporte|problema|erro|não funciona|nao funciona|caiu|fora do ar|lento|lentidão|bloqueado|não consigo|nao consigo|configurar|outlook|teamviewer|anydesk|chamado/i.test(
      lower
    )
  ) {
    return `Para suporte técnico emergencial, abertura de chamado ou auxílio remoto, selecione o botão **Falar com Suporte Técnico** logo abaixo.`;
  }

  // 2. Billing / Invoice / Financial -> Financeiro
  if (/boleto|fatura|pagamento|financeir|nota fiscal|cobran|mensalidade|segunda via|comprovante|contrato|2a via|nf-e|nfe/i.test(lower)) {
    return `Para emissão de segunda via de boletos, notas fiscais ou faturamento, selecione o botão **Enviar para o Financeiro** logo abaixo.`;
  }

  // 3. Prices / Plans / Commercial -> Comercial
  if (/preço|preco|valor|quanto custa|orçamento|orcamento|cotação|cotacao|contratar|comprar|plano|valores|comercial|proposta/i.test(lower)) {
    return `Os planos e estruturas em nuvem da ComBr são dimensionados sob medida para o porte e sistemas da sua empresa (Cloud AWS & Oracle, VPS Linux, E-mail Híbrido, Backup SaveData e DBA), com faturamento fixo em Real (BRL).\n\nPara receber uma proposta personalizada ou falar com nossa equipe, selecione o botão **Enviar para o Comercial** ou **Enviar para o Financeiro** logo abaixo.`;
  }

  // 4. About the company (Sobre a ComBr / sobre a empresa, história, sede, quem são, etc.)
  if (
    /(?:sobre|saber|conhecer|fale|hist[oó]ria).*(?:empresa|combr)|(?:empresa|combr).*(?:sobre|saber|conhecer|hist[oó]ria)|quem [eé] a (?:empresa|combr)|o que [eé] a (?:empresa|combr)|onde fica|localiza|endere[çc]o|mar[ií]lia|sede|telefone|contato/i.test(
      lower
    ) ||
    /saber\s+(?:mais|mias)?\s*sobre\s+a\s+(?:empresa|combr)/i.test(lower)
  ) {
    return `A **ComBr Soluções em Nuvem** possui mais de 25 anos de atuação sólida no mercado B2B, entregando tecnologia corporativa e infraestrutura de missão crítica:\n\n• **Sede:** Av. Ipiranga, 85 – Sala 91, Marília – SP | combr.com.br\n• **Soluções:** Cloud AWS e Oracle Cloud (OCI), VPS Linux Gerenciada NOC 24x7, E-mail Corporativo e Híbrido (até 70% de economia), SMTP Envios dedicado e Backup Imutável SaveData.\n• **Faturamento:** 100% em Real (BRL) sem variações cambiais ou IOF.\n\nPara propostas ou suporte, selecione uma das opções logo abaixo.`;
  }

  // 5. Catalog / Services / Solutions
  if (/cat[aá]logo|servi[çc]os?|produtos?|solu[çc][oõ]es|o que voc[êe]s fazem|o que a combr faz|trabalham com o que/i.test(lower)) {
    return `A ComBr Soluções em Nuvem atua em pilares corporativos essenciais:\n\n1. **Nuvem & VPS:** Cloud AWS & Oracle (OCI) com SLA 99,9% e VPS Linux com sustentação NOC 24x7.\n2. **E-mail & SMTP:** E-mail Híbrido com Microsoft 365 e relay dedicado para notas fiscais.\n3. **Segurança de Dados:** Backup SaveData imutável contra ransomware e arquivamento SaveMail para LGPD.\n4. **Consultoria DBA:** Sustentação e tuning de Oracle Database e MySQL.\n\nPara contratar ou tirar dúvidas, selecione **Enviar para o Comercial** ou **Falar com Suporte Técnico** logo abaixo.`;
  }

  // 6. Generic response when question is general or open-ended
  return `Como assistente virtual da **ComBr Soluções em Nuvem**, meu atendimento é dedicado exclusivamente aos nossos serviços e soluções corporativas (servidores em nuvem, VPS Linux, e-mail corporativo, backup SaveData e suporte técnico).\n\nComo posso auxiliá-lo com as soluções da ComBr para a sua empresa?`;
}

function generateImageClientResponse(fileName: string, caption: string, userMessage: string): string {
  const combined = `${fileName} ${caption} ${userMessage}`.toLowerCase();

  // 1. Logo / ComIA / Brand recognition
  if (/logo|comia|avatar|marca|icone|nuvem|combr/.test(combined)) {
    return `Analisei a imagem enviada (**${fileName}**) 🤖✨

Identifiquei a identidade visual / logotipo da **ComIA** e da **ComBr Soluções em Nuvem**! 

O design traz o conceito de tecnologia, computação em nuvem e atendimento humanizado e inteligente. Como posso te auxiliar hoje?`;
  }

  // 2. Outlook / Desktop mail clients
  if (/outlook|thunderbird|apple mail|windows mail|aplicativo|app|celular|iphone|android/.test(combined)) {
    return `Analisei a captura de tela enviada (**${fileName}**) 🔍

Identifiquei a janela de diálogo do **Microsoft Outlook** (ou cliente local) com notificação de falha de sincronização com o servidor de correio.

Pelo padrão do aviso exibido, o aplicativo local não conseguiu validar as credenciais salvas ou houve bloqueio no aperto de mão (handshake) nas portas IMAP/SMTP.

Para solucionarmos no suporte N1 da ComBr:

🌐 1. Teste o acesso de imediato pelo nosso Webmail: **https://webmail.combr.com.br** para confirmar se o e-mail e a senha continuam válidos no servidor.

⚙️ 2. Verifique as configurações de porta no cliente:
• **IMAP:** \`imap.combr.com.br\` (Porta 993 com SSL/TLS)
• **SMTP:** \`smtp.combr.com.br\` (Porta 465 SSL ou 587 STARTTLS) com a opção *"Meu servidor de saída requer autenticação"* marcada.

Qual é o seu e-mail corporativo ou domínio para verificarmos se seu IP sofreu um bloqueio temporário de segurança nos logs do firewall?`;
  }

  // 3. Webmail / Login issues
  if (/webmail|navegador|browser|login|autentic|sessão|sessao|senha incorreta/.test(combined)) {
    return `Analisei a imagem enviada (**${fileName}**) 🔍

Identifiquei a interface de autenticação do **Webmail da ComBr**. Na imagem observo a mensagem de credenciais incorretas ou sessão expirada.

Quando ocorrem erros consecutivos de senha em um curto intervalo de tempo, o firewall do servidor bloqueia temporariamente o IP de conexão para resguardar a integridade da sua conta.

Qual é o seu e-mail corporativo ou domínio para consultarmos os logs de segurança e providenciarmos a liberação do seu acesso?`;
  }

  // 4. Financial / Invoices / Boletos
  if (/boleto|fatura|nf|nota fiscal|pagamento|comprovante|recibo/.test(combined)) {
    return `Analisei o documento anexado na imagem (**${fileName}**) 📑

Identifiquei que se trata de uma fatura / boleto ou comprovante financeiro corporativo.

Você deseja confirmar a baixa deste pagamento ou precisa da emissão de uma 2ª via atualizada com nova data de vencimento?

Por favor, informe o CNPJ ou Razão Social da sua empresa para localizarmos no sistema financeiro da ComBr!`;
  }

  // 5. General image / Photo
  return `Analisei a imagem anexada (**${fileName}**) 📸

Como assistente virtual da ComBr Soluções em Nuvem, consigo examinar fotos, logos, telas de erro, documentos e arquiteturas de nuvem.

${caption || userMessage ? `Em relação a: *"${caption || userMessage}"*, como posso te auxiliar detalhadamente?` : `Como posso te auxiliar com relação a esta imagem hoje? Você pode me dizer sua dúvida que te respondo na hora!`}`;
}
