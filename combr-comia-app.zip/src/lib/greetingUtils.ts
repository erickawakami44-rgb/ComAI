/**
 * Utility to calculate Brazilian time (America/Sao_Paulo) and return appropriate greeting
 * Bom dia: 05:00 - 11:59
 * Boa tarde: 12:00 - 17:59
 * Boa noite: 18:00 - 04:59
 */

export interface PeriodGreeting {
  greeting: "Bom dia" | "Boa tarde" | "Boa noite";
  greetingWithEmoji: string;
  hour: number;
  period: "morning" | "afternoon" | "night";
}

export function getCurrentPeriodGreeting(): PeriodGreeting {
  const now = new Date();
  
  // Format current hour in America/Sao_Paulo timezone
  const hourStr = now.toLocaleTimeString("pt-BR", {
    timeZone: "America/Sao_Paulo",
    hour: "2-digit",
    hour12: false,
  });

  const hour = parseInt(hourStr, 10);

  if (hour >= 5 && hour < 12) {
    return {
      greeting: "Bom dia",
      greetingWithEmoji: "🌅 Bom dia",
      hour,
      period: "morning",
    };
  } else if (hour >= 12 && hour < 18) {
    return {
      greeting: "Boa tarde",
      greetingWithEmoji: "☀️ Boa tarde",
      hour,
      period: "afternoon",
    };
  } else {
    return {
      greeting: "Boa noite",
      greetingWithEmoji: "🌙 Boa noite",
      hour,
      period: "night",
    };
  }
}
