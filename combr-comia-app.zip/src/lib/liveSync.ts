import { LiveSession, Message, Ticket } from "../types";

const API_BASE = (import.meta.env.VITE_API_URL || "").replace(/\/$/, "");

type SyncCallback = (session: LiveSession, tickets?: Ticket[]) => void;
type NewMessageCallback = (message: Message, session: LiveSession) => void;
type TypingCallback = (who: "client" | "agent" | "comia", isTyping: boolean) => void;
type ResetCallback = (session: LiveSession) => void;

class LiveSyncClient {
  private ws: WebSocket | null = null;
  private reconnectTimer: any = null;
  private isConnecting = false;
  private syncListeners = new Set<SyncCallback>();
  private messageListeners = new Set<NewMessageCallback>();
  private typingListeners = new Set<TypingCallback>();
  private resetListeners = new Set<ResetCallback>();
  private currentSession: LiveSession | null = null;

  constructor() {
    this.connect();
  }

  public getSession(): LiveSession | null {
    return this.currentSession;
  }

  public connect() {
    if (typeof window === "undefined") return;
    if (this.ws && (this.ws.readyState === WebSocket.OPEN || this.ws.readyState === WebSocket.CONNECTING)) {
      return;
    }

    this.isConnecting = true;
    try {
      const loc = window.location;
      const wsProtocol = loc.protocol === "https:" ? "wss:" : "ws:";
      let host = loc.host;
      if (API_BASE) {
        try {
          const parsed = new URL(API_BASE);
          host = parsed.host;
        } catch (_) {}
      }

      const wsUrl = `${wsProtocol}//${host}`;
      this.ws = new WebSocket(wsUrl);

      this.ws.onopen = () => {
        this.isConnecting = false;
        // Request immediate sync
        this.sendWs({ type: "init" });
      };

      this.ws.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          if (!data || !data.type) return;

          switch (data.type) {
            case "sync": {
              if (data.session) {
                this.currentSession = data.session;
                this.syncListeners.forEach((cb) => cb(data.session, data.tickets));
              }
              break;
            }

            case "new_message": {
              if (data.session) this.currentSession = data.session;
              if (data.message) {
                this.messageListeners.forEach((cb) => cb(data.message, data.session || this.currentSession));
              }
              break;
            }

            case "session_updated": {
              if (data.session) {
                this.currentSession = data.session;
                this.syncListeners.forEach((cb) => cb(data.session));
              }
              break;
            }

            case "typing": {
              this.typingListeners.forEach((cb) => cb(data.who, !!data.isTyping));
              break;
            }

            case "ticket_deleted":
            case "ticket_updated": {
              if (data.session) this.currentSession = data.session;
              this.syncListeners.forEach((cb) => cb(data.session || this.currentSession, data.tickets));
              break;
            }

            case "chat_reset": {
              if (data.session) {
                this.currentSession = data.session;
                this.resetListeners.forEach((cb) => cb(data.session));
              }
              break;
            }

            case "attendance_finished":
            case "session_rated": {
              if (data.session) {
                this.currentSession = data.session;
                this.syncListeners.forEach((cb) => cb(data.session));
              }
              break;
            }
          }
        } catch (err) {
          console.warn("[LiveSync] Error parsing message:", err);
        }
      };

      this.ws.onerror = (err) => {
        console.warn("[LiveSync] WebSocket error:", err);
      };

      this.ws.onclose = () => {
        this.isConnecting = false;
        this.ws = null;
        // Auto-reconnect with 2.5s delay
        clearTimeout(this.reconnectTimer);
        this.reconnectTimer = setTimeout(() => {
          this.connect();
        }, 2500);
      };
    } catch (err) {
      this.isConnecting = false;
      console.warn("[LiveSync] Failed to initialize WebSocket:", err);
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = setTimeout(() => this.connect(), 3500);
    }
  }

  private sendWs(data: any): boolean {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      try {
        this.ws.send(JSON.stringify(data));
        return true;
      } catch (err) {
        console.warn("[LiveSync] Error sending WS message:", err);
      }
    }
    return false;
  }

  // Fallback REST fetch if WS not ready
  public async fetchInitialSession(): Promise<LiveSession | null> {
    try {
      const res = await fetch(`${API_BASE}/api/live-session`);
      if (res.ok) {
        const data = await res.json();
        if (data.session) {
          this.currentSession = data.session;
          this.syncListeners.forEach((cb) => cb(data.session));
          return data.session;
        }
      }
    } catch (err) {
      console.warn("[LiveSync] Failed to fetch session via HTTP:", err);
    }
    return null;
  }

  // Client sends a message (audio, photo, doc, or text)
  public async sendClientMessage(message: Message) {
    const sent = this.sendWs({
      type: "client_message",
      message,
    });

    if (!sent) {
      // Fallback via HTTP REST
      try {
        await fetch(`${API_BASE}/api/live-session/client-message`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ message }),
        });
      } catch (err) {
        console.warn("[LiveSync] HTTP client-message fallback failed:", err);
      }
    }
  }

  // Human Agent takes over conversation
  public async takeoverChat(agentName: string = "Erick (Suporte N2)") {
    const sent = this.sendWs({
      type: "agent_takeover",
      agentName,
    });

    if (!sent) {
      try {
        await fetch(`${API_BASE}/api/live-session/takeover`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ agentName }),
        });
      } catch (err) {
        console.warn("[LiveSync] HTTP takeover fallback failed:", err);
      }
    }
  }

  // Human Agent returns conversation to ComIA AI
  public async releaseToBot() {
    const sent = this.sendWs({
      type: "release_to_bot",
    });

    if (!sent) {
      try {
        await fetch(`${API_BASE}/api/live-session/release`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
        });
      } catch (err) {
        console.warn("[LiveSync] HTTP release fallback failed:", err);
      }
    }
  }

  // Human Agent sends a direct message
  public async sendAgentMessage(content: string, agentName?: string) {
    const sent = this.sendWs({
      type: "agent_message",
      content,
      agentName,
    });

    if (!sent) {
      try {
        await fetch(`${API_BASE}/api/live-session/agent-message`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ content, agentName }),
        });
      } catch (err) {
        console.warn("[LiveSync] HTTP agent-message fallback failed:", err);
      }
    }
  }

  // Typing indicator
  public sendTyping(who: "client" | "agent", isTyping: boolean) {
    this.sendWs({
      type: "typing",
      who,
      isTyping,
    });
  }

  // Reset chat
  public async resetChat() {
    const sent = this.sendWs({
      type: "reset_chat",
    });

    if (!sent) {
      try {
        await fetch(`${API_BASE}/api/live-session/reset`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
        });
      } catch (err) {
        console.warn("[LiveSync] HTTP reset fallback failed:", err);
      }
    }
  }

  // Internal Agent Note
  public async addInternalNote(text: string, author?: string) {
    const sent = this.sendWs({
      type: "add_internal_note",
      text,
      author,
    });

    if (!sent) {
      try {
        await fetch(`${API_BASE}/api/live-session/note`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ text, author }),
        });
      } catch (err) {
        console.warn("[LiveSync] HTTP note fallback failed:", err);
      }
    }
  }

  // Finalizar Atendimento e liberar para avaliação do cliente
  public async finishAttendance(agentName?: string, ticketId?: string) {
    const sent = this.sendWs({
      type: "finish_attendance",
      agentName,
      ticketId,
    });

    if (!sent) {
      try {
        await fetch(`${API_BASE}/api/live-session/finish`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ agentName, ticketId }),
        });
      } catch (err) {
        console.warn("[LiveSync] HTTP finishAttendance fallback failed:", err);
      }
    }
  }

  // Enviar Avaliação do Cliente
  public async submitRating(rating: { stars: number; tags?: string[]; comment?: string; clientName?: string }) {
    const sent = this.sendWs({
      type: "submit_rating",
      rating,
    });

    if (!sent) {
      try {
        await fetch(`${API_BASE}/api/live-session/rate`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(rating),
        });
      } catch (err) {
        console.warn("[LiveSync] HTTP submitRating fallback failed:", err);
      }
    }
  }

  // Event Listeners
  public onSync(cb: SyncCallback): () => void {
    this.syncListeners.add(cb);
    if (this.currentSession) cb(this.currentSession);
    return () => this.syncListeners.delete(cb);
  }

  public onNewMessage(cb: NewMessageCallback): () => void {
    this.messageListeners.add(cb);
    return () => this.messageListeners.delete(cb);
  }

  public onTyping(cb: TypingCallback): () => void {
    this.typingListeners.add(cb);
    return () => this.typingListeners.delete(cb);
  }

  public onReset(cb: ResetCallback): () => void {
    this.resetListeners.add(cb);
    return () => this.resetListeners.delete(cb);
  }
}

export const liveSync = new LiveSyncClient();
