import { WhatsAppClientChat, Message } from "../types";

export const STORAGE_KEY_CLIENT_CHATS = "combr_whatsapp_clients_v3";

const now = new Date();
const timeAgo = (minutes: number) => {
  const d = new Date(now.getTime() - minutes * 60 * 1000);
  return d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
};

export const DEFAULT_CLIENT_CHATS: WhatsAppClientChat[] = [
  {
    id: "main",
    name: "ComIA • Atendimento Oficial",
    phone: "+55 (14) 99895-1113",
    company: "ComBR Soluções em Nuvem",
    domain: "combr.com.br",
    category: "general",
    avatarColor: "#00a884",
    avatarInitials: "CI",
    isVerified: true,
    isPinned: true,
    unreadCount: 0,
    lastMessage: "Olá! Sou a ComIA, assistente virtual oficial da ComBR...",
    lastMessageTime: timeAgo(1),
    status: "online",
    mode: "bot",
    messages: [
      {
        id: "welcome-comia-1",
        sender: "assistant",
        content: `Olá! Sou a **ComIA**, assistente virtual oficial da **ComBR Soluções em Nuvem**.\n\nComo posso ajudar sua empresa hoje? Selecione um dos departamentos abaixo ou envie sua dúvida sobre e-mails, servidores em nuvem ou suporte:`,
        timestamp: new Date(now.getTime() - 5 * 60 * 1000).toISOString(),
        status: "read",
        showDepartmentOptions: true,
      },
    ],
    createdAt: new Date(now.getTime() - 60 * 60 * 1000).toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: "cli-carlos",
    name: "Carlos Eduardo",
    phone: "+55 (19) 99123-8877",
    company: "Fintech Express Brasil",
    domain: "fintechexpress.com.br",
    email: "carlos@fintechexpress.com.br",
    category: "support_n2",
    avatarColor: "#3b82f6",
    avatarInitials: "CE",
    isVerified: false,
    isPinned: false,
    unreadCount: 2,
    lastMessage: "Vocês poderiam verificar se houve alguma manutenção ou pico no datacenter?",
    lastMessageTime: timeAgo(8),
    status: "online",
    lastSeen: "online agora",
    mode: "bot",
    messages: [
      {
        id: "carlos-1",
        sender: "user",
        content: "Olá, equipe ComBR! Notamos uma oscilação na resposta da API no nosso servidor VPS Cloud Dedicado por volta das 14h.",
        timestamp: new Date(now.getTime() - 15 * 60 * 1000).toISOString(),
        status: "read",
      },
      {
        id: "carlos-2",
        sender: "assistant",
        content: "Olá Carlos! Já consultei os nós de monitoramento em tempo real do nosso datacenter em São Paulo. O cluster VPS-BR-04 está operando com carga normal de CPU e memória. Você gostaria que eu abra um chamado direto para o time de Engenharia N2 analisar o tráfego de rede da sua máquina?",
        timestamp: new Date(now.getTime() - 12 * 60 * 1000).toISOString(),
        status: "read",
      },
      {
        id: "carlos-3",
        sender: "user",
        content: "Sim, por favor! O host do servidor é vps12.fintechexpress.com.br.",
        timestamp: new Date(now.getTime() - 9 * 60 * 1000).toISOString(),
        status: "delivered",
      },
      {
        id: "carlos-4",
        sender: "user",
        content: "Vocês poderiam verificar se houve alguma manutenção ou pico no datacenter?",
        timestamp: new Date(now.getTime() - 8 * 60 * 1000).toISOString(),
        status: "delivered",
      },
    ],
    createdAt: new Date(now.getTime() - 120 * 60 * 1000).toISOString(),
    updatedAt: new Date(now.getTime() - 8 * 60 * 1000).toISOString(),
  },
  {
    id: "cli-mariana",
    name: "Mariana Silva",
    phone: "+55 (11) 98765-4321",
    company: "Agência Alfa Design",
    domain: "agenciaalfa.com.br",
    email: "mariana@agenciaalfa.com.br",
    category: "support_n2",
    avatarColor: "#8b5cf6",
    avatarInitials: "MS",
    isVerified: false,
    isPinned: false,
    unreadCount: 0,
    lastMessage: "Deu certinho! Ativei a autenticação SMTP e o e-mail disparou na hora. Muito obrigada! 🙌",
    lastMessageTime: timeAgo(25),
    status: "online",
    lastSeen: "visto por último hoje às " + timeAgo(10),
    mode: "bot",
    messages: [
      {
        id: "mariana-1",
        sender: "user",
        content: "Boa tarde! Estamos com problema no envio de e-mails pelo Thunderbird na nossa agência. Aparece a mensagem: 'Erro 550 Relaying denied'. Como posso arrumar?",
        timestamp: new Date(now.getTime() - 35 * 60 * 1000).toISOString(),
        status: "read",
      },
      {
        id: "mariana-2",
        sender: "assistant",
        content: `Boa tarde, Mariana! O erro **550 Relaying Denied** ocorre quando o programa de e-mail tenta enviar sem autenticar com login e senha no servidor de saída (SMTP).

Para resolver no **Mozilla Thunderbird**:
1. Vá em **Configurar Contas** > clique no menu esquerdo em **Servidor de envio (SMTP)**.
2. Selecione a conta e clique em **Editar**.
3. No campo **Método de autenticação**, selecione: **Senha normal**.
4. Certifique-se de que o **Nome de usuário** seja seu e-mail completo (\`mariana@agenciaalfa.com.br\`).
5. A porta correta é **465** com segurança **SSL/TLS** (ou porta **587** com STARTTLS).

Faça um teste enviando uma mensagem após salvar!`,
        timestamp: new Date(now.getTime() - 30 * 60 * 1000).toISOString(),
        status: "read",
      },
      {
        id: "mariana-3",
        sender: "user",
        content: "Deu certinho! Ativei a autenticação SMTP e o e-mail disparou na hora. Muito obrigada! 🙌",
        timestamp: new Date(now.getTime() - 25 * 60 * 1000).toISOString(),
        status: "read",
      },
    ],
    createdAt: new Date(now.getTime() - 180 * 60 * 1000).toISOString(),
    updatedAt: new Date(now.getTime() - 25 * 60 * 1000).toISOString(),
  },
  {
    id: "cli-beatriz",
    name: "Dra. Beatriz Alencar",
    phone: "+55 (31) 98456-1122",
    company: "Hospital & Maternidade São Lucas",
    domain: "saolucashospital.com.br",
    email: "beatriz.alencar@saolucashospital.com.br",
    category: "commercial",
    avatarColor: "#ec4899",
    avatarInitials: "BA",
    isVerified: false,
    isPinned: false,
    unreadCount: 1,
    lastMessage: "Poderia me enviar uma proposta com os valores para 150 contas corporativas e suporte 24/7?",
    lastMessageTime: timeAgo(42),
    status: "away",
    lastSeen: "ausente",
    mode: "bot",
    messages: [
      {
        id: "beatriz-1",
        sender: "user",
        content: "Bom dia! Sou diretora de TI do hospital São Lucas. Temos atualmente 150 contas de e-mail corporativo em um provedor antigo e queremos migrar para a infraestrutura em nuvem da ComBR com proteção anti-spam e conformidade LGPD.",
        timestamp: new Date(now.getTime() - 50 * 60 * 1000).toISOString(),
        status: "read",
      },
      {
        id: "beatriz-2",
        sender: "assistant",
        content: `Olá Dra. Beatriz! É uma grande satisfação atender o Hospital São Lucas.

A infraestrutura da **ComBR Soluções em Nuvem** é ideal para instituições de saúde:
- 🛡️ **Anti-spam e Antivírus corporativo em tempo real** com aprendizado contínuo;
- 🔒 **Criptografia TLS 1.3** e conformidade rigorosa com a LGPD;
- 💾 **Backup diário automatizado** com retenção estendida;
- ⚡ **Migração assistida sem parada de serviço** conduzida pelo nosso time de engenharia.

Posso transferir seus dados para um consultor comercial sênior enviar uma cotação formal com condições para grandes volumes?`,
        timestamp: new Date(now.getTime() - 45 * 60 * 1000).toISOString(),
        status: "read",
      },
      {
        id: "beatriz-3",
        sender: "user",
        content: "Poderia me enviar uma proposta com os valores para 150 contas corporativas e suporte 24/7?",
        timestamp: new Date(now.getTime() - 42 * 60 * 1000).toISOString(),
        status: "delivered",
      },
    ],
    createdAt: new Date(now.getTime() - 240 * 60 * 1000).toISOString(),
    updatedAt: new Date(now.getTime() - 42 * 60 * 1000).toISOString(),
  },
  {
    id: "cli-lucas",
    name: "Lucas Fernandes",
    phone: "+55 (11) 97321-9900",
    company: "Transportadora TransPaulista",
    domain: "transpaulista.com.br",
    email: "lucas@transpaulista.com.br",
    category: "support_n2",
    avatarColor: "#f97316",
    avatarInitials: "LF",
    isVerified: false,
    isPinned: false,
    unreadCount: 2,
    lastMessage: "Nosso IP fixo é 177.85.221.40. Podem liberar com urgência no firewall?",
    lastMessageTime: timeAgo(65),
    status: "offline",
    lastSeen: "visto hoje às " + timeAgo(60),
    mode: "bot",
    messages: [
      {
        id: "lucas-1",
        sender: "user",
        content: "Socorro! Ninguém no nosso escritório sede consegue abrir o Webmail nem baixar e-mails pelo Outlook. Acho que nosso IP foi bloqueado após um funcionário errar a senha várias vezes.",
        timestamp: new Date(now.getTime() - 70 * 60 * 1000).toISOString(),
        status: "read",
      },
      {
        id: "lucas-2",
        sender: "user",
        content: "Nosso IP fixo é 177.85.221.40. Podem liberar com urgência no firewall?",
        timestamp: new Date(now.getTime() - 65 * 60 * 1000).toISOString(),
        status: "delivered",
      },
    ],
    createdAt: new Date(now.getTime() - 300 * 60 * 1000).toISOString(),
    updatedAt: new Date(now.getTime() - 65 * 60 * 1000).toISOString(),
  },
  {
    id: "cli-juliana",
    name: "Juliana Mendes",
    phone: "+55 (21) 98844-3322",
    company: "Moda Bella E-commerce",
    domain: "modabella.com.br",
    email: "financeiro@modabella.com.br",
    category: "financial",
    avatarColor: "#eab308",
    avatarInitials: "JM",
    isVerified: false,
    isPinned: false,
    unreadCount: 1,
    lastMessage: "Perfeito, acabei de pagar via Pix! Já compensou aí no sistema?",
    lastMessageTime: "Ontem",
    status: "online",
    lastSeen: "online",
    mode: "bot",
    messages: [
      {
        id: "juliana-1",
        sender: "user",
        content: "Olá! Gostaria da segunda via do boleto e a nota fiscal do plano Cloud E-commerce do mês vigente.",
        timestamp: new Date(now.getTime() - 26 * 60 * 60 * 1000).toISOString(),
        status: "read",
      },
      {
        id: "juliana-2",
        sender: "assistant",
        content: "Olá Juliana! Localizei sua assinatura da Moda Bella. Enviamos o PDF atualizado com código de barras e chave Pix Copia-e-Cola para o e-mail financeiro@modabella.com.br. O pagamento via Pix é identificado e compensado em até 2 minutos!",
        timestamp: new Date(now.getTime() - 25 * 60 * 60 * 1000).toISOString(),
        status: "read",
      },
      {
        id: "juliana-3",
        sender: "user",
        content: "Perfeito, acabei de pagar via Pix! Já compensou aí no sistema?",
        timestamp: new Date(now.getTime() - 24 * 60 * 60 * 1000).toISOString(),
        status: "delivered",
      },
    ],
    createdAt: new Date(now.getTime() - 48 * 60 * 60 * 1000).toISOString(),
    updatedAt: new Date(now.getTime() - 24 * 60 * 60 * 1000).toISOString(),
  },
];

export function loadStoredClientChats(): WhatsAppClientChat[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_CLIENT_CHATS);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed;
      }
    }
  } catch (err) {
    console.warn("[MockClients] Erro ao carregar conversas do localStorage:", err);
  }
  return DEFAULT_CLIENT_CHATS;
}

export function saveStoredClientChats(chats: WhatsAppClientChat[]) {
  try {
    localStorage.setItem(STORAGE_KEY_CLIENT_CHATS, JSON.stringify(chats));
  } catch (err) {
    console.warn("[MockClients] Erro ao salvar conversas no localStorage:", err);
  }
}

export const PRESET_SCENARIOS = [
  {
    id: "smtp_error",
    title: "📩 Erro 550 Relaying / Envio SMTP",
    category: "support_n2" as const,
    firstMessage: "Boa tarde! Nossos colaboradores não estão conseguindo enviar e-mails pelo Outlook corporativo. Está dando mensagem de erro de autenticação SMTP.",
    botReply: "Olá! Para resolver o erro de envio no Outlook: vá em Arquivo > Configurações de Conta > selecione a conta > Mais Configurações > na aba 'Servidor de Saída', marque 'Meu servidor de saída (SMTP) requer autenticação'. A porta recomendada é 465 SSL/TLS. Precisa de auxílio passo a passo?",
  },
  {
    id: "vps_load",
    title: "💻 Lentidão / Carga no Servidor Cloud",
    category: "support_n2" as const,
    firstMessage: "Olá suporte! Nosso sistema web está demorando para carregar no servidor VPS dedicado. Poderiam verificar se há alto consumo de CPU ou memória?",
    botReply: "Olá! Acionei o diagnóstico dos recursos do seu servidor VPS. Nossa equipe pode verificar os processos ativos via SSH e analisar os logs do servidor web Apache/Nginx. Posso direcionar para a fila prioritária do Suporte N2?",
  },
  {
    id: "commercial_plan",
    title: "💼 Cotação de 50 Contas e Nuvem",
    category: "commercial" as const,
    firstMessage: "Olá! Estamos avaliando migrar 50 caixas postais corporativas e um servidor em nuvem para a ComBR. Qual o valor mensal e prazo de ativação?",
    botReply: "Olá! É um prazer atender sua empresa. Temos pacotes empresariais com armazenamento dedicado por conta, antivírus integrado e suporte humanizado 24/7. Gostaria de receber uma proposta comercial formal por e-mail ou WhatsApp?",
  },
  {
    id: "billing_invoice",
    title: "💳 2ª Via de Fatura e Nota Fiscal",
    category: "financial" as const,
    firstMessage: "Bom dia! Nosso setor contábil precisa da segunda via do boleto e da Nota Fiscal de Serviços eletrônica deste mês.",
    botReply: "Bom dia! Localizamos seu cadastro. Você pode efetuar o pagamento imediato via Pix com baixa automática em poucos segundos ou baixar a NFS-e e o boleto bancário pelo Portal do Cliente ComBR.",
  },
  {
    id: "dns_mx",
    title: "🌐 Apontamento de DNS / Registros MX e SPF",
    category: "support_n2" as const,
    firstMessage: "Olá! Acabei de registrar um novo domínio e preciso configurar os apontamentos MX, SPF e DKIM para os e-mails funcionarem na ComBR.",
    botReply: "Excelente! Para apontar seus e-mails para a nuvem ComBR, configure: MX mx.combr.com.br (prioridade 10) e TXT (SPF) 'v=spf1 include:_spf.combr.com.br ~all'. Deseja que um atendente técnico valide os registros do seu domínio?",
  },
];

export const RANDOM_NAMES = [
  { name: "Gabriel Siqueira", company: "InovaTech Softwares", phone: "+55 (11) 98112-3344" },
  { name: "Patrícia Nogueira", company: "Advocacia Nogueira & Associados", phone: "+55 (21) 99443-8877" },
  { name: "Renato Silveira", company: "Silveira Engenharia Civil", phone: "+55 (31) 98776-5544" },
  { name: "Camila Guimarães", company: "Studio Criativo Digital", phone: "+55 (41) 99221-6655" },
  { name: "Felipe Antunes", company: "Distribuidora Nacional de Peças", phone: "+55 (19) 98334-1122" },
  { name: "Aline Vasconcelos", company: "Hospital Oftalmológico Visão", phone: "+55 (61) 99554-7788" },
];

export const AVATAR_COLORS = [
  "#00a884",
  "#3b82f6",
  "#8b5cf6",
  "#ec4899",
  "#f97316",
  "#eab308",
  "#06b6d4",
  "#10b981",
];

export function getInitials(name: string): string {
  if (!name) return "CL";
  const parts = name.trim().split(/\s+/);
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
}
