// Humanized Voice & Speech Synthesis Helper for ComIA
// Provides natural voice selection, text normalization, and accessibility controls

export interface VoiceOption {
  voice: SpeechSynthesisVoice;
  displayName: string;
  isRecommended: boolean;
  score: number;
}

export const TTS_STORAGE_KEYS = {
  ENABLED: "comia_tts_enabled",
  VOICE_URI: "comia_tts_voice_uri",
  RATE: "comia_tts_rate",
};

/**
 * Strips markdown, emojis and converts technical terms into natural Portuguese speech
 */
export function normalizeTextForSpeech(rawText: string): string {
  if (!rawText) return "";

  let text = rawText;

  // Remove markdown images and links formatting: [text](url) -> text
  text = text.replace(/\[([^\]]+)\]\([^)]+\)/g, "$1");

  // Remove standalone URLs
  text = text.replace(/https?:\/\/[^\s]+/g, "link do site");

  // Remove markdown headers, bold, italics, strikethrough, backticks, blockquotes, horizontal rules
  text = text
    .replace(/^#{1,6}\s+/gm, "")
    .replace(/\*\*([^*]+)\*\*/g, "$1")
    .replace(/\*([^*]+)\*/g, "$1")
    .replace(/__([^_]+)__/g, "$1")
    .replace(/_([^_]+)_/g, "$1")
    .replace(/~~([^~]+)~~/g, "$1")
    .replace(/```[\s\S]*?```/g, "código técnico omitido")
    .replace(/`([^`]+)`/g, "$1")
    .replace(/^\s*>\s+/gm, "")
    .replace(/^-{3,}/gm, "")
    .replace(/_{3,}/gm, "");

  // Remove emojis so browser TTS doesn't read out emoji names mechanically
  text = text.replace(/[\u{1F300}-\u{1FAD6}\u{1F600}-\u{1F64F}\u{1F680}-\u{1F6FF}\u{2600}-\u{26FF}\u{2700}-\u{27BF}\u{1F900}-\u{1F9FF}\u{1F1E6}-\u{1F1FF}]/gu, "");

  // Convert technical terms and abbreviations into natural conversational spoken Portuguese
  const phoneticMap: [RegExp, string][] = [
    [/\bComBr\b/gi, "Com Brasil"],
    [/\bComIA\b/gi, "Com I A"],
    [/\bTI\b/g, "T. I."],
    [/\bVPS\b/gi, "V. P. S."],
    [/\bAWS\b/gi, "A. W. S."],
    [/\bOCI\b/gi, "O. C. I."],
    [/\bIMAP\b/gi, "I-MAP"],
    [/\bSMTP\b/gi, "S-M-T-P"],
    [/\bPOP3\b/gi, "POP 3"],
    [/\bSSL\/TLS\b/gi, "S-S-L ou T-L-S"],
    [/\bSSL\b/gi, "S-S-L"],
    [/\bTLS\b/gi, "T-L-S"],
    [/\b2ª\s*via\b/gi, "segunda via"],
    [/\b1ª\s*via\b/gi, "primeira via"],
    [/\bN2\b/gi, "N dois"],
    [/\bN1\b/gi, "N um"],
    [/\bSaveData\b/gi, "Save Data"],
    [/\bcPanel\b/gi, "C-Panel"],
    [/\bR\$\s*([0-9.,]+)/gi, "$1 reais"],
    [/\bkbps\b/gi, "quilobits por segundo"],
    [/\bMbps\b/gi, "megabits por segundo"],
    [/\bGB\b/gi, "gigabytes"],
    [/\bMB\b/gi, "megabytes"],
    [/\bTB\b/gi, "terabytes"],
    [/\bDNS\b/gi, "D. N. S."],
    [/\bSPF\b/gi, "S. P. F."],
    [/\bDKIM\b/gi, "D-KIM"],
    [/\bDMARC\b/gi, "D-MARC"],
    [/\bCNPJ\b/gi, "C. N. P. J."],
    [/\bCPF\b/gi, "C. P. F."],
    [/\bNF\b/gi, "Nota Fiscal"],
    [/\bex\.:/gi, "por exemplo:"],
  ];

  for (const [regex, replacement] of phoneticMap) {
    text = text.replace(regex, replacement);
  }

  // Turn bullets and numbered items into natural conversational pauses
  text = text
    .replace(/^\s*[-*•]\s+/gm, ", ")
    .replace(/^\s*\d+\.\s+/gm, ", ");

  // Collapse multiple spaces, line breaks and commas
  text = text
    .replace(/,\s*,/g, ",")
    .replace(/\s+/g, " ")
    .trim();

  return text;
}

/**
 * Score and sort voices so the most humanized natural voices appear first
 */
function scoreVoice(voice: SpeechSynthesisVoice): { score: number; label: string; isRecommended: boolean } {
  const name = voice.name.toLowerCase();
  const lang = (voice.lang || "").toLowerCase();
  let score = 0;

  // Language priority: pt-BR > pt-PT > other
  if (lang.includes("pt-br") || lang === "pt_br") {
    score += 50;
  } else if (lang.startsWith("pt")) {
    score += 30;
  } else {
    score -= 50;
  }

  // Natural / Neural high quality online voices
  if (name.includes("natural") || name.includes("online (natural)")) {
    score += 100;
  }
  if (name.includes("neural") || name.includes("enhanced") || name.includes("premium")) {
    score += 80;
  }
  if (name.includes("google") && lang.includes("pt")) {
    score += 70;
  }
  if (name.includes("francisca") || name.includes("antonio") || name.includes("thalita")) {
    score += 60;
  }
  if (name.includes("luciana") || name.includes("felipe") || name.includes("joana")) {
    score += 50;
  }
  if (name.includes("microsoft") && lang.includes("pt")) {
    score += 40;
  }

  let label = voice.name;
  if (name.includes("francisca")) {
    label = "Francisca (Natural • Mais Humanizada)";
  } else if (name.includes("antonio")) {
    label = "Antônio (Natural • Voz Masculina)";
  } else if (name.includes("thalita")) {
    label = "Thalita (Natural • Voz Feminina)";
  } else if (name.includes("google") && lang.includes("pt")) {
    label = "Google Português (Brasil • Humanizada)";
  } else if (name.includes("luciana")) {
    label = "Luciana (Brasil • Apple)";
  } else if (name.includes("felipe")) {
    label = "Felipe (Brasil • Apple)";
  } else if (name.includes("maria")) {
    label = "Maria (Brasil)";
  }

  const isRecommended = score >= 80;

  return { score, label, isRecommended };
}

/**
 * Returns sorted available Brazilian Portuguese voices
 */
export function getAvailableVoices(): VoiceOption[] {
  if (typeof window === "undefined" || !("speechSynthesis" in window)) {
    return [];
  }

  const allVoices = window.speechSynthesis.getVoices();
  const ptVoices = allVoices.filter((v) => {
    const lang = (v.lang || "").toLowerCase();
    return lang.startsWith("pt");
  });

  // If no pt voice, fallback to all
  const pool = ptVoices.length > 0 ? ptVoices : allVoices;

  const scored: VoiceOption[] = pool.map((voice) => {
    const { score, label, isRecommended } = scoreVoice(voice);
    return {
      voice,
      displayName: label,
      isRecommended,
      score,
    };
  });

  return scored.sort((a, b) => b.score - a.score);
}

/**
 * Finds the preferred humanized voice based on saved URI or highest score
 */
export function getPreferredVoice(savedUri?: string | null): SpeechSynthesisVoice | null {
  const options = getAvailableVoices();
  if (options.length === 0) return null;

  if (savedUri) {
    const matched = options.find((opt) => opt.voice.voiceURI === savedUri);
    if (matched) return matched.voice;
  }

  // Pick the top-scoring natural voice
  return options[0].voice;
}

let currentUtterance: SpeechSynthesisUtterance | null = null;

export interface SpeakOptions {
  voiceURI?: string;
  rate?: number; // 0.85 to 1.2
  pitch?: number;
  onStart?: () => void;
  onEnd?: () => void;
  onError?: (err: any) => void;
}

/**
 * Stops any ongoing speech synthesis
 */
export function stopSpeech() {
  if (typeof window === "undefined" || !("speechSynthesis" in window)) return;
  try {
    window.speechSynthesis.cancel();
    currentUtterance = null;
  } catch {}
}

/**
 * Check if browser is currently speaking
 */
export function isSpeaking(): boolean {
  if (typeof window === "undefined" || !("speechSynthesis" in window)) return false;
  return window.speechSynthesis.speaking;
}

/**
 * Plays humanized text-to-speech with natural cadence and voice selection
 */
export function speakHumanized(text: string, options: SpeakOptions = {}): boolean {
  if (typeof window === "undefined" || !("speechSynthesis" in window)) {
    console.warn("SpeechSynthesis não suportado neste navegador");
    return false;
  }

  try {
    stopSpeech();

    const clean = normalizeTextForSpeech(text);
    if (!clean) return false;

    const utterance = new SpeechSynthesisUtterance(clean);
    currentUtterance = utterance;

    // Rate: 0.98 is the optimal conversational human pace in Portuguese
    utterance.rate = options.rate ?? 0.98;
    utterance.pitch = options.pitch ?? 1.0;
    utterance.lang = "pt-BR";

    const voice = getPreferredVoice(options.voiceURI);
    if (voice) {
      utterance.voice = voice;
      utterance.lang = voice.lang || "pt-BR";
    }

    utterance.onstart = () => {
      options.onStart?.();
    };

    utterance.onend = () => {
      currentUtterance = null;
      options.onEnd?.();
    };

    utterance.onerror = (event) => {
      currentUtterance = null;
      // 'canceled' is common when user stops or switches message
      if (event.error !== "canceled" && event.error !== "interrupted") {
        console.warn("TTS utterance error:", event.error);
        options.onError?.(event);
      } else {
        options.onEnd?.();
      }
    };

    window.speechSynthesis.speak(utterance);
    return true;
  } catch (err) {
    console.warn("Falha ao sintetizar voz:", err);
    options.onError?.(err);
    return false;
  }
}
