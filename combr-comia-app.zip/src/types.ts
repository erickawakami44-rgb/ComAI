export type MessageSender = 'user' | 'assistant' | 'system';

export interface ContactCardData {
  name: string;
  phone: string;
  organization?: string;
  email?: string;
  avatar?: string;
}

export interface DocumentAttachmentData {
  name: string;
  size: string;
  type: string;
  url?: string;
  dataBase64?: string;
  textContent?: string;
  caption?: string;
  mimeType?: string;
}

export interface ImageAttachmentData {
  url: string;
  caption?: string;
  fileName?: string;
  size?: string;
}

export interface Message {
  id: string;
  sender: MessageSender;
  content: string;
  timestamp: string;
  category?: 'support' | 'support_n2' | 'commercial' | 'financial' | 'general' | 'escalation';
  ticketData?: Ticket;
  serverInfoSnippet?: boolean;
  isAudio?: boolean;
  audioDuration?: string;
  audioUrl?: string;
  audioTranscript?: string;
  imageAttachment?: ImageAttachmentData;
  documentAttachment?: DocumentAttachmentData;
  contactAttachment?: ContactCardData;
  reactions?: string[];
  status?: 'sent' | 'delivered' | 'read';
  showDepartmentOptions?: boolean;
  isHumanAgent?: boolean;
  agentName?: string;
  agentRole?: string;
  isInternalNote?: boolean;
  showRatingCard?: boolean;
  ratingData?: AttendanceRating;
}

export type TriageType = 'support_n2' | 'commercial' | 'financial';

export type TicketStatus = 'not_started' | 'in_progress' | 'completed' | 'cancelled';

export interface Ticket {
  id: string;
  type: TriageType;
  // Common
  domain?: string;
  cnpjOrCorporateName?: string;
  companyName?: string;
  contactName?: string;
  phone?: string;
  email?: string;
  subject: string;
  // Specific
  affectedEmail?: string;
  errorMessage?: string;
  approxAccountsOrResources?: string;
  attachmentImage?: {
    url: string;
    fileName?: string;
    caption?: string;
    size?: string;
  };
  attachmentDocument?: {
    name: string;
    size: string;
    type: string;
    url?: string;
  };
  status: TicketStatus;
  createdAt: string;
  updatedAt?: string;
}

export interface ChatChannel {
  id: string;
  name: string;
  subtitle: string;
  avatarType: 'bot' | 'n2' | 'commercial' | 'financial' | 'tickets';
  unreadCount?: number;
  lastMessage: string;
  lastTime: string;
  isPinned?: boolean;
  isVerified?: boolean;
  type: 'main' | TriageType | 'tickets';
}

export interface EmailServerConfig {
  protocol: string;
  host: string;
  port: string;
  security: string;
  description: string;
}

export type AppViewMode = 'split' | 'client' | 'agent';

export interface AttendanceRating {
  stars: number; // 1 to 5
  tags?: string[];
  comment?: string;
  clientName?: string;
  ratedAt: string;
}

export interface WhatsAppClientChat {
  id: string;
  name: string;
  phone: string;
  company?: string;
  domain?: string;
  email?: string;
  category: 'support_n2' | 'commercial' | 'financial' | 'general';
  avatarColor?: string;
  avatarInitials?: string;
  isVerified?: boolean;
  isPinned?: boolean;
  unreadCount: number;
  lastMessage: string;
  lastMessageTime: string;
  status: 'online' | 'offline' | 'away';
  lastSeen?: string;
  messages: Message[];
  mode: 'bot' | 'human';
  assignedAgent?: {
    name: string;
    role: string;
    email?: string;
  } | null;
  rating?: AttendanceRating;
  createdAt: string;
  updatedAt: string;
}

export interface LiveSession {
  id: string;
  mode: 'bot' | 'human';
  status?: 'active' | 'in_progress' | 'finished';
  assignedAgent: {
    name: string;
    role: string;
    email?: string;
  } | null;
  clientInfo: {
    name: string;
    phone: string;
    company?: string;
    online: boolean;
  };
  messages: Message[];
  unreadCountForAgent: number;
  internalNotes?: Array<{
    id: string;
    author: string;
    text: string;
    timestamp: string;
  }>;
  createdAt: string;
  updatedAt: string;
  finishedAt?: string;
  awaitingRating?: boolean;
  rating?: AttendanceRating;
}

