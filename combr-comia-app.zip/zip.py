import os
import zipfile

exclude_dirs = {"node_modules", ".git", ".system_generated", ".cache", "__pycache__"}
exclude_files = {".DS_Store", "thumbs.db"}

def make_zip(output_filename):
    print(f"Compactando projeto para {output_filename}...")
    # Remove old zip if present to avoid corruption
    if os.path.exists(output_filename):
        try:
            os.remove(output_filename)
        except Exception:
            pass

    with zipfile.ZipFile(output_filename, "w", zipfile.ZIP_DEFLATED) as zf:
        for root, dirs, files in os.walk("."):
            dirs[:] = [d for d in dirs if d not in exclude_dirs and not d.startswith(".aistudio")]
            for f in files:
                if f in exclude_files or f.endswith(".zip") or f.endswith(".pyc"):
                    continue
                full_path = os.path.join(root, f)
                arc_name = os.path.relpath(full_path, ".")
                zf.write(full_path, arc_name)
    print(f"Concluído! Tamanho: {os.path.getsize(output_filename)} bytes")

if __name__ == "__main__":
    os.makedirs("public", exist_ok=True)
    make_zip("combr-comia-app.zip")
    # Copy to public for static serving
    import shutil
    shutil.copyfile("combr-comia-app.zip", "public/combr-comia-app.zip")
    print(f"Copiado para public/combr-comia-app.zip com sucesso!")

